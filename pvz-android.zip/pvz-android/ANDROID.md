# Сборка APK

## Вариант 1. Через GitHub (без Android Studio)

1. Создайте репозиторий на github.com и загрузите в него ВСЕ файлы этого проекта
   (включая скрытую папку `.github`).
2. Откройте вкладку **Actions** → **Build Android APK** → **Run workflow**.
3. Через 5–10 минут откройте завершённый запуск и скачайте артефакт **pvz-debug-apk**.
   Внутри будет `app-debug.apk`. Распакуйте и установите на телефон
   (разрешите установку из неизвестных источников).

## Вариант 2. На своём компьютере

Нужны: Node.js 22+, JDK 21, Android SDK (проще всего поставить Android Studio).

```bash
npm install
npm run android:add     # один раз: создаёт папку android/
npm run android:apk     # сборка, APK: android/app/build/outputs/apk/debug/app-debug.apk
```

Для проверки на телефоне по USB: `npx cap run android`.
