import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import type { ZombieId } from '@/data/zombies';
import type { PlayablePlant } from './balance';
import { BOARD, cellKey, colX, HOUSE_X, MOWER_X, rowGroundY, TARGETABLE_X, ZOMBIE_SPAWN_X, type Cell } from './Board';
import { Effects } from './Effects';
import type { LevelSession } from './LevelSession';
import { LawnMower } from './entities/LawnMower';
import { Pea, type PeaKind } from './entities/Pea';
import { t } from '@/i18n/ru';
import { createPlant, type Plant } from './entities/Plant';
import { Sun } from './entities/Sun';
import { Zombie } from './entities/Zombie';

function prune<T extends { alive: boolean }>(list: T[]): void {
  let w = 0;
  for (const item of list) if (item.alive) list[w++] = item;
  list.length = w;
}

/**
 * Все сущности поля и правила их взаимодействия: кто в кого стреляет,
 * кто кого ест, взрывы, газонокосилки и проигрыш у дома.
 */
export class World {
  readonly plants: Plant[] = [];
  readonly zombies: Zombie[] = [];
  readonly peas: Pea[] = [];
  readonly suns: Sun[] = [];
  readonly mowers: LawnMower[];
  readonly fx: Effects;
  /** Мир замирает при поражении. */
  frozen = false;
  /** Где погиб последний зомби — там появится награда. */
  lastKill = { x: colX(6), y: rowGroundY(2) };
  onHouseReached?: (zombie: Zombie) => void;
  private readonly grid = new Map<string, Plant>();

  constructor(
    readonly scene: Phaser.Scene,
    readonly session: LevelSession,
  ) {
    this.fx = new Effects(scene);
    this.mowers = session.script.rows.map((row) => new LawnMower(this, row));
  }

  update(dt: number): void {
    if (this.frozen) return;
    for (const p of this.plants) if (p.alive) p.update(dt);
    for (const z of this.zombies) if (z.alive) z.update(dt);
    for (const p of this.peas) if (p.alive) p.update(dt);
    for (const s of this.suns) s.update(dt);
    for (const m of this.mowers) m.update(dt);
    prune(this.plants);
    prune(this.zombies);
    prune(this.peas);
    prune(this.suns);

    for (const z of this.zombies) {
      if (z.x < MOWER_X + 48) this.mowers.find((m) => m.row === z.row && m.state === 'idle')?.trigger();
      if (z.x < HOUSE_X) {
        this.onHouseReached?.(z);
        return;
      }
    }
  }

  setTimeScale(scale: number): void {
    this.fx.setTimeScale(scale);
  }

  isRowActive(row: number): boolean {
    return this.session.script.rows.includes(row);
  }

  plantAt(cell: Cell): Plant | undefined {
    return this.grid.get(cellKey(cell));
  }

  canPlant(cell: Cell): boolean {
    return this.isRowActive(cell.row) && !this.grid.has(cellKey(cell));
  }

  addPlant(id: PlayablePlant, cell: Cell): Plant {
    const plant = createPlant(this, id, cell);
    this.grid.set(cellKey(cell), plant);
    this.plants.push(plant);
    audio.sfx('plant');
    this.fx.plantDust(plant.x, plant.y);
    return plant;
  }

  releaseCell(plant: Plant): void {
    const key = cellKey(plant);
    if (this.grid.get(key) === plant) this.grid.delete(key);
  }

  spawnZombie(type: ZombieId, row: number): Zombie {
    const zombie = new Zombie(this, type, row, ZOMBIE_SPAWN_X + Phaser.Math.Between(0, 40));
    this.zombies.push(zombie);
    return zombie;
  }

  spawnPea(x: number, y: number, row: number, kind: PeaKind = 'pea'): void {
    this.peas.push(new Pea(this, x, y, row, kind));
  }

  spawnSkySun(x: number, landY: number): void {
    this.suns.push(Sun.fromSky(this, x, landY));
  }

  spawnPlantSun(x: number, y: number): void {
    this.suns.push(Sun.fromPlant(this, x, y));
  }

  get aliveZombies(): number {
    return this.zombies.reduce((n, z) => n + (z.alive ? 1 : 0), 0);
  }

  hasTargetInRow(row: number, fromX: number): boolean {
    return this.zombies.some((z) => z.row === row && z.targetable && z.x > fromX - 20);
  }

  zombieHitBy(row: number, x: number): Zombie | undefined {
    return this.zombies.find((z) => z.alive && z.row === row && z.x < TARGETABLE_X && x >= z.x - 22 && x <= z.x + 34);
  }

  /** Растение, в которое упёрся зомби (он смотрит влево). */
  blockingPlant(row: number, zombieX: number): Plant | undefined {
    return this.plants.find((p) => p.alive && p.row === row && zombieX <= p.x + 46 && zombieX >= p.x - 14);
  }

  /** Растение, через которое прыгун с шестом сейчас перемахнёт. */
  vaultTarget(row: number, zombieX: number): Plant | undefined {
    return this.plants.find((p) => p.alive && p.row === row && zombieX <= p.x + 72 && zombieX >= p.x + 20);
  }

  /** Зомби, наступивший на мину (мина срабатывает чуть раньше, чем зомби начнёт её есть). */
  zombieOnMine(row: number, mineX: number): boolean {
    return this.zombies.some((z) => z.alive && !z.airborne && z.row === row && z.x <= mineX + 52 && z.x >= mineX - 30);
  }

  /** Ближайший зомби в пределах досягаемости кусачки. */
  chompTarget(row: number, x: number, reachCols: number): Zombie | undefined {
    let best: Zombie | undefined;
    for (const z of this.zombies) {
      if (!z.alive || z.airborne || z.row !== row || z.x < x - 20 || z.x > x + reachCols * BOARD.cellW) continue;
      if (!best || z.x < best.x) best = z;
    }
    return best;
  }

  mineExplosion(x: number, y: number, row: number, damage: number, radius: number): void {
    this.fx.explosion(x, y, 0.55);
    this.fx.popText(x, y - 50, t.game.boom, '#ffd23f');
    audio.sfx('explode');
    this.scene.cameras.main.shake(200, 0.008);
    for (const z of this.zombies) {
      if (z.alive && !z.airborne && z.row === row && Math.abs(z.x - x) <= radius) z.damage(damage, 'explosion');
    }
  }

  explode(x: number, y: number, row: number, damage: number, radiusCols: number): void {
    this.fx.explosion(x, y);
    audio.sfx('explode');
    this.scene.cameras.main.shake(320, 0.012);
    for (const z of this.zombies) {
      if (z.alive && Math.abs(z.row - row) <= 1 && Math.abs(z.x - x) <= radiusCols * BOARD.cellW) z.damage(damage, 'explosion');
    }
  }

  onZombieKilled(zombie: Zombie): void {
    this.lastKill = { x: zombie.x, y: zombie.groundY };
  }

  clearSuns(): void {
    for (const s of this.suns) s.collect();
  }
}
