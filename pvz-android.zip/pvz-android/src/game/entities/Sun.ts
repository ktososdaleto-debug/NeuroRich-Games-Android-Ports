import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import { Tex } from '@/graphics/TextureKeys';
import { SUN_FALL_SPEED, SUN_LIFETIME, SUN_VALUE } from '../balance';
import { DEPTH_SUN } from '../Board';
import type { World } from '../World';

/** Куда летит собранное солнце (центр счётчика в HUD; камера игры в бою не сдвинута). */
export const SUN_COUNTER_POS = { x: 63, y: 40 } as const;

type SunState = 'falling' | 'popping' | 'ground' | 'collecting' | 'gone';

/** Солнце: падает с неба или выпрыгивает из подсолнуха, лежит какое-то время и мерцает перед исчезновением. */
export class Sun {
  private readonly image: Phaser.GameObjects.Image;
  private state: SunState;
  private life = SUN_LIFETIME;
  private targetY = 0;

  constructor(
    private readonly world: World,
    x: number,
    y: number,
    private readonly value = SUN_VALUE,
  ) {
    this.image = world.scene.add.image(x, y, Tex.Fx.SunDrop).setDepth(DEPTH_SUN).setScale(0.82);
    this.image.setInteractive(new Phaser.Geom.Circle(44, 44, 36), Phaser.Geom.Circle.Contains);
    this.image.input!.cursor = 'pointer';
    this.image.on(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, () => this.collect());
    this.state = 'falling';
  }

  get alive(): boolean {
    return this.state !== 'gone';
  }

  static fromSky(world: World, x: number, landY: number): Sun {
    const sun = new Sun(world, x, -50);
    sun.targetY = landY;
    return sun;
  }

  /** Солнце из подсолнуха: подпрыгивает дугой и приземляется рядом. */
  static fromPlant(world: World, x: number, y: number): Sun {
    const sun = new Sun(world, x, y);
    sun.state = 'popping';
    audio.sfx('pop');
    const endX = x + Phaser.Math.Between(-34, 34);
    const endY = y + 70;
    sun.image.setScale(0.3);
    world.scene.tweens.add({ targets: sun.image, scale: 0.82, duration: 300, ease: 'Back.easeOut' });
    world.scene.tweens.addCounter({
      from: 0,
      to: 1,
      duration: 650,
      onUpdate: (tw) => {
        if (sun.state !== 'popping') return;
        const t = tw.getValue() ?? 0;
        sun.image.x = Phaser.Math.Linear(x, endX, t);
        sun.image.y = Phaser.Math.Linear(y, endY, t) - Math.sin(Math.PI * t) * 55;
      },
      onComplete: () => {
        if (sun.state === 'popping') sun.state = 'ground';
      },
    });
    return sun;
  }

  update(dt: number): void {
    if (this.state === 'gone' || this.state === 'collecting') return;
    this.image.angle += dt * 40;
    if (this.state === 'falling') {
      this.image.y += SUN_FALL_SPEED * dt;
      if (this.image.y >= this.targetY) {
        this.image.y = this.targetY;
        this.state = 'ground';
      }
    } else if (this.state === 'ground') {
      this.life -= dt;
      if (this.life < 3) this.image.setAlpha(0.55 + 0.45 * Math.abs(Math.sin(this.life * 6)));
      if (this.life <= 0) this.vanish();
    }
  }

  collect(): void {
    if (this.state === 'collecting' || this.state === 'gone') return;
    if (this.world.session.phase === 'defeat') return;
    this.state = 'collecting';
    this.image.disableInteractive().setAlpha(1);
    audio.sfx('sun');
    this.world.fx.sparkle(this.image.x, this.image.y);
    this.world.scene.tweens.add({
      targets: this.image,
      x: SUN_COUNTER_POS.x,
      y: SUN_COUNTER_POS.y,
      scale: 0.5,
      duration: 600,
      ease: 'Cubic.easeInOut',
      onComplete: () => {
        this.world.session.addSun(this.value);
        this.destroy();
      },
    });
  }

  private vanish(): void {
    this.state = 'collecting';
    this.image.disableInteractive();
    this.world.scene.tweens.add({ targets: this.image, alpha: 0, scale: 0.4, duration: 300, onComplete: () => this.destroy() });
  }

  private destroy(): void {
    this.state = 'gone';
    this.image.destroy();
  }
}
