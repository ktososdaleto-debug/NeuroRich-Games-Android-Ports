import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import { Tex } from '@/graphics/TextureKeys';
import { PLANT_STATS, type PlayablePlant } from '../balance';
import { colX, depthOf, Layer, rowGroundY, type Cell } from '../Board';
import { PLANT_VISUALS } from '../view/plantVisuals';
import type { World } from '../World';
import type { Zombie } from './Zombie';

/** Базовое растение: спрайт, здоровье, покачивание, урон и выкапывание. */
export abstract class Plant {
  readonly sprite: Phaser.GameObjects.Container;
  readonly x: number;
  readonly y: number;
  readonly col: number;
  readonly row: number;
  hp: number;
  readonly maxHp: number;
  alive = true;
  protected readonly body: Phaser.GameObjects.Image;
  protected time = Math.random() * 10;
  private highlighted = false;

  constructor(
    protected readonly world: World,
    readonly id: PlayablePlant,
    cell: Cell,
  ) {
    const scene = world.scene;
    this.col = cell.col;
    this.row = cell.row;
    this.x = colX(cell.col);
    this.y = rowGroundY(cell.row);
    this.hp = this.maxHp = PLANT_STATS[id].hp;

    const visual = PLANT_VISUALS[id]!;
    const shadow = scene.add.ellipse(0, 0, 90, 22, 0x000000, 0.22);
    this.body = scene.add.image(0, 0, visual.key).setOrigin(visual.origin.x, visual.origin.y);
    this.sprite = scene.add.container(this.x, this.y, [shadow, this.body]).setDepth(depthOf(this.row, Layer.Plant));
    this.sprite.setScale(0);
    scene.tweens.add({ targets: this.sprite, scale: visual.scale, duration: 260, ease: 'Back.easeOut' });
  }

  update(dt: number): void {
    this.time += dt;
    this.idle();
    this.onUpdate(dt);
  }

  damage(amount: number): void {
    if (!this.alive) return;
    this.hp -= amount;
    this.body.setTint(0xffc0a0);
    this.world.scene.time.delayedCall(90, () => this.alive && this.applyTint());
    this.onDamaged();
    if (this.hp <= 0) {
      audio.sfx('gulp');
      this.remove();
    }
  }

  /** Подсветка под лопатой. */
  setHighlight(on: boolean): void {
    this.highlighted = on;
    this.applyTint();
  }

  dig(): void {
    audio.sfx('dig');
    this.world.fx.plantDust(this.x, this.y);
    this.remove();
  }

  remove(animated = true): void {
    if (!this.alive) return;
    this.alive = false;
    this.world.releaseCell(this);
    if (!animated) {
      this.sprite.destroy();
      return;
    }
    this.world.scene.tweens.add({
      targets: this.sprite,
      scaleX: 0,
      scaleY: 0,
      duration: 200,
      ease: 'Back.easeIn',
      onComplete: () => this.sprite.destroy(),
    });
  }

  protected idle(): void {
    this.body.scaleY = 1 + Math.sin(this.time * 2.6) * 0.025;
    this.body.angle = Math.sin(this.time * 1.7) * 2.5;
  }

  protected onUpdate(_dt: number): void {}

  protected onDamaged(): void {}

  protected applyTint(): void {
    if (this.highlighted) this.body.setTint(0xff9a9a);
    else this.body.clearTint();
  }
}

/** Стрелок: горохострел, снежный горох (замедляет) и повторитель (очередь из двух горошин). */
class Shooter extends Plant {
  private cooldown = 0.5 + Math.random() * 0.7;

  protected override onUpdate(dt: number): void {
    this.cooldown -= dt;
    if (this.cooldown > 0 || !this.world.hasTargetInRow(this.row, this.x)) return;
    const stats = PLANT_STATS[this.id === 'snowpea' ? 'snowpea' : this.id === 'repeater' ? 'repeater' : 'peashooter'];
    this.cooldown = stats.fireInterval;
    this.fire();
    if (this.id === 'repeater') {
      this.world.scene.time.delayedCall(PLANT_STATS.repeater.burstGap * 1000, () => this.alive && this.fire());
    }
  }

  private fire(): void {
    const s = this.sprite.scaleX;
    this.world.spawnPea(this.x + 72 * s, this.y - 100 * s, this.row, this.id === 'snowpea' ? 'snow' : 'pea');
    audio.sfx('shoot');
    this.world.scene.tweens.add({ targets: this.body, scaleX: 0.86, duration: 70, yoyo: true, ease: 'Quad.easeOut' });
  }
}

/** Картофельная мина: заряжается под землёй, затем взрывается под первым наступившим зомби. */
class PotatoMine extends Plant {
  private armTimer: number = PLANT_STATS.potatomine.armTime;
  private armed = false;
  private readonly light: Phaser.GameObjects.Image;

  constructor(world: World, id: PlayablePlant, cell: Cell) {
    super(world, id, cell);
    this.body.setTexture(Tex.Plant.PotatoMineBuried);
    this.light = world.scene.add.image(0, -66, Tex.Fx.Spark).setScale(1.4).setTint(0xff3030).setBlendMode(Phaser.BlendModes.ADD).setVisible(false);
    this.sprite.add(this.light);
  }

  protected override idle(): void {
    if (!this.armed) return;
    this.body.scaleY = 1 + Math.sin(this.time * 3) * 0.03;
    this.light.setAlpha(Math.sin(this.time * 7) > 0 ? 1 : 0.2);
  }

  protected override onUpdate(dt: number): void {
    if (!this.armed) {
      this.armTimer -= dt;
      if (this.armTimer <= 0) this.arm();
      return;
    }
    if (this.world.zombieOnMine(this.row, this.x)) {
      this.world.mineExplosion(this.x, this.y - 20, this.row, PLANT_STATS.potatomine.damage, PLANT_STATS.potatomine.radius);
      this.remove(false);
    }
  }

  private arm(): void {
    this.armed = true;
    this.body.setTexture(Tex.Plant.PotatoMine);
    this.light.setVisible(true);
    audio.sfx('pop');
    this.world.fx.plantDust(this.x, this.y);
    this.world.scene.tweens.add({ targets: this.body, scaleY: { from: 0.3, to: 1 }, duration: 380, ease: 'Back.easeOut' });
  }
}

/** Кусачка: проглатывает зомби перед собой целиком и долго жуёт. */
class Chomper extends Plant {
  private state: 'ready' | 'biting' | 'chewing' = 'ready';
  private timer = 0;
  private target: Zombie | null = null;

  protected override idle(): void {
    if (this.state === 'chewing') {
      this.body.scaleX = 1 + Math.sin(this.time * 6) * 0.05;
      this.body.angle = Math.sin(this.time * 3) * 2;
    } else if (this.state === 'ready') {
      super.idle();
    }
  }

  protected override onUpdate(dt: number): void {
    const stats = PLANT_STATS.chomper;
    if (this.state === 'ready') {
      const target = this.world.chompTarget(this.row, this.x, stats.reachCols);
      if (!target) return;
      this.target = target;
      this.state = 'biting';
      this.timer = stats.biteDelay;
      this.world.scene.tweens.add({ targets: this.body, angle: -16, scaleX: 1.12, duration: stats.biteDelay * 900, yoyo: true, ease: 'Quad.easeIn' });
      return;
    }
    this.timer -= dt;
    if (this.timer > 0) return;
    if (this.state === 'biting') {
      const t = this.target;
      this.target = null;
      if (t && t.alive && this.world.chompTarget(this.row, this.x, stats.reachCols + 0.3) === t) {
        t.swallow();
        audio.sfx('gulp');
        this.body.setTexture(Tex.Plant.ChomperChew);
        this.state = 'chewing';
        this.timer = stats.chewTime;
      } else {
        this.state = 'ready';
      }
    } else {
      this.body.setTexture(Tex.Plant.Chomper).setScale(1).setAngle(0);
      this.state = 'ready';
    }
  }
}

class Sunflower extends Plant {
  private timer = Phaser.Math.FloatBetween(PLANT_STATS.sunflower.firstSunMin, PLANT_STATS.sunflower.firstSunMax);
  private readonly glow: Phaser.GameObjects.Image;

  constructor(world: World, id: PlayablePlant, cell: Cell) {
    super(world, id, cell);
    this.glow = world.scene.add.image(0, -116, Tex.Fx.Spark).setScale(5).setAlpha(0).setBlendMode(Phaser.BlendModes.ADD);
    this.sprite.addAt(this.glow, 1);
  }

  protected override onUpdate(dt: number): void {
    this.timer -= dt;
    if (this.timer > 0) return;
    this.timer = PLANT_STATS.sunflower.interval;
    this.world.scene.tweens.add({ targets: this.glow, alpha: 0.9, duration: 350, yoyo: true, ease: 'Sine.easeInOut' });
    this.world.scene.time.delayedCall(320, () => {
      if (!this.alive) return;
      const s = this.sprite.scaleX;
      this.world.spawnPlantSun(this.x, this.y - 116 * s);
    });
  }
}

class CherryBomb extends Plant {
  private fuse: number = PLANT_STATS.cherrybomb.fuse;

  constructor(world: World, id: PlayablePlant, cell: Cell) {
    super(world, id, cell);
    audio.sfx('fuse');
    world.scene.tweens.add({ targets: this.body, scale: 1.35, duration: this.fuse * 1000, ease: 'Quad.easeIn' });
  }

  protected override idle(): void {
    this.body.x = Math.sin(this.time * 70) * 2;
    this.body.setTint(Math.sin(this.time * 28) > 0 ? 0xff6a6a : 0xffffff);
  }

  protected override onUpdate(dt: number): void {
    this.fuse -= dt;
    if (this.fuse > 0) return;
    const stats = PLANT_STATS.cherrybomb;
    this.world.explode(this.x, this.y - 30, this.row, stats.damage, stats.radiusCols);
    this.world.scene.tweens.killTweensOf(this.body);
    this.remove(false);
  }
}

class WallNut extends Plant {
  private readonly crack: Phaser.GameObjects.Image;

  constructor(world: World, id: PlayablePlant, cell: Cell) {
    super(world, id, cell);
    this.crack = world.scene.add.image(0, 0, Tex.Plant.WallnutCracks[0]).setOrigin(this.body.originX, this.body.originY).setVisible(false);
    this.sprite.add(this.crack);
  }

  protected override idle(): void {
    this.body.angle = Math.sin(this.time * 1.2) * 1.5;
    this.crack.angle = this.body.angle;
  }

  protected override onDamaged(): void {
    const frac = this.hp / this.maxHp;
    if (frac < 0.66) this.crack.setVisible(true);
    if (frac < 0.33) this.crack.setTexture(Tex.Plant.WallnutCracks[1]);
  }
}

const PLANT_CLASSES: Record<PlayablePlant, new (world: World, id: PlayablePlant, cell: Cell) => Plant> = {
  peashooter: Shooter,
  sunflower: Sunflower,
  cherrybomb: CherryBomb,
  wallnut: WallNut,
  potatomine: PotatoMine,
  snowpea: Shooter,
  chomper: Chomper,
  repeater: Shooter,
};

export function createPlant(world: World, id: PlayablePlant, cell: Cell): Plant {
  return new PLANT_CLASSES[id](world, id, cell);
}
