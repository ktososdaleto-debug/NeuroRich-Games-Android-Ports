import Phaser from 'phaser';
import { ensureButtonTexture } from '@/graphics/textures/ui';
import { t } from '@/i18n/ru';
import { Pressable } from '@/ui/Pressable';
import { textStyle } from '@/ui/theme';
import type { GameSpeed, LevelSession } from '../LevelSession';

const SPEEDS: GameSpeed[] = [1, 2, 3];
const W = 58;
const H = 48;

class SpeedButton extends Pressable {
  private readonly bg: Phaser.GameObjects.Image;

  constructor(scene: Phaser.Scene, x: number, y: number, readonly speed: GameSpeed) {
    super(scene, x, y, W, H);
    this.bg = scene.add.image(0, 0, '__DEFAULT');
    const label = scene.add.text(0, -3, `×${speed}`, textStyle(22)).setOrigin(0.5);
    this.content.add([this.bg, label]);
  }

  setSelected(active: boolean): void {
    const tex = ensureButtonTexture(this.scene.textures, active ? 'green' : 'wood', W, H);
    this.bg.setTexture(tex.key).setOrigin(tex.originX, tex.originY);
  }
}

/** Переключатель скорости игры ×1 / ×2 / ×3. */
export class SpeedControls extends Phaser.GameObjects.Container {
  private readonly buttons: SpeedButton[];

  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    private readonly session: LevelSession,
  ) {
    super(scene, x, y);
    const caption = scene.add.text(0, -40, t.game.speed, textStyle(14)).setOrigin(0.5);
    this.buttons = SPEEDS.map((speed, i) => new SpeedButton(scene, (i - 1) * (W + 6), 0, speed).onClick(() => session.setSpeed(speed)));
    this.add([caption, ...this.buttons]);
    scene.add.existing(this);
    session.on('speed-changed', this.sync, this);
    this.sync();
  }

  cycle(): void {
    const next = SPEEDS[(SPEEDS.indexOf(this.session.speed) + 1) % SPEEDS.length];
    this.session.setSpeed(next);
  }

  private sync(): void {
    for (const b of this.buttons) b.setSelected(b.speed === this.session.speed);
  }
}
