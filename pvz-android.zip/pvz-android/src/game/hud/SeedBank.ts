import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import { Tex } from '@/graphics/TextureKeys';
import { ensurePanelTexture } from '@/graphics/textures/ui';
import { Pressable } from '@/ui/Pressable';
import { inkStyle, textStyle } from '@/ui/theme';
import type { PlayablePlant } from '../balance';
import type { LevelSession } from '../LevelSession';
import { createPacketView } from '../view/plantVisuals';

const PACKET_W = 64;
const PACKET_H = 86;
const PACKET_STEP = 72;
const BANK_H = 100;

class SeedPacketButton extends Pressable {
  private readonly overlay: Phaser.GameObjects.Graphics;
  private readonly frame: Phaser.GameObjects.Graphics;
  private renderKey = '';

  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    readonly plant: PlayablePlant,
    private readonly session: LevelSession,
    hotkey: number,
  ) {
    super(scene, x, y, PACKET_W, PACKET_H);
    this.hoverScale = 1.08;
    const view = createPacketView(scene, plant);
    this.overlay = scene.add.graphics();
    this.frame = scene.add.graphics();
    this.frame.lineStyle(4, 0xfff27e, 1).strokeRoundedRect(-PACKET_W / 2 - 3, -PACKET_H / 2 - 3, PACKET_W + 6, PACKET_H + 6, 11);
    this.frame.setVisible(false);
    const key = scene.add.text(-PACKET_W / 2 + 9, -PACKET_H / 2 + 9, String(hotkey), textStyle(13)).setOrigin(0.5);
    this.content.add([view, this.overlay, this.frame, key]);
    this.onClick(() => this.pick());
  }

  pick(): void {
    const s = this.session;
    if (!s.canInteract) return;
    if (s.tool?.kind === 'plant' && s.tool.plant === this.plant) {
      s.selectTool(null);
      return;
    }
    if (!s.isReady(this.plant) || !s.canAfford(this.plant)) {
      this.shake();
      audio.sfx('error');
      if (!s.canAfford(this.plant)) s.emit('no-sun');
      return;
    }
    s.selectTool({ kind: 'plant', plant: this.plant });
  }

  refresh(): void {
    const s = this.session;
    const cd = s.cooldownFraction(this.plant);
    const afford = s.canAfford(this.plant);
    const selected = s.tool?.kind === 'plant' && s.tool.plant === this.plant;
    const state = `${cd.toFixed(3)}|${afford}|${selected}`;
    if (state === this.renderKey) return;
    this.renderKey = state;

    this.overlay.clear();
    if (!afford || selected) this.overlay.fillStyle(0x000000, 0.45).fillRoundedRect(-PACKET_W / 2 + 2, -PACKET_H / 2 + 2, PACKET_W - 4, PACKET_H - 4, 8);
    if (cd > 0) this.overlay.fillStyle(0x000000, 0.5).fillRect(-PACKET_W / 2 + 2, -PACKET_H / 2 + 2, PACKET_W - 4, (PACKET_H - 4) * cd);
    this.frame.setVisible(selected);
    this.content.y = selected ? 6 : 0;
  }
}

class ShovelButton extends Pressable {
  private readonly icon: Phaser.GameObjects.Image;

  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    private readonly session: LevelSession,
  ) {
    super(scene, x, y, 80, 80);
    this.icon = scene.add.image(0, 0, Tex.Icon.Shovel).setScale(0.95);
    const key = scene.add.text(-28, -28, 'S', textStyle(13)).setOrigin(0.5);
    this.content.add([scene.add.image(0, 0, Tex.Game.ShovelSlot), this.icon, key]);
    this.onClick(() => this.toggle());
  }

  toggle(): void {
    const s = this.session;
    if (!s.canInteract) return;
    s.selectTool(s.tool?.kind === 'shovel' ? null : { kind: 'shovel' });
  }

  refresh(): void {
    this.icon.setAlpha(this.session.tool?.kind === 'shovel' ? 0.2 : 1);
  }
}

/** Панель семян: счётчик солнца, пакетики растений и лопата. */
export class SeedBank extends Phaser.GameObjects.Container {
  private readonly packets: SeedPacketButton[];
  private readonly shovel: ShovelButton;
  private readonly sunText: Phaser.GameObjects.Text;
  private readonly sunIcon: Phaser.GameObjects.Image;

  constructor(
    scene: Phaser.Scene,
    private readonly session: LevelSession,
  ) {
    super(scene, 10, 6);
    const width = 104 + session.plants.length * PACKET_STEP + 8;
    const tex = ensurePanelTexture(scene.textures, 'wood', width, BANK_H);
    const panel = scene.add.image(width / 2, BANK_H / 2, tex.key).setOrigin(tex.originX, tex.originY);

    const sunBox = scene.add.graphics();
    sunBox.fillStyle(0x2a1a0b, 0.85).fillRoundedRect(14, 12, 80, 76, 14);
    sunBox.fillStyle(0xfffbea, 1).fillRoundedRect(20, 60, 68, 24, 9);
    this.sunIcon = scene.add.image(54, 34, Tex.Fx.SunDrop).setScale(0.6);
    this.sunText = scene.add.text(54, 72, String(session.sun), inkStyle(20, { fontStyle: '900' })).setOrigin(0.5);

    this.packets = session.plants.map(
      (plant, i) => new SeedPacketButton(scene, 104 + i * PACKET_STEP + PACKET_W / 2, BANK_H / 2, plant, session, i + 1),
    );
    this.shovel = new ShovelButton(scene, width + 50, BANK_H / 2, session);
    this.add([panel, sunBox, this.sunIcon, this.sunText, ...this.packets, this.shovel]);
    scene.add.existing(this);

    session.on('sun-changed', this.onSunChanged, this);
    session.on('no-sun', this.flashNoSun, this);
  }

  pickSlot(index: number): void {
    this.packets[index]?.pick();
  }

  toggleShovel(): void {
    this.shovel.toggle();
  }

  refresh(dt: number): void {
    this.sunIcon.angle += dt * 30;
    for (const p of this.packets) p.refresh();
    this.shovel.refresh();
  }

  private onSunChanged(sun: number): void {
    this.sunText.setText(String(sun));
    this.scene.tweens.add({ targets: this.sunText, scale: { from: 1.3, to: 1 }, duration: 220, ease: 'Back.easeOut' });
  }

  private flashNoSun(): void {
    this.sunText.setColor('#e0452f');
    this.scene.tweens.add({
      targets: this.sunText,
      x: { from: 48, to: 54 },
      duration: 300,
      ease: 'Elastic.easeOut',
      onComplete: () => this.sunText.setColor('#3b2a18'),
    });
  }
}
