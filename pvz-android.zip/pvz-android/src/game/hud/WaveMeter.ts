import Phaser from 'phaser';
import { Tex } from '@/graphics/TextureKeys';
import { t } from '@/i18n/ru';
import { textStyle } from '@/ui/theme';
import type { LevelSession } from '../LevelSession';

const W = 340;
const H = 20;

/**
 * Шкала прогресса уровня: деления по волнам, флажки огромных волн,
 * голова зомби на краю заливки, номер волны и таймер до следующей.
 */
export class WaveMeter extends Phaser.GameObjects.Container {
  private readonly fill: Phaser.GameObjects.Graphics;
  private readonly head: Phaser.GameObjects.Image;
  private readonly title: Phaser.GameObjects.Text;
  private readonly timer: Phaser.GameObjects.Text;
  private readonly flags: { image: Phaser.GameObjects.Image; wave: number }[] = [];
  private shownProgress = 0;
  private lastSpawned = -1;

  constructor(
    scene: Phaser.Scene,
    x: number,
    y: number,
    private readonly session: LevelSession,
  ) {
    super(scene, x, y);
    const total = session.wave.total;
    const bg = scene.add.graphics();
    bg.fillStyle(0x000000, 0.3).fillRoundedRect(-W / 2 - 8, -H / 2 - 4, W + 16, H + 14, 14);
    bg.fillStyle(0x2a1a0b, 1).fillRoundedRect(-W / 2 - 8, -H / 2 - 8, W + 16, H + 16, 14);
    bg.fillStyle(0x5a3d1e, 1).fillRoundedRect(-W / 2, -H / 2, W, H, H / 2);
    this.fill = scene.add.graphics();
    const ticks = scene.add.graphics();
    ticks.fillStyle(0x000000, 0.35);
    for (let i = 1; i < total; i++) ticks.fillRect(-W / 2 + (W * i) / total - 1, -H / 2 + 3, 2, H - 6);

    for (const wave of session.wave.flags) {
      const fx = -W / 2 + (W * (wave + 1)) / total;
      const image = scene.add.image(fx, -H / 2 + 2, Tex.Ui.Flag).setOrigin(0.15, 1);
      this.flags.push({ image, wave });
    }
    this.head = scene.add.image(-W / 2, 0, Tex.Zombie.Head).setScale(0.36);
    this.title = scene.add.text(-W / 2 - 4, -H / 2 - 12, '', textStyle(18)).setOrigin(0, 1);
    this.timer = scene.add.text(W / 2 + 4, -H / 2 - 12, '', textStyle(15)).setOrigin(1, 1);
    this.add([bg, this.fill, ticks, ...this.flags.map((f) => f.image), this.head, this.title, this.timer]);
    scene.add.existing(this);
    this.refresh(0);
  }

  refresh(dt: number): void {
    const w = this.session.wave;
    // Плавно догоняем реальный прогресс, чтобы досрочные волны не дёргали шкалу.
    this.shownProgress += (w.progress - this.shownProgress) * Math.min(1, dt * 4);
    const p = this.shownProgress;
    this.fill.clear();
    if (p > 0.005) {
      const fw = Math.max(H, W * p);
      this.fill.fillStyle(0x7ccf3a, 1).fillRoundedRect(-W / 2, -H / 2, fw, H, H / 2);
      this.fill.fillStyle(0xffffff, 0.28).fillRoundedRect(-W / 2 + 5, -H / 2 + 3, fw - 10, 5, 3);
    }
    this.head.x = -W / 2 + W * p;
    this.head.angle = Math.sin(this.scene.time.now / 200) * 8;

    if (w.spawned !== this.lastSpawned) {
      this.lastSpawned = w.spawned;
      for (const f of this.flags) {
        if (f.wave < w.spawned && f.image.y > -H / 2 - 10) {
          this.scene.tweens.add({ targets: f.image, y: -H / 2 - 12, duration: 400, ease: 'Back.easeOut' });
        }
      }
      this.scene.tweens.add({ targets: this.title, scale: { from: 1.25, to: 1 }, duration: 300, ease: 'Back.easeOut' });
    }

    this.title.setText(w.spawned === 0 ? t.game.approaching : t.game.wave(w.spawned, w.total));
    if (w.nextIn === null) this.timer.setText(t.game.zombiesLeft(w.zombiesLeft));
    else {
      const sec = Math.ceil(w.nextIn);
      this.timer.setText(w.spawned === 0 ? t.game.firstIn(sec) : t.game.nextIn(sec));
    }
    this.timer.setColor(w.nextIn !== null && w.nextIn <= 5 ? '#ffd23f' : '#fff8e7');
  }
}
