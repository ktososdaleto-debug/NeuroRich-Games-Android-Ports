import Phaser from 'phaser';
import { textStyle } from '@/ui/theme';

/** Плашка-подсказка внизу экрана. */
export class HintRibbon extends Phaser.GameObjects.Container {
  private readonly bg: Phaser.GameObjects.Graphics;
  private readonly label: Phaser.GameObjects.Text;

  constructor(scene: Phaser.Scene, x: number, y: number) {
    super(scene, x, y);
    this.bg = scene.add.graphics();
    this.label = scene.add.text(0, 0, '', textStyle(21)).setOrigin(0.5);
    this.add([this.bg, this.label]);
    this.setAlpha(0).setDepth(400);
    scene.add.existing(this);
  }

  show(text: string | null): void {
    this.scene.tweens.killTweensOf([this, this.label]);
    this.label.setScale(1);
    if (!text) {
      this.scene.tweens.add({ targets: this, alpha: 0, duration: 250 });
      return;
    }
    this.label.setText(text);
    const w = this.label.width + 48;
    const h = 50;
    this.bg.clear();
    this.bg.fillStyle(0x000000, 0.25).fillRoundedRect(-w / 2, -h / 2 + 5, w, h, 16);
    this.bg.fillStyle(0x3b2a18, 0.92).fillRoundedRect(-w / 2, -h / 2, w, h, 16);
    this.bg.lineStyle(3, 0x8fe03c, 1).strokeRoundedRect(-w / 2 + 2, -h / 2 + 2, w - 4, h - 4, 14);
    this.setAlpha(0).setScale(0.85);
    this.scene.tweens.add({ targets: this, alpha: 1, scale: 1, duration: 300, ease: 'Back.easeOut' });
    this.scene.tweens.add({ targets: this.label, scale: { from: 1, to: 1.04 }, yoyo: true, repeat: -1, duration: 700, ease: 'Sine.easeInOut' });
  }
}
