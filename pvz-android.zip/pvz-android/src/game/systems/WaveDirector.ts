import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import type { ZombieId } from '@/data/zombies';
import type { LevelSession } from '../LevelSession';
import type { World } from '../World';

interface PendingSpawn {
  type: ZombieId;
  delay: number;
}

/** Если волна перебита раньше срока, следующая приходит через столько секунд. */
const EARLY_NEXT_WAVE = 4;
/** Пауза между сиреной огромной волны и первым зомби. */
const FLAG_LEAD = 3.2;

/**
 * Режиссёр волн: отсчитывает время, запускает волны по сценарию,
 * объявляет огромные и финальную волны и считает прогресс уровня.
 */
export class WaveDirector {
  onVictory?: () => void;
  private spawned = 0;
  private timer: number;
  private gap: number;
  private queue: PendingSpawn[] = [];
  private finished = false;
  private lastRow = -1;

  constructor(
    private readonly world: World,
    private readonly session: LevelSession,
  ) {
    this.timer = this.gap = session.script.firstWaveDelay;
  }

  private get total(): number {
    return this.session.script.waves.length;
  }

  update(dt: number): void {
    const head = this.queue[0];
    if (head) {
      head.delay -= dt;
      if (head.delay <= 0) {
        this.queue.shift();
        this.spawn(head.type);
      }
    }

    if (this.spawned < this.total) {
      this.timer -= dt;
      const waveCleared = this.spawned > 0 && this.queue.length === 0 && this.world.aliveZombies === 0;
      if (waveCleared && this.timer > EARLY_NEXT_WAVE) this.timer = EARLY_NEXT_WAVE;
      if (this.timer <= 0) this.startWave();
    } else if (!this.finished && this.queue.length === 0 && this.world.aliveZombies === 0) {
      this.finished = true;
      this.onVictory?.();
    }
    this.publish();
  }

  private startWave(): void {
    const def = this.session.script.waves[this.spawned];
    this.spawned++;
    const isFinal = this.spawned === this.total;
    let lead = 0.4;
    if (def.flag) {
      this.session.emit('banner', 'huge');
      audio.sfx('siren');
      lead = FLAG_LEAD;
    }
    if (isFinal) {
      this.session.emit('banner', 'final');
      audio.setTempo(1.12);
    }
    def.zombies.forEach((type, i) => {
      this.queue.push({ type, delay: i === 0 ? lead : Phaser.Math.FloatBetween(0.6, 1.7) });
    });
    this.timer = this.gap = this.session.script.waveInterval + def.zombies.length * 1.2;
  }

  /** Зомби идут в наименее загруженные линии, чтобы крепкие не скапливались в одной. */
  private pickRow(): number {
    const rows = this.session.script.rows;
    if (rows.length === 1) return rows[0];
    const loads = rows.map(
      (row) =>
        this.world.zombies.reduce((n, z) => n + (z.alive && z.row === row ? 1 + (z.armorHp > 0 ? 2 : 0) : 0), 0) +
        (row === this.lastRow ? 1.5 : 0) +
        Math.random() * 1.2,
    );
    return rows[loads.indexOf(Math.min(...loads))];
  }

  private spawn(type: ZombieId): void {
    const row = this.pickRow();
    this.lastRow = row;
    this.world.spawnZombie(type, row);
    if (Math.random() < 0.35) audio.sfx('groan');
  }

  private publish(): void {
    const remaining = this.spawned < this.total ? 1 - this.timer / this.gap : 0;
    this.session.wave = {
      ...this.session.wave,
      spawned: this.spawned,
      progress: Math.min(1, (this.spawned + Math.max(0, remaining)) / this.total),
      nextIn: this.spawned < this.total ? Math.max(0, this.timer) : null,
      zombiesLeft: this.world.aliveZombies + this.queue.length,
    };
  }
}
