import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import { Tex } from '@/graphics/TextureKeys';
import { BOARD, cellAt, colX, DEPTH_HIGHLIGHT, DEPTH_TOP, rowCenterY, rowGroundY, type Cell } from '../Board';
import type { LevelSession, Tool } from '../LevelSession';
import { PLANT_VISUALS } from '../view/plantVisuals';
import type { Plant } from '../entities/Plant';
import type { World } from '../World';

/**
 * Посадка и выкапывание: «призрак» растения под курсором, подсветка клетки,
 * полупрозрачное превью на месте посадки и лопата.
 */
export class PlacementController {
  private readonly ghost: Phaser.GameObjects.Image;
  private readonly preview: Phaser.GameObjects.Image;
  private readonly highlight: Phaser.GameObjects.Rectangle;
  private readonly shovel: Phaser.GameObjects.Image;
  private hoverPlant: Plant | null = null;

  constructor(
    private readonly scene: Phaser.Scene,
    private readonly world: World,
    private readonly session: LevelSession,
  ) {
    this.highlight = scene.add
      .rectangle(0, 0, BOARD.cellW - 6, BOARD.cellH - 6, 0xffffff, 0.18)
      .setStrokeStyle(3, 0xffffff, 0.7)
      .setDepth(DEPTH_HIGHLIGHT)
      .setVisible(false);
    this.preview = scene.add.image(0, 0, Tex.Plant.Peashooter).setAlpha(0.45).setDepth(DEPTH_TOP).setVisible(false);
    this.ghost = scene.add.image(0, 0, Tex.Plant.Peashooter).setAlpha(0.9).setDepth(DEPTH_TOP + 5).setVisible(false);
    this.shovel = scene.add.image(0, 0, Tex.Icon.Shovel).setOrigin(0.25, 0.8).setDepth(DEPTH_TOP + 6).setVisible(false);

    scene.input.on(Phaser.Input.Events.POINTER_MOVE, this.onMove, this);
    scene.input.on(Phaser.Input.Events.POINTER_DOWN, this.onDown, this);
    session.on('tool-changed', this.onToolChanged, this);
  }

  private onToolChanged(tool: Tool): void {
    this.setHoverPlant(null);
    this.ghost.setVisible(false);
    this.preview.setVisible(false);
    this.highlight.setVisible(false);
    this.shovel.setVisible(false);
    if (tool?.kind === 'plant') {
      const v = PLANT_VISUALS[tool.plant]!;
      for (const img of [this.ghost, this.preview]) img.setTexture(v.key).setOrigin(v.origin.x, v.origin.y).setScale(v.scale);
    }
    this.onMove(this.scene.input.activePointer);
  }

  private onMove(pointer: Phaser.Input.Pointer): void {
    const tool = this.session.tool;
    if (!tool) return;
    const { worldX: x, worldY: y } = pointer;
    const cell = cellAt(x, y);

    if (tool.kind === 'plant') {
      this.ghost.setPosition(x, y + 34).setVisible(true);
      const valid = cell !== null && this.world.canPlant(cell);
      this.highlight.setVisible(valid);
      this.preview.setVisible(valid);
      if (valid) {
        this.highlight.setPosition(colX(cell.col), rowCenterY(cell.row));
        this.preview.setPosition(colX(cell.col), rowGroundY(cell.row));
      }
    } else {
      this.shovel.setPosition(x, y).setVisible(true);
      this.setHoverPlant(cell ? this.world.plantAt(cell) ?? null : null);
    }
  }

  private onDown(pointer: Phaser.Input.Pointer, over: Phaser.GameObjects.GameObject[]): void {
    if (!this.session.canInteract) return;
    const tool = this.session.tool;
    if (pointer.rightButtonDown()) {
      if (tool) this.session.selectTool(null);
      return;
    }
    // Клик по солнцу не должен сажать растение под ним.
    if (!tool || over.length > 0) return;
    const cell: Cell | null = cellAt(pointer.worldX, pointer.worldY);

    if (tool.kind === 'plant') {
      if (cell && this.world.canPlant(cell)) {
        this.world.addPlant(tool.plant, cell);
        this.session.commitPlant(tool.plant);
      } else if (cell) {
        audio.sfx('error');
      } else {
        this.session.selectTool(null);
      }
      return;
    }

    const plant = cell ? this.world.plantAt(cell) : undefined;
    if (plant) plant.dig();
    this.session.selectTool(null);
  }

  private setHoverPlant(plant: Plant | null): void {
    if (this.hoverPlant === plant) return;
    if (this.hoverPlant?.alive) this.hoverPlant.setHighlight(false);
    this.hoverPlant = plant;
    plant?.setHighlight(true);
  }
}
