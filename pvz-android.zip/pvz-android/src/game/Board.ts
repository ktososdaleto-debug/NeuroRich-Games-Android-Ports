import { GAME_WIDTH } from '@/config/constants';

/** Геометрия лужайки 9×5. Все координаты — в мировых пикселях игровой сцены. */
export const BOARD = { x: 250, y: 118, cols: 9, rows: 5, cellW: 92, cellH: 102 } as const;

export const BOARD_RIGHT = BOARD.x + BOARD.cols * BOARD.cellW;
export const BOARD_BOTTOM = BOARD.y + BOARD.rows * BOARD.cellH;
/** Мир шире экрана: справа улица, куда камера заглядывает в начале уровня. */
export const WORLD_WIDTH = GAME_WIDTH + 400;
export const HOUSE_X = 168;
export const MOWER_X = 212;
export const ZOMBIE_SPAWN_X = BOARD_RIGHT + 70;
/** Растения стреляют по зомби, только когда тот ступил на лужайку. */
export const TARGETABLE_X = BOARD_RIGHT + 30;

export interface Cell {
  col: number;
  row: number;
}

export const colX = (col: number): number => BOARD.x + (col + 0.5) * BOARD.cellW;
export const rowCenterY = (row: number): number => BOARD.y + (row + 0.5) * BOARD.cellH;
/** Линия «земли» в ряду — сюда ставятся растения и ходят зомби. */
export const rowGroundY = (row: number): number => BOARD.y + (row + 1) * BOARD.cellH - 14;

export function cellAt(x: number, y: number): Cell | null {
  const col = Math.floor((x - BOARD.x) / BOARD.cellW);
  const row = Math.floor((y - BOARD.y) / BOARD.cellH);
  if (col < 0 || row < 0 || col >= BOARD.cols || row >= BOARD.rows) return null;
  return { col, row };
}

export const cellKey = (cell: Cell): string => `${cell.col}:${cell.row}`;

/** Слои внутри ряда: нижние ряды рисуются поверх верхних. */
export const Layer = { Mower: 5, Plant: 20, Pea: 40, Zombie: 50 } as const;
export const depthOf = (row: number, layer: number): number => 100 + row * 100 + layer;
export const DEPTH_HIGHLIGHT = 90;
export const DEPTH_SUN = 1000;
export const DEPTH_TOP = 1100;
