import Phaser from 'phaser';
import { GAME_HEIGHT, GAME_WIDTH } from '@/config/constants';
import { mulberry32 } from '@/utils/random';
import { circle, ellipse, linearGradient, makeCanvasTexture, radialGradient } from '../canvas';
import { Tex } from '../TextureKeys';

type Wave = [amplitude: number, frequency: number, phase: number];

export const LAWN_HEIGHT = 250;

function hillY(x: number, w: number, base: number, waves: Wave[]): number {
  return waves.reduce((y, [amp, freq, phase]) => y + amp * Math.sin((Math.PI * 2 * freq * x) / w + phase), base);
}

function drawHills(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  base: number,
  waves: Wave[],
  colors: [string, string],
  ridge: string,
): void {
  ctx.beginPath();
  ctx.moveTo(0, h);
  for (let x = 0; x <= w; x += 4) ctx.lineTo(x, hillY(x, w, base, waves));
  ctx.lineTo(w, h);
  ctx.closePath();
  ctx.fillStyle = linearGradient(ctx, 0, base - 50, 0, h, colors);
  ctx.fill();

  ctx.beginPath();
  for (let x = 0; x <= w; x += 4) {
    const y = hillY(x, w, base, waves) + 3;
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = ridge;
  ctx.lineWidth = 4;
  ctx.stroke();
}

function drawCloud(ctx: CanvasRenderingContext2D, puffs: number[][], dy = 0): void {
  ctx.beginPath();
  for (const [x, y, r] of puffs) {
    ctx.moveTo(x + r, y + dy);
    ctx.arc(x, y + dy, r, 0, Math.PI * 2);
  }
}

const CLOUD_SHAPES: number[][][] = [
  [[60, 80, 40], [110, 60, 52], [170, 58, 46], [215, 78, 38], [140, 88, 40]],
  [[50, 66, 32], [95, 48, 40], [140, 60, 34], [100, 72, 30]],
  [[60, 90, 38], [115, 66, 50], [180, 54, 58], [245, 72, 46], [290, 92, 32], [170, 96, 40]],
];

export function generateEnvironmentTextures(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Env.Sky, GAME_WIDTH, GAME_HEIGHT, (ctx, w, h) => {
    ctx.fillStyle = linearGradient(ctx, 0, 0, 0, h * 0.7, ['#2f97e6', '#7cc9ff', '#d9f3ff']);
    ctx.fillRect(0, 0, w, h);
  });

  makeCanvasTexture(tm, Tex.Env.SunRays, 380, 380, (ctx, w) => {
    const c = w / 2;
    const n = 16;
    ctx.fillStyle = radialGradient(ctx, c, c, 30, c, c, c, ['rgba(255,240,150,0.6)', 'rgba(255,240,150,0)']);
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * Math.PI * 2;
      const a1 = a0 + Math.PI / n;
      const r = i % 2 === 0 ? c : c * 0.82;
      ctx.beginPath();
      ctx.moveTo(c, c);
      ctx.lineTo(c + Math.cos(a0) * r, c + Math.sin(a0) * r);
      ctx.lineTo(c + Math.cos(a1) * r, c + Math.sin(a1) * r);
      ctx.closePath();
      ctx.fill();
    }
  });

  makeCanvasTexture(tm, Tex.Env.Sun, 200, 200, (ctx) => {
    const cx = 100;
    const cy = 100;
    ctx.fillStyle = radialGradient(ctx, cx, cy, 40, cx, cy, 100, ['rgba(255,236,140,0.75)', 'rgba(255,236,140,0)']);
    circle(ctx, cx, cy, 100);
    ctx.fill();
    ctx.fillStyle = radialGradient(ctx, cx - 18, cy - 20, 6, cx, cy, 56, ['#fffbd1', '#ffd84a', '#ffaa1c']);
    circle(ctx, cx, cy, 56);
    ctx.fill();
    ctx.strokeStyle = 'rgba(214,128,0,0.6)';
    ctx.lineWidth = 3;
    ctx.stroke();
    // мордашка
    ctx.fillStyle = '#8a4b06';
    ellipse(ctx, cx - 17, cy - 8, 5, 8);
    ctx.fill();
    ellipse(ctx, cx + 17, cy - 8, 5, 8);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    circle(ctx, cx - 15, cy - 11, 2);
    ctx.fill();
    circle(ctx, cx + 19, cy - 11, 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,110,70,0.4)';
    circle(ctx, cx - 30, cy + 8, 8);
    ctx.fill();
    circle(ctx, cx + 30, cy + 8, 8);
    ctx.fill();
    ctx.strokeStyle = '#8a4b06';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(cx, cy + 4, 16, 0.15 * Math.PI, 0.85 * Math.PI);
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.Env.Moon, 170, 170, (ctx) => {
    const c = 85;
    ctx.fillStyle = radialGradient(ctx, c, c, 30, c, c, 85, ['rgba(220,225,255,0.55)', 'rgba(220,225,255,0)']);
    circle(ctx, c, c, 85);
    ctx.fill();
    ctx.fillStyle = radialGradient(ctx, c - 14, c - 16, 4, c, c, 46, ['#ffffff', '#f1eed2', '#cfcaa6']);
    circle(ctx, c, c, 46);
    ctx.fill();
    ctx.fillStyle = 'rgba(150,140,100,0.3)';
    for (const [x, y, r] of [[-14, -8, 9], [12, 10, 12], [16, -18, 6], [-10, 20, 6]]) {
      circle(ctx, c + x, c + y, r);
      ctx.fill();
    }
  });

  CLOUD_SHAPES.forEach((puffs, i) => {
    const w = Math.max(...puffs.map(([x, , r]) => x + r)) + 10;
    const h = Math.max(...puffs.map(([, y, r]) => y + r)) + 14;
    makeCanvasTexture(tm, Tex.Env.Clouds[i], w, h, (ctx) => {
      ctx.fillStyle = 'rgba(90,140,190,0.22)';
      drawCloud(ctx, puffs, 7);
      ctx.fill();
      ctx.fillStyle = linearGradient(ctx, 0, 0, 0, h, ['#ffffff', '#ffffff', '#d4e9f8']);
      drawCloud(ctx, puffs);
      ctx.fill();
    });
  });

  makeCanvasTexture(tm, Tex.Env.HillsFar, GAME_WIDTH, 260, (ctx, w, h) => {
    const base = 70;
    const waves: Wave[] = [[28, 2, 0.6], [14, 5, 2.1]];
    drawHills(ctx, w, h, base, waves, ['#86d063', '#5aa83f'], 'rgba(220,255,190,0.45)');
    for (const x of [90, 260, 470, 690, 880, 1100, 1220]) {
      const y = hillY(x, w, base, waves) + 6;
      ctx.fillStyle = '#6b4a2a';
      ctx.fillRect(x - 3, y - 8, 6, 14);
      ctx.fillStyle = '#4f9e3a';
      circle(ctx, x, y - 20, 16);
      ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      circle(ctx, x - 5, y - 25, 7);
      ctx.fill();
    }
    // воздушная дымка
    ctx.globalCompositeOperation = 'source-atop';
    ctx.fillStyle = linearGradient(ctx, 0, 0, 0, h, ['rgba(200,235,255,0.35)', 'rgba(200,235,255,0)']);
    ctx.fillRect(0, 0, w, h);
    ctx.globalCompositeOperation = 'source-over';
  });

  makeCanvasTexture(tm, Tex.Env.HillsNear, GAME_WIDTH, 200, (ctx, w, h) => {
    const base = 62;
    const waves: Wave[] = [[22, 3, 1.3], [10, 7, 0.2]];
    drawHills(ctx, w, h, base, waves, ['#62bd48', '#3e8f2e'], 'rgba(200,255,170,0.45)');
    const rnd = mulberry32(7);
    for (const x of [110, 330, 540, 770, 990, 1170]) {
      const y = hillY(x, w, base, waves) + 14;
      for (let i = 0; i < 3; i++) {
        const bx = x + (i - 1) * 24;
        const r = 22 + rnd() * 12;
        ctx.fillStyle = '#2f8a28';
        circle(ctx, bx, y - r * 0.5, r);
        ctx.fill();
        ctx.fillStyle = 'rgba(160,230,120,0.35)';
        circle(ctx, bx - r * 0.3, y - r * 0.85, r * 0.45);
        ctx.fill();
      }
    }
  });

  makeCanvasTexture(tm, Tex.Env.Fence, GAME_WIDTH, 110, (ctx, w, h) => {
    ctx.fillStyle = '#c9b48a';
    ctx.fillRect(0, 34, w, 10);
    ctx.fillRect(0, 76, w, 10);
    ctx.fillStyle = 'rgba(80,60,30,0.35)';
    ctx.fillRect(0, 42, w, 2);
    ctx.fillRect(0, 84, w, 2);
    for (let x = 0; x < w; x += 40) {
      const px = x + 5;
      ctx.beginPath();
      ctx.moveTo(px, h - 6);
      ctx.lineTo(px, 22);
      ctx.lineTo(px + 15, 6);
      ctx.lineTo(px + 30, 22);
      ctx.lineTo(px + 30, h - 6);
      ctx.closePath();
      ctx.fillStyle = linearGradient(ctx, px, 0, px + 30, 0, ['#fff6e0', '#f0e2bf', '#d8c59a']);
      ctx.fill();
      ctx.strokeStyle = '#9c8558';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }
    ctx.fillStyle = linearGradient(ctx, 0, h - 16, 0, h, ['rgba(0,0,0,0)', 'rgba(0,0,0,0.25)']);
    ctx.fillRect(0, h - 16, w, 16);
  });

  makeCanvasTexture(tm, Tex.Env.Lawn, GAME_WIDTH, LAWN_HEIGHT, (ctx, w, h) => {
    const cols = 16;
    const rows = 3;
    const tw = w / cols;
    const th = h / rows;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        ctx.fillStyle = (r + c) % 2 === 0 ? '#64bd3e' : '#56ad34';
        ctx.fillRect(c * tw, r * th, tw + 1, th + 1);
      }
    }
    const rnd = mulberry32(42);
    ctx.lineWidth = 2;
    for (let i = 0; i < 1600; i++) {
      const x = rnd() * w;
      const y = 10 + rnd() * (h - 10);
      ctx.strokeStyle = rnd() > 0.5 ? 'rgba(30,90,20,0.3)' : 'rgba(170,235,120,0.3)';
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + (rnd() - 0.5) * 6, y - 4 - rnd() * 6);
      ctx.stroke();
    }
    ctx.fillStyle = linearGradient(ctx, 0, 0, 0, 30, ['rgba(0,40,0,0.38)', 'rgba(0,40,0,0)']);
    ctx.fillRect(0, 0, w, 30);
    ctx.fillStyle = linearGradient(ctx, 0, h - 70, 0, h, ['rgba(0,30,0,0)', 'rgba(0,30,0,0.3)']);
    ctx.fillRect(0, h - 70, w, 70);
  });

  makeCanvasTexture(tm, Tex.Env.Tombstone, 80, 100, (ctx) => {
    ctx.fillStyle = '#3f8f28';
    ellipse(ctx, 40, 90, 36, 8);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(12, 90);
    ctx.lineTo(12, 40);
    ctx.arc(40, 40, 28, Math.PI, 0);
    ctx.lineTo(68, 90);
    ctx.closePath();
    ctx.fillStyle = linearGradient(ctx, 12, 0, 68, 0, ['#b3bcc1', '#8d969b', '#6a7378']);
    ctx.fill();
    ctx.strokeStyle = '#3c4347';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fillStyle = 'rgba(40,46,50,0.65)';
    ctx.font = '900 17px Rubik, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('RIP', 40, 52);
    ctx.strokeStyle = 'rgba(40,46,50,0.5)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(52, 62);
    ctx.lineTo(46, 70);
    ctx.lineTo(50, 76);
    ctx.lineTo(44, 86);
    ctx.stroke();
    ctx.strokeStyle = '#2f7d1c';
    ctx.lineWidth = 3;
    for (const x of [8, 16, 62, 70]) {
      ctx.beginPath();
      ctx.moveTo(x, 92);
      ctx.lineTo(x - 3, 82);
      ctx.moveTo(x, 92);
      ctx.lineTo(x + 4, 83);
      ctx.stroke();
    }
  });
}
