import Phaser from 'phaser';
import { mulberry32 } from '@/utils/random';
import { circle, ellipse, linearGradient, makeCanvasTexture, roundRect, type TextureRef } from '../canvas';

export type ButtonVariant = 'wood' | 'green' | 'red' | 'stone' | 'gold';
export type PanelVariant = 'wood' | 'paper';
export type CardState = 'open' | 'done' | 'locked';

interface Palette {
  top: string;
  bottom: string;
  edge: string;
  outline: string;
}

const PALETTES: Record<ButtonVariant, Palette> = {
  wood: { top: '#dca464', bottom: '#a0622e', edge: '#6b3e18', outline: '#3b2410' },
  green: { top: '#a2ec60', bottom: '#4aa52a', edge: '#2e7016', outline: '#1d4a0c' },
  red: { top: '#ff8f72', bottom: '#d83a2a', edge: '#8e1e14', outline: '#5a0e08' },
  stone: { top: '#c9cfd5', bottom: '#868e96', edge: '#5a6168', outline: '#2f3438' },
  gold: { top: '#ffe57e', bottom: '#f0a91c', edge: '#b06a00', outline: '#6a3c00' },
};

const PAD = 8;
const SHADOW = 6;

function woodGrain(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, seed: number, alpha = 0.16): void {
  const rnd = mulberry32(seed);
  ctx.save();
  ctx.strokeStyle = `rgba(70,35,10,${alpha})`;
  ctx.lineWidth = 2;
  const lines = Math.max(2, Math.floor(h / 12));
  for (let i = 0; i < lines; i++) {
    const ly = y + ((i + 0.5) / lines) * h + (rnd() - 0.5) * 4;
    ctx.beginPath();
    ctx.moveTo(x + rnd() * 20, ly);
    ctx.bezierCurveTo(x + w * 0.3, ly + (rnd() - 0.5) * 6, x + w * 0.7, ly + (rnd() - 0.5) * 6, x + w - rnd() * 20, ly);
    ctx.stroke();
  }
  ctx.restore();
}

function nail(ctx: CanvasRenderingContext2D, x: number, y: number): void {
  circle(ctx, x, y, 4);
  ctx.fillStyle = '#4a3020';
  ctx.fill();
  circle(ctx, x - 1, y - 1, 1.6);
  ctx.fillStyle = 'rgba(255,255,255,0.45)';
  ctx.fill();
}

/** Кнопка с объёмным «нижним краем», бликом и тенью. Кэшируется по варианту и размеру. */
export function ensureButtonTexture(tm: Phaser.Textures.TextureManager, variant: ButtonVariant, w: number, h: number): TextureRef {
  const key = `btn-${variant}-${w}x${h}`;
  const tw = w + PAD * 2;
  const th = h + PAD * 2 + SHADOW;
  makeCanvasTexture(tm, key, tw, th, (ctx) => {
    const p = PALETTES[variant];
    const x = PAD;
    const y = PAD;
    const r = Math.min(18, h / 2.6);
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    roundRect(ctx, x, y + SHADOW, w, h, r);
    ctx.fill();
    ctx.fillStyle = p.edge;
    roundRect(ctx, x, y, w, h, r);
    ctx.fill();
    ctx.fillStyle = linearGradient(ctx, 0, y, 0, y + h - 6, [p.top, p.bottom]);
    roundRect(ctx, x + 3, y + 3, w - 6, h - 10, Math.max(2, r - 3));
    ctx.fill();
    if (variant === 'wood') {
      woodGrain(ctx, x + 6, y + 6, w - 12, h - 16, w * 31 + h);
      nail(ctx, x + 14, y + (h - 6) / 2);
      nail(ctx, x + w - 14, y + (h - 6) / 2);
    }
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    roundRect(ctx, x + 8, y + 6, w - 16, (h - 10) * 0.4, Math.max(2, r - 6));
    ctx.fill();
    ctx.strokeStyle = p.outline;
    ctx.lineWidth = 3;
    roundRect(ctx, x + 1.5, y + 1.5, w - 3, h - 3, r);
    ctx.stroke();
  });
  return { key, originX: (PAD + w / 2) / tw, originY: (PAD + h / 2) / th };
}

export function ensureRoundButtonTexture(tm: Phaser.Textures.TextureManager, variant: ButtonVariant, size: number): TextureRef {
  const key = `btn-round-${variant}-${size}`;
  const tw = size + PAD * 2;
  const th = size + PAD * 2 + SHADOW;
  makeCanvasTexture(tm, key, tw, th, (ctx) => {
    const p = PALETTES[variant];
    const c = PAD + size / 2;
    const r = size / 2;
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    circle(ctx, c, c + SHADOW, r);
    ctx.fill();
    ctx.fillStyle = p.edge;
    circle(ctx, c, c, r);
    ctx.fill();
    ctx.fillStyle = linearGradient(ctx, 0, c - r, 0, c + r, [p.top, p.bottom]);
    circle(ctx, c, c - 3, r - 4);
    ctx.fill();
    if (variant === 'wood') woodGrain(ctx, c - r + 6, c - r + 4, size - 12, size - 14, size * 7);
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ellipse(ctx, c, c - r * 0.45, r * 0.6, r * 0.28);
    ctx.fill();
    ctx.strokeStyle = p.outline;
    ctx.lineWidth = 3;
    circle(ctx, c, c, r - 1.5);
    ctx.stroke();
  });
  return { key, originX: 0.5, originY: (PAD + size / 2) / th };
}

/** Деревянная доска из планок в рамке либо пергамент. */
export function ensurePanelTexture(tm: Phaser.Textures.TextureManager, variant: PanelVariant, w: number, h: number): TextureRef {
  const key = `panel-${variant}-${w}x${h}`;
  const P = 12;
  const S = 10;
  const tw = w + P * 2;
  const th = h + P * 2 + S;
  makeCanvasTexture(tm, key, tw, th, (ctx) => {
    const x = P;
    const y = P;
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    roundRect(ctx, x + 4, y + S, w - 8, h, 24);
    ctx.fill();

    if (variant === 'wood') {
      ctx.fillStyle = linearGradient(ctx, 0, y, 0, y + h, ['#8a5428', '#6b3e1a']);
      roundRect(ctx, x, y, w, h, 24);
      ctx.fill();
      const frame = 16;
      const ix = x + frame;
      const iy = y + frame;
      const iw = w - frame * 2;
      const ih = h - frame * 2;
      ctx.save();
      roundRect(ctx, ix, iy, iw, ih, 12);
      ctx.clip();
      const planks = Math.max(2, Math.round(ih / 64));
      const ph = ih / planks;
      const tones = [['#c99258', '#b07a43'], ['#d29c62', '#b9834b'], ['#c08a50', '#a8723d']];
      for (let i = 0; i < planks; i++) {
        const [a, b] = tones[i % tones.length];
        ctx.fillStyle = linearGradient(ctx, 0, iy + i * ph, 0, iy + (i + 1) * ph, [a, b]);
        ctx.fillRect(ix, iy + i * ph, iw, ph);
        woodGrain(ctx, ix, iy + i * ph + 4, iw, ph - 8, i * 97 + w);
        ctx.fillStyle = 'rgba(60,30,10,0.45)';
        ctx.fillRect(ix, iy + (i + 1) * ph - 2, iw, 3);
      }
      ctx.strokeStyle = 'rgba(0,0,0,0.28)';
      ctx.lineWidth = 10;
      roundRect(ctx, ix, iy, iw, ih, 12);
      ctx.stroke();
      ctx.restore();
      ctx.strokeStyle = 'rgba(255,220,170,0.35)';
      ctx.lineWidth = 2;
      roundRect(ctx, x + 4, y + 4, w - 8, h - 8, 20);
      ctx.stroke();
      for (const [nx, ny] of [[x + 9, y + 9], [x + w - 9, y + 9], [x + 9, y + h - 9], [x + w - 9, y + h - 9]]) nail(ctx, nx, ny);
    } else {
      ctx.fillStyle = linearGradient(ctx, 0, y, 0, y + h, ['#fff6dc', '#f0dcaa']);
      roundRect(ctx, x, y, w, h, 22);
      ctx.fill();
      ctx.strokeStyle = 'rgba(156,116,66,0.45)';
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 6]);
      roundRect(ctx, x + 12, y + 12, w - 24, h - 24, 14);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    ctx.strokeStyle = '#3b2410';
    ctx.lineWidth = 4;
    roundRect(ctx, x + 2, y + 2, w - 4, h - 4, 22);
    ctx.stroke();
  });
  return { key, originX: (P + w / 2) / tw, originY: (P + h / 2) / th };
}

const CARD_COLORS: Record<CardState, { band: string; body: [string, string]; outline: string }> = {
  open: { band: '#6fbf3a', body: ['#fbedc2', '#e7cf91'], outline: '#5a4220' },
  done: { band: '#f0b429', body: ['#fbedc2', '#e7cf91'], outline: '#6a4410' },
  locked: { band: '#7d756a', body: ['#b8b0a2', '#958d7f'], outline: '#4a443b' },
};

/** Карточка уровня в стиле пакетика семян. */
export function ensureCardTexture(tm: Phaser.Textures.TextureManager, state: CardState, w: number, h: number): TextureRef {
  const key = `card-${state}-${w}x${h}`;
  const tw = w + PAD * 2;
  const th = h + PAD * 2 + SHADOW;
  makeCanvasTexture(tm, key, tw, th, (ctx) => {
    const c = CARD_COLORS[state];
    const x = PAD;
    const y = PAD;
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    roundRect(ctx, x, y + SHADOW, w, h, 14);
    ctx.fill();
    ctx.save();
    roundRect(ctx, x, y, w, h, 14);
    ctx.clip();
    ctx.fillStyle = linearGradient(ctx, 0, y, 0, y + h, c.body);
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = c.band;
    ctx.fillRect(x, y, w, 30);
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.fillRect(x, y, w, 10);
    ctx.fillStyle = 'rgba(0,0,0,0.18)';
    ctx.fillRect(x, y + 28, w, 3);
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,0.45)';
    ctx.lineWidth = 2;
    roundRect(ctx, x + 6, y + 36, w - 12, h - 42, 8);
    ctx.stroke();
    ctx.strokeStyle = c.outline;
    ctx.lineWidth = 3.5;
    roundRect(ctx, x + 1.5, y + 1.5, w - 3, h - 3, 13);
    ctx.stroke();
  });
  return { key, originX: (PAD + w / 2) / tw, originY: (PAD + h / 2) / th };
}
