import Phaser from 'phaser';

export type DrawFn = (ctx: CanvasRenderingContext2D, width: number, height: number) => void;

/** Ключ текстуры и точка, вокруг которой её нужно центрировать (учитывает поля под тень). */
export interface TextureRef {
  key: string;
  originX: number;
  originY: number;
}

/** Рисует текстуру через Canvas 2D один раз и кэширует её в TextureManager. */
export function makeCanvasTexture(
  textures: Phaser.Textures.TextureManager,
  key: string,
  width: number,
  height: number,
  draw: DrawFn,
): string {
  if (textures.exists(key)) return key;
  const w = Math.ceil(width);
  const h = Math.ceil(height);
  const texture = textures.createCanvas(key, w, h);
  if (!texture) throw new Error(`Failed to create canvas texture "${key}"`);
  const ctx = texture.getContext();
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  draw(ctx, w, h);
  texture.refresh();
  return key;
}

export function circle(ctx: CanvasRenderingContext2D, x: number, y: number, r: number): void {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
}

export function ellipse(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, rotation = 0): void {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, rotation, 0, Math.PI * 2);
}

export function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
}

export function linearGradient(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  stops: string[],
): CanvasGradient {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  stops.forEach((c, i) => g.addColorStop(stops.length === 1 ? 0 : i / (stops.length - 1), c));
  return g;
}

export function radialGradient(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  r0: number,
  x1: number,
  y1: number,
  r1: number,
  stops: string[],
): CanvasGradient {
  const g = ctx.createRadialGradient(x0, y0, r0, x1, y1, r1);
  stops.forEach((c, i) => g.addColorStop(stops.length === 1 ? 0 : i / (stops.length - 1), c));
  return g;
}

export function starPath(ctx: CanvasRenderingContext2D, cx: number, cy: number, outer: number, inner: number, points = 5): void {
  ctx.beginPath();
  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 === 0 ? outer : inner;
    const a = -Math.PI / 2 + (i * Math.PI) / points;
    const x = cx + Math.cos(a) * r;
    const y = cy + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

/** Обводка-«контур»: широкая тёмная линия, поверх неё узкая светлая. */
export function doubleStroke(ctx: CanvasRenderingContext2D, outer: string, inner: string, width: number): void {
  ctx.strokeStyle = outer;
  ctx.lineWidth = width;
  ctx.stroke();
  ctx.strokeStyle = inner;
  ctx.lineWidth = width * 0.5;
  ctx.stroke();
}
