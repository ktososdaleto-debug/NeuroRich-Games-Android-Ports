import Phaser from 'phaser';
import { CENTER_X, CENTER_Y } from '@/config/constants';
import { SceneKeys } from '@/core/SceneKeys';
import { TEXTURE_GENERATORS } from '@/graphics/textures';
import { t } from '@/i18n/ru';
import { textStyle } from '@/ui/theme';

const BAR_W = 460;
const BAR_H = 26;

/**
 * Загрузка ресурсов. Сейчас вся графика процедурная; реальные ассеты
 * (спрайты, звуки, атласы) добавляются в preload() через this.load.*.
 */
export class PreloadScene extends Phaser.Scene {
  private bar!: Phaser.GameObjects.Graphics;

  constructor() {
    super(SceneKeys.Preload);
  }

  preload(): void {
    this.add.text(CENTER_X, CENTER_Y - 50, t.loading, textStyle(36)).setOrigin(0.5);
    const frame = this.add.graphics();
    frame.fillStyle(0x3b2a18, 1).fillRoundedRect(CENTER_X - BAR_W / 2 - 5, CENTER_Y - 5, BAR_W + 10, BAR_H + 10, 18);
    frame.fillStyle(0x24170b, 1).fillRoundedRect(CENTER_X - BAR_W / 2, CENTER_Y, BAR_W, BAR_H, 13);
    this.bar = this.add.graphics();
    this.drawBar(0);

    // Файловые ассеты займут первую половину полосы.
    this.load.on(Phaser.Loader.Events.PROGRESS, (p: number) => this.drawBar(p * 0.5));
  }

  create(): void {
    const steps = TEXTURE_GENERATORS;
    let done = 0;
    this.time.addEvent({
      delay: 16,
      repeat: steps.length - 1,
      callback: () => {
        steps[done](this.textures);
        done++;
        this.drawBar(0.5 + (0.5 * done) / steps.length);
        if (done === steps.length) this.time.delayedCall(200, () => this.finish());
      },
    });
  }

  private drawBar(progress: number): void {
    const w = Math.max(BAR_H, BAR_W * progress);
    this.bar.clear();
    this.bar.fillStyle(0x5fbf2e, 1).fillRoundedRect(CENTER_X - BAR_W / 2, CENTER_Y, w, BAR_H, 13);
    this.bar.fillStyle(0xffffff, 0.25).fillRoundedRect(CENTER_X - BAR_W / 2 + 6, CENTER_Y + 4, w - 12, 7, 4);
  }

  private finish(): void {
    this.scene.launch(SceneKeys.MenuBackground);
    this.scene.launch(SceneKeys.HudOverlay);
    this.scene.start(SceneKeys.MainMenu);
  }
}
