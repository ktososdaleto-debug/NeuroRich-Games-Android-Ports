import { CENTER_X, GAME_HEIGHT, GAME_VERSION, GAME_WIDTH } from '@/config/constants';
import { SceneKeys } from '@/core/SceneKeys';
import { saves } from '@/core/SaveManager';
import { getNextLevel } from '@/core/progress';
import { audio } from '@/audio/AudioManager';
import { hasLevelScript } from '@/data/levelScripts';
import { Tex } from '@/graphics/TextureKeys';
import type { ButtonVariant } from '@/graphics/textures/ui';
import { t } from '@/i18n/ru';
import { Button } from '@/ui/Button';
import { openCreateProfileDialog } from '@/ui/dialogs';
import { showToast } from '@/ui/Toast';
import { textStyle } from '@/ui/theme';
import { MenuScene } from './MenuScene';
import { GameTitle } from './components/GameTitle';

interface MenuItem {
  label: string;
  icon: string;
  y: number;
  variant?: ButtonVariant;
  width?: number;
  height?: number;
  action: () => void;
}

export class MainMenuScene extends MenuScene {
  private title!: GameTitle;

  constructor() {
    super(SceneKeys.MainMenu);
  }

  create(): void {
    this.initMenu('day');
    audio.playMusic();

    this.title = new GameTitle(this, CENTER_X, 88);
    this.root.add(this.title);
    this.title.playIntro();

    const save = saves.active;
    const items: MenuItem[] = [
      {
        label: save ? t.menu.continue(getNextLevel(save).id) : t.menu.adventure,
        icon: Tex.Icon.Play,
        y: 362,
        variant: 'green',
        width: 400,
        height: 84,
        action: () => this.startAdventure(),
      },
      { label: t.menu.levels, icon: Tex.Icon.Levels, y: 452, action: () => this.goTo(SceneKeys.LevelSelect) },
      { label: t.menu.saves, icon: Tex.Icon.Save, y: 526, action: () => this.goTo(SceneKeys.Saves) },
      { label: t.menu.settings, icon: Tex.Icon.Gear, y: 600, action: () => this.goTo(SceneKeys.Settings) },
    ];

    items.forEach((item, i) => {
      const button = new Button(this, CENTER_X, item.y + 70, {
        label: item.label,
        icon: item.icon,
        variant: item.variant ?? 'wood',
        width: item.width ?? 340,
        height: item.height ?? 62,
      }).onClick(item.action);
      button.setAlpha(0);
      this.root.add(button);
      this.tweens.add({ targets: button, y: item.y, alpha: 1, delay: 450 + i * 90, duration: 520, ease: 'Back.easeOut' });
    });

    this.createProfileTag();

    const version = this.add
      .text(GAME_WIDTH - 16, GAME_HEIGHT - 12, t.menu.version(GAME_VERSION), textStyle(16))
      .setOrigin(1, 1)
      .setAlpha(0.8);
    this.root.add(version);
  }

  update(time: number): void {
    this.title.update(time);
  }

  private createProfileTag(): void {
    const save = saves.active;
    const tag = new Button(this, 160, 48, {
      label: save?.name ?? t.menu.noProfile,
      icon: Tex.Icon.User,
      width: 280,
      height: 54,
      fontSize: 22,
    }).onClick(() => this.goTo(SceneKeys.Saves));
    tag.setAngle(-2).setAlpha(0);
    tag.y = -40;
    this.root.add(tag);
    this.tweens.add({ targets: tag, y: 48, alpha: 1, delay: 900, duration: 600, ease: 'Bounce.easeOut' });
  }

  private startAdventure(): void {
    const save = saves.active;
    if (save) {
      this.startLevel(getNextLevel(save).id);
      return;
    }
    const slot = saves.firstEmptySlot();
    if (slot === null) {
      showToast(this, t.saves.noFreeSlots);
      this.goTo(SceneKeys.Saves);
      return;
    }
    openCreateProfileDialog(this, slot, (created) => {
      this.time.delayedCall(250, () => this.startLevel(getNextLevel(created).id));
    });
  }

  private startLevel(levelId: string): void {
    if (!hasLevelScript(levelId)) {
      this.goTo(SceneKeys.LevelSelect);
      return;
    }
    this.goTo(SceneKeys.Game, { levelId }, { fadeToBlack: true });
  }
}
