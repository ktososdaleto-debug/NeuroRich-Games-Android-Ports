import Phaser from 'phaser';
import { ZombieRig } from '@/game/view/ZombieRig';

/** Декоративный зомби меню: ковыляет, получает горошины и красиво падает. */
export class MenuZombie extends ZombieRig {
  hp = 10;
  alive = true;
  private speed = 16;

  constructor(scene: Phaser.Scene, x: number, y: number) {
    super(scene, x, y);
  }

  /** Точка, куда попадает горошина (мировые координаты). */
  get hitX(): number {
    return this.x - 22;
  }

  respawn(x: number): void {
    this.scene.tweens.killTweensOf(this);
    this.x = x;
    this.hp = Phaser.Math.Between(8, 12);
    this.speed = Phaser.Math.FloatBetween(13, 20);
    this.alive = true;
    this.setAngle(0).setAlpha(1);
    this.resetPose();
  }

  override update(dt: number): void {
    if (!this.alive) return;
    this.x -= this.speed * dt;
    this.animate(dt, 'walk');
  }

  /** Возвращает true, если удар оказался смертельным. */
  hit(): boolean {
    if (!this.alive) return false;
    this.hp--;
    this.x += 3;
    this.flash();
    if (this.hp > 0) return false;
    this.alive = false;
    this.playDeath(() => undefined);
    return true;
  }
}
