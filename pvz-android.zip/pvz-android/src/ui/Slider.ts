import Phaser from 'phaser';
import { Tex } from '@/graphics/TextureKeys';
import { textStyle } from './theme';

export interface SliderConfig {
  width: number;
  value: number;
  onChange: (value: number) => void;
  /** Вызывается, когда пользователь отпустил ползунок (например, для тестового звука). */
  onRelease?: (value: number) => void;
}

/** Горизонтальный ползунок 0..1; бегунок — вращающееся солнышко. */
export class Slider extends Phaser.GameObjects.Container {
  private value: number;
  private dragging = false;
  private readonly fill: Phaser.GameObjects.Graphics;
  private readonly knob: Phaser.GameObjects.Image;
  private readonly valueText: Phaser.GameObjects.Text;

  constructor(scene: Phaser.Scene, x: number, y: number, private readonly config: SliderConfig) {
    super(scene, x, y);
    this.value = Phaser.Math.Clamp(config.value, 0, 1);
    const w = config.width;

    const track = scene.add.graphics();
    track.fillStyle(0x3b2a18, 1).fillRoundedRect(-w / 2 - 3, -11, w + 6, 22, 11);
    track.fillStyle(0x5c4326, 1).fillRoundedRect(-w / 2, -8, w, 16, 8);
    this.fill = scene.add.graphics();
    this.knob = scene.add.image(0, 0, Tex.Fx.SunDrop).setScale(0.62);
    this.valueText = scene.add.text(w / 2 + 34, 0, '', textStyle(20)).setOrigin(0, 0.5);

    const zone = scene.add.zone(0, 0, w + 40, 48).setInteractive({ useHandCursor: true });
    zone.on(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, (p: Phaser.Input.Pointer) => {
      this.dragging = true;
      this.scene.tweens.add({ targets: this.knob, scale: 0.78, duration: 120 });
      this.updateFromPointer(p);
    });
    scene.input.on(Phaser.Input.Events.POINTER_MOVE, this.handleMove, this);
    scene.input.on(Phaser.Input.Events.POINTER_UP, this.handleUp, this);
    this.once(Phaser.GameObjects.Events.DESTROY, () => {
      scene.input.off(Phaser.Input.Events.POINTER_MOVE, this.handleMove, this);
      scene.input.off(Phaser.Input.Events.POINTER_UP, this.handleUp, this);
    });

    this.add([track, this.fill, zone, this.knob, this.valueText]);
    this.redraw();
    scene.add.existing(this);
  }

  setValue(value: number): this {
    this.value = Phaser.Math.Clamp(value, 0, 1);
    this.redraw();
    return this;
  }

  private handleMove(p: Phaser.Input.Pointer): void {
    if (this.dragging) this.updateFromPointer(p);
  }

  private handleUp(): void {
    if (!this.dragging) return;
    this.dragging = false;
    this.scene.tweens.add({ targets: this.knob, scale: 0.62, duration: 160, ease: 'Back.easeOut' });
    this.config.onRelease?.(this.value);
  }

  private updateFromPointer(p: Phaser.Input.Pointer): void {
    const local = this.getWorldTransformMatrix().applyInverse(p.worldX, p.worldY);
    const next = Phaser.Math.Clamp((local.x + this.config.width / 2) / this.config.width, 0, 1);
    const rounded = Math.round(next * 100) / 100;
    if (rounded === this.value) return;
    this.value = rounded;
    this.redraw();
    this.config.onChange(this.value);
  }

  private redraw(): void {
    const w = this.config.width;
    this.fill.clear();
    if (this.value > 0) {
      const fw = Math.max(16, w * this.value);
      this.fill.fillStyle(0x5fbf2e, 1).fillRoundedRect(-w / 2, -8, fw, 16, 8);
      this.fill.fillStyle(0xffffff, 0.25).fillRoundedRect(-w / 2 + 4, -6, Math.max(8, fw - 8), 5, 3);
    }
    this.knob.x = -w / 2 + w * this.value;
    this.knob.angle = this.value * 360;
    this.valueText.setText(`${Math.round(this.value * 100)}%`);
  }
}
