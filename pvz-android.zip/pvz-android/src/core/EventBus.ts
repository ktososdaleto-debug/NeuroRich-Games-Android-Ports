import type { Settings } from './SettingsManager';
import type { SaveData } from './SaveManager';
import type { WorldId } from '@/data/worlds';
import { TypedEmitter } from './TypedEmitter';

/** Все глобальные события игры и их аргументы. Новые события добавляются сюда. */
export type GameEvents = {
  'settings:changed': [settings: Readonly<Settings>];
  'save:active-changed': [save: SaveData | null];
  'menu:world-preview': [world: WorldId];
};

/** Глобальная шина событий для связи между сценами и сервисами. */
export const eventBus = new TypedEmitter<GameEvents>();
