import type { SaveData } from './SaveManager';
import { LEVELS, getLevel, getLevelsOfWorld, type LevelDef } from '@/data/levels';
import type { WorldId } from '@/data/worlds';

export const MAX_STARS = LEVELS.length * 3;

export function isLevelCompleted(save: SaveData | null, levelId: string): boolean {
  return Boolean(save?.levels[levelId]);
}

/** Уровень открыт, если это первый уровень или пройден предыдущий по порядку. */
export function isLevelUnlocked(save: SaveData | null, levelId: string): boolean {
  const level = getLevel(levelId);
  if (!level) return false;
  if (level.order === 0) return true;
  return isLevelCompleted(save, LEVELS[level.order - 1].id);
}

export function isWorldUnlocked(save: SaveData | null, worldId: WorldId): boolean {
  const first = getLevelsOfWorld(worldId)[0];
  return Boolean(first) && isLevelUnlocked(save, first.id);
}

export function getNextLevel(save: SaveData | null): LevelDef {
  return LEVELS.find((l) => !isLevelCompleted(save, l.id)) ?? LEVELS[LEVELS.length - 1];
}

export function getStars(save: SaveData | null, levelId: string): number {
  return save?.levels[levelId]?.stars ?? 0;
}

export function countCompleted(save: SaveData | null): number {
  return save ? Object.keys(save.levels).length : 0;
}

export function countStars(save: SaveData | null): number {
  return save ? Object.values(save.levels).reduce((sum, l) => sum + l.stars, 0) : 0;
}
