import { eventBus } from './EventBus';
import { storage } from './storage';
import { getLevel } from '@/data/levels';
import { STARTER_PLANTS, type PlantId } from '@/data/plants';

export const SAVE_SLOT_COUNT = 3;
export const PROFILE_NAME_MAX = 14;
const SAVE_VERSION = 1;
const ACTIVE_KEY = 'activeSlot';

export interface LevelProgress {
  stars: number;
  completedAt: number;
}

export interface SaveData {
  version: number;
  slot: number;
  name: string;
  createdAt: number;
  updatedAt: number;
  playTimeSec: number;
  coins: number;
  unlockedPlants: PlantId[];
  levels: Record<string, LevelProgress>;
}

/**
 * Миграции формата сохранений. При изменении SaveData увеличьте SAVE_VERSION
 * и добавьте шаг миграции со старой версии.
 */
function migrate(raw: SaveData): SaveData {
  const data = { ...raw };
  // if (data.version < 2) { ...; data.version = 2; }
  data.version = SAVE_VERSION;
  data.levels ??= {};
  data.unlockedPlants ??= [...STARTER_PLANTS];
  data.playTimeSec ??= 0;
  data.coins ??= 0;
  return data;
}

const slotKey = (slot: number) => `save:${slot}`;

class SaveManager {
  private activeSlot: number | null = null;

  constructor() {
    const stored = storage.get<number>(ACTIVE_KEY);
    if (typeof stored === 'number' && this.load(stored)) this.activeSlot = stored;
  }

  load(slot: number): SaveData | null {
    const raw = storage.get<SaveData>(slotKey(slot));
    return raw ? migrate(raw) : null;
  }

  list(): (SaveData | null)[] {
    return Array.from({ length: SAVE_SLOT_COUNT }, (_, i) => this.load(i));
  }

  firstEmptySlot(): number | null {
    const index = this.list().findIndex((s) => s === null);
    return index === -1 ? null : index;
  }

  create(slot: number, name: string): SaveData {
    const now = Date.now();
    const data: SaveData = {
      version: SAVE_VERSION,
      slot,
      name: name.trim().slice(0, PROFILE_NAME_MAX) || `Игрок ${slot + 1}`,
      createdAt: now,
      updatedAt: now,
      playTimeSec: 0,
      coins: 0,
      unlockedPlants: [...STARTER_PLANTS],
      levels: {},
    };
    storage.set(slotKey(slot), data);
    this.setActive(slot);
    return data;
  }

  delete(slot: number): void {
    storage.remove(slotKey(slot));
    if (this.activeSlot === slot) this.setActive(null);
  }

  get active(): SaveData | null {
    return this.activeSlot === null ? null : this.load(this.activeSlot);
  }

  get activeSlotIndex(): number | null {
    return this.activeSlot;
  }

  setActive(slot: number | null): void {
    this.activeSlot = slot;
    if (slot === null) storage.remove(ACTIVE_KEY);
    else storage.set(ACTIVE_KEY, slot);
    eventBus.emit('save:active-changed', this.active);
  }

  /** Изменяет активное сохранение и сразу записывает его. */
  update(mutate: (data: SaveData) => void): SaveData | null {
    const data = this.active;
    if (!data) return null;
    mutate(data);
    data.updatedAt = Date.now();
    storage.set(slotKey(data.slot), data);
    eventBus.emit('save:active-changed', data);
    return data;
  }

  completeLevel(levelId: string, stars: number): void {
    this.update((data) => {
      const prev = data.levels[levelId];
      data.levels[levelId] = {
        stars: Math.max(prev?.stars ?? 0, Math.min(3, stars)),
        completedAt: Date.now(),
      };
      const reward = getLevel(levelId)?.rewardPlant;
      if (reward && !data.unlockedPlants.includes(reward)) data.unlockedPlants.push(reward);
    });
  }
}

export const saves = new SaveManager();
