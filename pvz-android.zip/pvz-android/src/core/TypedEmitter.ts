import Phaser from 'phaser';

export type EventMap = Record<string, unknown[]>;

type Handler<A extends unknown[]> = (...args: A) => void;

/** Эмиттер с типизированными событиями: имя события определяет аргументы обработчика. */
export class TypedEmitter<E extends EventMap> {
  private readonly emitter = new Phaser.Events.EventEmitter();

  on<K extends keyof E & string>(event: K, fn: Handler<E[K]>, context?: unknown): this {
    this.emitter.on(event, fn, context);
    return this;
  }

  once<K extends keyof E & string>(event: K, fn: Handler<E[K]>, context?: unknown): this {
    this.emitter.once(event, fn, context);
    return this;
  }

  off<K extends keyof E & string>(event: K, fn: Handler<E[K]>, context?: unknown): this {
    this.emitter.off(event, fn, context);
    return this;
  }

  emit<K extends keyof E & string>(event: K, ...args: E[K]): void {
    this.emitter.emit(event, ...args);
  }

  removeAll(): void {
    this.emitter.removeAllListeners();
  }
}
