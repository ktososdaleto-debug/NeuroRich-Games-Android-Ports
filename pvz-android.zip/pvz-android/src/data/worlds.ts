export type WorldId = 'day' | 'night' | 'pool' | 'fog' | 'roof';

export interface WorldDef {
  id: WorldId;
  name: string;
  description: string;
  /** Цвет и прозрачность оверлея, которым фон меню «примеряет» мир. */
  overlayColor: number;
  overlayAlpha: number;
  accent: number;
}

export const WORLDS: WorldDef[] = [
  {
    id: 'day',
    name: 'День',
    description: 'Солнечная лужайка перед домом',
    overlayColor: 0x000000,
    overlayAlpha: 0,
    accent: 0xffd23f,
  },
  {
    id: 'night',
    name: 'Ночь',
    description: 'Задний двор при свете луны',
    overlayColor: 0x0b1240,
    overlayAlpha: 0.55,
    accent: 0x9b7bff,
  },
  {
    id: 'pool',
    name: 'Бассейн',
    description: 'Зомби умеют плавать. К сожалению',
    overlayColor: 0x0088cc,
    overlayAlpha: 0.16,
    accent: 0x3fd0ff,
  },
  {
    id: 'fog',
    name: 'Туман',
    description: 'Ничего не видно, но что-то стонет',
    overlayColor: 0x8a9bb0,
    overlayAlpha: 0.5,
    accent: 0xb0c4de,
  },
  {
    id: 'roof',
    name: 'Крыша',
    description: 'Последний рубеж обороны',
    overlayColor: 0xff7a33,
    overlayAlpha: 0.22,
    accent: 0xff8a4c,
  },
];

export function getWorld(id: WorldId): WorldDef {
  return WORLDS.find((w) => w.id === id) ?? WORLDS[0];
}
