@echo off
setlocal
chcp 65001 >nul
title Geometry Dash - Claude Edition
cd /d "%~dp0"

set "PORT=5173"

echo.
echo   ==========================================
echo      GEOMETRY DASH  -  Claude Edition
echo   ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo   [!] Node.js не найден.
  echo       Установите Node.js LTS ^(версия 20 или новее^) с https://nodejs.org
  echo       и запустите start.bat снова.
  echo.
  start "" "https://nodejs.org/"
  pause
  exit /b 1
)

if not exist "node_modules\" (
  echo   Первый запуск: устанавливаю зависимости...
  echo.
  call npm install
  if errorlevel 1 (
    echo.
    echo   [!] Не удалось установить зависимости. Проверьте подключение к интернету.
    pause
    exit /b 1
  )
  echo.
)

rem Если игра уже запущена - просто открываем ещё одно окно
call :port_open
if not errorlevel 1 (
  echo   Сервер уже запущен - открываю окно игры.
  call scripts\open-game.cmd %PORT%
  exit /b 0
)

rem Окно игры откроется само, как только сервер будет готов
start "GD Launcher" /min cmd /c scripts\open-game.cmd %PORT%

echo   Запускаю игру... Окно откроется автоматически.
echo   Чтобы остановить игру - закройте это окно.
echo.
call npm run dev
exit /b %errorlevel%

:port_open
powershell -NoProfile -Command "try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', %PORT%); $c.Close(); exit 0 } catch { exit 1 }" >nul 2>nul
exit /b %errorlevel%
