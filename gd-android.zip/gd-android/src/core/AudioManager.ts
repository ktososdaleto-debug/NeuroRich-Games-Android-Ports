import { settings, type Settings } from '../state/settings';
import { Synth } from '../audio/Synth';
import type { Song } from '../audio/types';
import { menuSong } from '../audio/songs';

export type Sfx =
  | 'click'
  | 'hover'
  | 'back'
  | 'select'
  | 'play'
  | 'error'
  | 'toggle'
  | 'death'
  | 'checkpoint'
  | 'complete'
  | 'record';

type BeatListener = (beatIndex: number) => void;

/** Насколько вперёд планируем ноты, с */
const LOOKAHEAD = 0.12;
/** Задержка старта песни, чтобы первая нота не опоздала */
export const SONG_LEAD_IN = 0.06;

interface Playback {
  song: Song;
  bus: GainNode;
  /** Время AudioContext, в которое у песни «0 секунд» */
  origin: number;
  step: number;
  stepDur: number;
}

/**
 * Весь звук игры. Музыка синтезируется на лету (см. src/audio/songs).
 * Главное для игры — songTime(): это часы, по которым идёт физика уровня,
 * поэтому картинка никогда не «уплывает» от музыки.
 */
class AudioManager {
  private ctx: AudioContext | null = null;
  private synth: Synth | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private playback: Playback | null = null;
  private readonly beatListeners = new Set<BeatListener>();

  get unlocked(): boolean {
    return this.ctx !== null;
  }

  /** Браузер разрешает звук только после жеста пользователя — вызывать из обработчика клика/клавиши. */
  unlock(): void {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    let ctx: AudioContext;
    try {
      ctx = new AudioContext({ latencyHint: 'interactive' });
    } catch {
      return;
    }
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 4;
    comp.connect(ctx.destination);
    const master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(comp);

    this.musicBus = ctx.createGain();
    this.musicBus.connect(master);
    this.sfxBus = ctx.createGain();
    this.sfxBus.connect(master);
    this.synth = new Synth(ctx);
    this.ctx = ctx;

    settings.subscribe((s) => this.applyVolumes(s), true);
    document.addEventListener('visibilitychange', () => {
      if (!this.ctx) return;
      if (document.hidden) void this.ctx.suspend();
      else void this.ctx.resume();
    });
    window.setInterval(() => this.schedule(), 25);
  }

  // ---- Музыка ---------------------------------------------------------------

  /** Запустить песню с момента from (секунды от начала трека) */
  playSong(song: Song, from = 0): void {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    this.stopSong(0.03);
    const bus = ctx.createGain();
    bus.gain.value = this.songGain(song);
    bus.connect(this.musicBus);
    const stepDur = 60 / song.bpm / 4;
    this.playback = {
      song,
      bus,
      origin: ctx.currentTime + SONG_LEAD_IN - from,
      step: Math.max(0, Math.ceil(from / stepDur - 1e-6)),
      stepDur,
    };
    this.schedule();
  }

  stopSong(fade = 0.06): void {
    const p = this.playback;
    if (!p || !this.ctx) return;
    this.playback = null;
    const t = this.ctx.currentTime;
    p.bus.gain.cancelScheduledValues(t);
    p.bus.gain.setValueAtTime(p.bus.gain.value, t);
    p.bus.gain.linearRampToValueAtTime(0, t + fade);
    window.setTimeout(() => p.bus.disconnect(), (fade + LOOKAHEAD + 0.3) * 1000);
  }

  isPlaying(songId: string): boolean {
    return this.playback?.song.id === songId;
  }

  /** Сколько секунд песни уже *прозвучало* (с учётом задержки вывода звука) */
  songTime(): number {
    const ctx = this.ctx;
    const p = this.playback;
    if (!ctx || !p) return 0;
    return ctx.currentTime - p.origin - (ctx.baseLatency || 0) - (ctx.outputLatency || 0);
  }

  startMenuMusic(): void {
    if (!this.ctx || this.isPlaying(menuSong.id)) return;
    this.playSong(menuSong);
  }

  /** Подписка на сильные доли текущей песни (для пульсации интерфейса) */
  onBeat(fn: BeatListener): () => void {
    this.beatListeners.add(fn);
    return () => {
      this.beatListeners.delete(fn);
    };
  }

  // ---- Эффекты --------------------------------------------------------------

  sfx(name: Sfx): void {
    const sy = this.synth;
    const bus = this.sfxBus;
    if (!this.ctx || !sy || !bus) return;
    const t = this.ctx.currentTime + 0.005;
    switch (name) {
      case 'hover':
        sy.tone(1400, t, 0.035, bus, { type: 'sine', gain: 0.035 });
        break;
      case 'click':
        sy.tone(520, t, 0.07, bus, { type: 'square', gain: 0.11, slideTo: 880, cutoff: 3000 });
        sy.tone(1040, t + 0.03, 0.06, bus, { type: 'triangle', gain: 0.08 });
        break;
      case 'back':
        sy.tone(620, t, 0.09, bus, { type: 'square', gain: 0.1, slideTo: 310, cutoff: 2400 });
        break;
      case 'select':
        sy.tone(784, t, 0.06, bus, { type: 'triangle', gain: 0.12 });
        sy.tone(1175, t + 0.05, 0.08, bus, { type: 'triangle', gain: 0.1 });
        break;
      case 'toggle':
        sy.tone(990, t, 0.05, bus, { type: 'triangle', gain: 0.1 });
        break;
      case 'error':
        sy.tone(220, t, 0.08, bus, { type: 'square', gain: 0.1, cutoff: 1200 });
        sy.tone(180, t + 0.1, 0.12, bus, { type: 'square', gain: 0.1, cutoff: 1200 });
        break;
      case 'play':
        sy.tone(330, t, 0.35, bus, { type: 'sawtooth', gain: 0.12, slideTo: 1320, cutoff: 4000 });
        sy.tone(660, t + 0.08, 0.3, bus, { type: 'square', gain: 0.06, slideTo: 1760, cutoff: 5000 });
        sy.noise(t, 0.3, 0.12, bus, 'highpass', 3000);
        break;
      case 'death':
        sy.noise(t, 0.5, 0.5, bus, 'lowpass', 2200);
        sy.noise(t, 0.25, 0.25, bus, 'highpass', 3000);
        sy.tone(160, t, 0.4, bus, { type: 'sawtooth', gain: 0.18, slideTo: 40, cutoff: 900 });
        break;
      case 'checkpoint':
        sy.tone(880, t, 0.08, bus, { type: 'triangle', gain: 0.1 });
        sy.tone(1320, t + 0.06, 0.1, bus, { type: 'triangle', gain: 0.08 });
        break;
      case 'record':
        sy.tone(988, t, 0.12, bus, { type: 'square', gain: 0.06, cutoff: 4000 });
        sy.tone(1319, t + 0.1, 0.25, bus, { type: 'square', gain: 0.06, cutoff: 4000 });
        break;
      case 'complete':
        [523, 659, 784, 1047, 1319].forEach((f, i) =>
          sy.tone(f, t + i * 0.07, 0.5, bus, { type: 'square', gain: 0.07, cutoff: 5000 }),
        );
        sy.crash(t, bus, 0.15);
        break;
    }
  }

  // ---------------------------------------------------------------------------

  /** Громкость отдельной песни: музыку меню можно выключить отдельно */
  private songGain(song: Song): number {
    return song.id === menuSong.id && !settings.get().menuMusic ? 0 : 1;
  }

  private applyVolumes(s: Readonly<Settings>): void {
    if (!this.ctx || !this.musicBus || !this.sfxBus) return;
    const t = this.ctx.currentTime;
    this.musicBus.gain.setTargetAtTime(s.musicVolume ** 2 * 0.55, t, 0.08);
    this.sfxBus.gain.setTargetAtTime(s.sfxVolume ** 2 * 0.8, t, 0.03);
    if (this.playback) this.playback.bus.gain.setTargetAtTime(this.songGain(this.playback.song), t, 0.08);
  }

  private schedule(): void {
    const ctx = this.ctx;
    const sy = this.synth;
    const p = this.playback;
    if (!ctx || !sy || !p) return;
    const horizon = ctx.currentTime + LOOKAHEAD;
    for (;;) {
      const t = p.origin + p.step * p.stepDur;
      if (t >= horizon) break;
      const song = p.song;
      if (!song.loop && p.step >= song.lengthSteps) break;
      // ноты, которые уже безнадёжно опоздали, пропускаем
      if (t >= ctx.currentTime - 0.02) {
        const local = song.loop ? p.step % song.lengthSteps : p.step;
        song.play(sy, local, t, p.bus);
        if (local % 4 === 0) this.emitBeat(t, local / 4, song);
      }
      p.step++;
    }
  }

  private emitBeat(t: number, index: number, song: Song): void {
    if (!this.ctx || this.songGain(song) === 0 || settings.get().musicVolume === 0) return;
    const delay = Math.max(0, (t - this.ctx.currentTime) * 1000);
    window.setTimeout(() => {
      for (const fn of this.beatListeners) fn(index);
    }, delay);
  }
}

export const audio = new AudioManager();
