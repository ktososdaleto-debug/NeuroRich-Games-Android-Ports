/**
 * Тонкая обёртка над localStorage. Все ошибки (приватный режим, переполнение квоты,
 * битый JSON) гасятся — игра обязана работать и без сохранений.
 */
const PREFIX = 'gd-claude/v1/';

export function loadJSON<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export function saveJSON(key: string, value: unknown): void {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    /* хранилище недоступно — молча продолжаем */
  }
}

export function removeKey(key: string): void {
  try {
    localStorage.removeItem(PREFIX + key);
  } catch {
    /* noop */
  }
}
