/** Маленький счётчик FPS в верхней части экрана. */
export function createFpsCounter(): { setVisible(visible: boolean): void } {
  const el = document.createElement('div');
  el.className = 'fps';
  document.body.appendChild(el);

  let visible = false;
  let frames = 0;
  let last = performance.now();
  let raf = 0;

  const loop = (now: number) => {
    frames++;
    if (now - last >= 500) {
      el.textContent = `${Math.round((frames * 1000) / (now - last))} FPS`;
      frames = 0;
      last = now;
    }
    raf = requestAnimationFrame(loop);
  };

  return {
    setVisible(v) {
      if (v === visible) return;
      visible = v;
      el.classList.toggle('is-visible', v);
      if (v) {
        frames = 0;
        last = performance.now();
        raf = requestAnimationFrame(loop);
      } else {
        cancelAnimationFrame(raf);
      }
    },
  };
}
