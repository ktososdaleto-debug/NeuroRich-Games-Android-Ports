export const isFullscreen = (): boolean => document.fullscreenElement !== null;

export async function setFullscreen(on: boolean): Promise<void> {
  try {
    if (on && !document.fullscreenElement) await document.documentElement.requestFullscreen();
    else if (!on && document.fullscreenElement) await document.exitFullscreen();
  } catch {
    /* браузер может отказать без жеста пользователя */
  }
}

export const toggleFullscreen = (): Promise<void> => setFullscreen(!isFullscreen());
