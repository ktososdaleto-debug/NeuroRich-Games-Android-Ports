import type { Application } from 'pixi.js';
import type { Router } from './Router';
import type { MenuBackground } from '../render/MenuBackground';

export type ScreenId = 'splash' | 'main' | 'levels' | 'settings' | 'skins' | 'game' | 'editorList' | 'editor';
export type Transition = 'forward' | 'back' | 'zoom' | 'fade';

/** Общие сервисы, которые получает каждый экран */
export interface AppContext {
  router: Router;
  /** null, если WebGL недоступен — меню работает на CSS-фоне, а игра не запускается */
  app: Application | null;
  background: MenuBackground | null;
}

export interface Screen {
  readonly el: HTMLElement;
  /** Вызывается сразу после монтирования в DOM */
  enter?(): void;
  /** Вызывается перед анимацией ухода */
  leave?(): void;
  /** true — клавиша обработана, роутер дальше её не трогает */
  onKey?(e: KeyboardEvent): boolean | void;
  /** Esc / кнопка «назад» */
  back?(): void;
}

export type ScreenFactory = (ctx: AppContext) => Screen;
