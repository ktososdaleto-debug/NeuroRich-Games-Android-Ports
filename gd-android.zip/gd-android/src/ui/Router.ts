import type { AppContext, Screen, ScreenFactory, ScreenId, Transition } from './types';

const LEAVE_MS = 480;

/**
 * Переключает экраны с анимацией. Экран создаётся заново при каждом входе
 * и уничтожается после ухода — состояние живёт в Store, а не в DOM.
 */
export class Router {
  private readonly factories = new Map<ScreenId, ScreenFactory>();
  private readonly history: ScreenId[] = [];
  private current: { id: ScreenId; screen: Screen } | null = null;
  private readonly ctx: AppContext;

  constructor(
    private readonly root: HTMLElement,
    services: Omit<AppContext, 'router'>,
  ) {
    this.ctx = { ...services, router: this };
    window.addEventListener('keydown', this.onKey);
  }

  register(id: ScreenId, factory: ScreenFactory): this {
    this.factories.set(id, factory);
    return this;
  }

  get currentId(): ScreenId | null {
    return this.current?.id ?? null;
  }

  go(id: ScreenId, transition: Transition = 'forward'): void {
    if (this.current?.id === id) return;
    if (this.current && transition === 'forward') this.history.push(this.current.id);
    this.swap(id, transition);
  }

  back(fallback: ScreenId = 'main'): void {
    this.swap(this.history.pop() ?? fallback, 'back');
  }

  /** Пересоздать текущий экран (например, после сброса настроек) */
  refresh(): void {
    if (this.current) this.swap(this.current.id, 'fade');
  }

  private swap(id: ScreenId, transition: Transition): void {
    const factory = this.factories.get(id);
    if (!factory) throw new Error(`Экран «${id}» не зарегистрирован`);

    const prev = this.current;
    const screen = factory(this.ctx);
    const inClass = `t-${transition}-in`;
    screen.el.classList.add('screen', inClass);
    const onEnd = (e: AnimationEvent) => {
      if (e.target !== screen.el) return;
      screen.el.classList.remove(inClass);
      screen.el.removeEventListener('animationend', onEnd);
    };
    screen.el.addEventListener('animationend', onEnd);

    this.root.appendChild(screen.el);
    this.current = { id, screen };
    screen.enter?.();

    if (prev) {
      prev.screen.leave?.();
      const el = prev.screen.el;
      el.inert = true;
      el.classList.add(`t-${transition}-out`);
      window.setTimeout(() => el.remove(), LEAVE_MS);
    }
  }

  private readonly onKey = (e: KeyboardEvent): void => {
    const screen = this.current?.screen;
    if (!screen || document.querySelector('.modal')) return;
    if (screen.onKey?.(e)) {
      e.preventDefault();
      return;
    }
    if (e.code === 'Escape' && !e.repeat && screen.back) {
      e.preventDefault();
      screen.back();
    }
  };
}
