/*
 * Векторные иконки интерфейса. Рисуются белым — чёрную «GD-обводку» добавляет CSS
 * (filter: drop-shadow ×4), поэтому формы здесь без stroke-контуров.
 */
const svg = (body: string) =>
  `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">${body}</svg>`;

const gearTeeth = Array.from(
  { length: 8 },
  (_, i) => `<rect x="42" y="6" width="16" height="22" rx="3" transform="rotate(${i * 45} 50 50)"/>`,
).join('');

const musicNote =
  '<path d="M38 72 V24 L82 14 V62" fill="none" stroke="#fff" stroke-width="10" stroke-linejoin="round"/>' +
  '<ellipse cx="28" cy="74" rx="14" ry="11" fill="#fff"/><ellipse cx="72" cy="64" rx="14" ry="11" fill="#fff"/>';

export const ICONS = {
  play: svg('<path d="M32 20 L82 50 L32 80 Z" fill="#fff" stroke="#fff" stroke-width="8" stroke-linejoin="round"/>'),
  gear: svg(
    `<defs><mask id="gear-hole"><rect width="100" height="100" fill="#fff"/><circle cx="50" cy="50" r="12" fill="#000"/></mask></defs>` +
      `<g fill="#fff" mask="url(#gear-hole)"><circle cx="50" cy="50" r="30"/>${gearTeeth}</g>`,
  ),
  back: svg('<path d="M62 18 L28 50 L62 82" fill="none" stroke="#fff" stroke-width="16" stroke-linecap="round" stroke-linejoin="round"/>'),
  left: svg('<path d="M62 18 L30 50 L62 82" fill="none" stroke="#fff" stroke-width="16" stroke-linecap="round" stroke-linejoin="round"/>'),
  right: svg('<path d="M38 18 L70 50 L38 82" fill="none" stroke="#fff" stroke-width="16" stroke-linecap="round" stroke-linejoin="round"/>'),
  star: svg(
    '<path d="M50 6 L62 36 L94 38 L69 58 L78 90 L50 72 L22 90 L31 58 L6 38 L38 36 Z" fill="#ffd21f" stroke="#ffd21f" stroke-width="4" stroke-linejoin="round"/>',
  ),
  lock: svg(
    '<path d="M32 46 V34 a18 18 0 0 1 36 0 V46" fill="none" stroke="#fff" stroke-width="11"/>' +
      '<rect x="20" y="44" width="60" height="44" rx="8" fill="#fff"/><rect x="45" y="58" width="10" height="16" rx="4" fill="#3a3a6a"/>',
  ),
  fullscreen: svg(
    '<path d="M14 38 V14 H38 M62 14 H86 V38 M86 62 V86 H62 M38 86 H14 V62" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/>',
  ),
  music: svg(musicNote),
  musicOff: svg(`${musicNote}<path d="M14 14 L86 86" stroke="#ff4b5c" stroke-width="12" stroke-linecap="round"/>`),
  swap: svg(
    '<path d="M20 34 H76 M62 18 L78 34 L62 50 M80 66 H24 M38 50 L22 66 L38 82" fill="none" stroke="#fff" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>',
  ),
  speaker: svg(
    '<path d="M14 38 H32 L54 18 V82 L32 62 H14 Z" fill="#fff" stroke="#fff" stroke-width="6" stroke-linejoin="round"/>' +
      '<path d="M66 34 a22 22 0 0 1 0 32 M76 22 a38 38 0 0 1 0 56" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round"/>',
  ),
  monitor: svg(
    '<rect x="10" y="16" width="80" height="54" rx="8" fill="#fff"/><rect x="20" y="26" width="60" height="34" rx="3" fill="#3a6bff"/>' +
      '<path d="M36 86 H64 M50 70 V86" stroke="#fff" stroke-width="10" stroke-linecap="round"/>',
  ),
  cube: svg('<rect x="14" y="14" width="72" height="72" rx="6" fill="#fff"/><rect x="32" y="32" width="36" height="36" rx="3" fill="#62d81e"/>'),
  keyboard: svg(
    '<rect x="6" y="24" width="88" height="52" rx="8" fill="#fff"/><g fill="#3a3a6a">' +
      '<rect x="16" y="34" width="10" height="10" rx="2"/><rect x="31" y="34" width="10" height="10" rx="2"/>' +
      '<rect x="46" y="34" width="10" height="10" rx="2"/><rect x="61" y="34" width="10" height="10" rx="2"/>' +
      '<rect x="76" y="34" width="8" height="10" rx="2"/><rect x="26" y="54" width="48" height="10" rx="2"/></g>',
  ),
  pause: svg('<rect x="22" y="16" width="20" height="68" rx="6" fill="#fff"/><rect x="58" y="16" width="20" height="68" rx="6" fill="#fff"/>'),
  restart: svg(
    '<path d="M78 50 A28 28 0 1 1 64 25.8" fill="none" stroke="#fff" stroke-width="13" stroke-linecap="round"/>' +
      '<path d="M54 8 L82 22 L58 40 Z" fill="#fff" stroke="#fff" stroke-width="4" stroke-linejoin="round"/>',
  ),
  home: svg('<path d="M50 12 L90 48 H78 V86 H58 V64 H42 V86 H22 V48 H10 Z" fill="#fff" stroke="#fff" stroke-width="4" stroke-linejoin="round"/>'),
  diamond: svg(
    '<path d="M50 8 L86 50 L50 92 L14 50 Z" fill="#5dff7a" stroke="#5dff7a" stroke-width="4" stroke-linejoin="round"/>' +
      '<path d="M50 24 L72 50 L50 76 L28 50 Z" fill="#c4ffd0" opacity=".55"/>',
  ),
  close: svg('<path d="M24 24 L76 76 M76 24 L24 76" stroke="#fff" stroke-width="16" stroke-linecap="round"/>'),
  pencil: svg(
    '<path d="M18 82 L24 60 L66 18 L82 34 L40 76 Z" fill="#fff" stroke="#fff" stroke-width="6" stroke-linejoin="round"/>' +
      '<path d="M58 26 L74 42" stroke="#3a3a6a" stroke-width="6"/><path d="M18 82 L24 60 L40 76 Z" fill="#ffd21f"/>',
  ),
  cursor: svg('<path d="M24 12 L76 54 L52 58 L66 86 L54 92 L40 64 L24 80 Z" fill="#fff" stroke="#fff" stroke-width="5" stroke-linejoin="round"/>'),
  eraser: svg(
    '<path d="M14 62 L52 24 L86 58 L56 88 L32 88 Z" fill="#fff" stroke="#fff" stroke-width="5" stroke-linejoin="round"/>' +
      '<path d="M33 43 L67 77" stroke="#ff6b7a" stroke-width="10"/>',
  ),
  undo: svg('<path d="M36 22 L14 42 L36 62" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 42 H60 a24 24 0 0 1 0 48 H44" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round"/>'),
  redo: svg('<path d="M64 22 L86 42 L64 62" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/><path d="M84 42 H40 a24 24 0 0 0 0 48 H56" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round"/>'),
  grid: svg('<path d="M14 14 H86 V86 H14 Z M38 14 V86 M62 14 V86 M14 38 H86 M14 62 H86" fill="none" stroke="#fff" stroke-width="7"/>'),
  plus: svg('<path d="M50 16 V84 M16 50 H84" stroke="#fff" stroke-width="16" stroke-linecap="round"/>'),
  upload: svg('<path d="M50 70 V18 M28 38 L50 16 L72 38" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 64 V84 H84 V64" fill="none" stroke="#fff" stroke-width="10" stroke-linejoin="round"/>'),
  download: svg('<path d="M50 16 V66 M28 46 L50 68 L72 46" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 64 V84 H84 V64" fill="none" stroke="#fff" stroke-width="10" stroke-linejoin="round"/>'),
  copy: svg('<rect x="30" y="30" width="54" height="54" rx="8" fill="#fff"/><rect x="14" y="14" width="54" height="54" rx="8" fill="none" stroke="#fff" stroke-width="9"/>'),
  data: svg(
    '<ellipse cx="50" cy="22" rx="34" ry="12" fill="#fff"/><path d="M16 22 V78 a34 12 0 0 0 68 0 V22" fill="#fff"/>' +
      '<path d="M16 42 a34 12 0 0 0 68 0 M16 60 a34 12 0 0 0 68 0" fill="none" stroke="#3a3a6a" stroke-width="5"/>',
  ),
} as const;
