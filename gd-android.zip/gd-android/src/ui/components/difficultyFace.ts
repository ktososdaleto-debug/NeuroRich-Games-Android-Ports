import type { Difficulty } from '../../data/levels';
import { DIFFICULTIES } from '../../data/difficulty';

const EYES_ROUND = '<circle cx="36" cy="50" r="6"/><circle cx="64" cy="50" r="6"/>';
const STROKE = 'fill="none" stroke="#000" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"';

const FACES: Record<Difficulty, string> = {
  easy: `<g fill="#000">${EYES_ROUND}</g><path d="M32 64 Q50 82 68 64" ${STROKE}/>`,
  normal: `<g fill="#000"><ellipse cx="36" cy="49" rx="5" ry="8"/><ellipse cx="64" cy="49" rx="5" ry="8"/></g><path d="M36 67 Q50 77 64 67" ${STROKE}/>`,
  hard: `<g fill="#000">${EYES_ROUND}</g><path d="M36 70 L64 70" ${STROKE}/>`,
  harder:
    `<path d="M26 36 L44 44 M74 36 L56 44" ${STROKE}/><g fill="#000">${EYES_ROUND}</g>` +
    `<path d="M34 76 Q50 62 66 76" ${STROKE}/>`,
  insane:
    `<path d="M24 32 L46 44 M76 32 L54 44" ${STROKE}/>` +
    '<circle cx="36" cy="54" r="9" fill="#fff" stroke="#000" stroke-width="4"/><circle cx="64" cy="54" r="9" fill="#fff" stroke="#000" stroke-width="4"/>' +
    '<circle cx="37" cy="55" r="4" fill="#d1002a"/><circle cx="63" cy="55" r="4" fill="#d1002a"/>' +
    '<ellipse cx="50" cy="76" rx="11" ry="7" fill="#000"/>',
  demon:
    '<path d="M22 40 L45 50 L25 56 Z M78 40 L55 50 L75 56 Z" fill="#ffd21f" stroke="#000" stroke-width="4" stroke-linejoin="round"/>' +
    '<path d="M26 66 L74 66 L68 82 L59 73 L50 84 L41 73 L32 82 Z" fill="#000" stroke="#000" stroke-width="3" stroke-linejoin="round"/>',
};

/** SVG-мордочка сложности, как в оригинале */
export function difficultyFace(d: Difficulty): string {
  const color = DIFFICULTIES[d].color;
  const horns =
    d === 'demon'
      ? '<path d="M20 34 L8 2 L40 22 Z M80 34 L92 2 L60 22 Z" fill="#7a0d18" stroke="#000" stroke-width="5" stroke-linejoin="round"/>'
      : '';
  return (
    '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    horns +
    `<circle cx="50" cy="56" r="38" fill="${color}" stroke="#000" stroke-width="6"/>` +
    '<ellipse cx="50" cy="38" rx="24" ry="10" fill="#fff" opacity=".28"/>' +
    FACES[d] +
    '</svg>'
  );
}
