import { h } from '../dom';

let host: HTMLElement | null = null;

export function toast(message: string, kind: 'info' | 'warn' = 'info', ms = 2400): void {
  host ??= document.body.appendChild(h('div', { class: 'toasts' }));
  const el = h('div', { class: `toast toast--${kind}` }, message);
  host.appendChild(el);
  // не копим больше трёх сообщений
  while (host.children.length > 3) host.firstElementChild?.remove();
  window.setTimeout(() => {
    el.classList.add('toast--out');
    window.setTimeout(() => el.remove(), 380);
  }, ms);
}
