import { h, icon } from '../dom';
import { ICONS } from '../icons';
import { button } from './button';
import { MAX_STARS } from '../../state/profile';

export function createLogo(withSubtitle = true): HTMLElement {
  let i = 0;
  const word = (text: string) =>
    h('span', { class: 'logo__word' }, ...[...text].map((ch) => h('span', { class: 'logo__letter', style: `--i:${i++}` }, ch)));
  return h(
    'div',
    { class: 'logo loop-anim' },
    h('div', { class: 'logo__title' }, word('GEOMETRY'), word('DASH')),
    withSubtitle ? h('div', { class: 'logo__sub' }, 'CLAUDE EDITION') : null,
  );
}

export function starsBadge(stars: number): HTMLElement {
  return h(
    'div',
    { class: 'badge', title: 'Звёзды за пройденные уровни' },
    icon(ICONS.star),
    h('span', { class: 'badge__value' }, String(stars)),
    h('span', { class: 'badge__max' }, `/ ${MAX_STARS}`),
  );
}

/** Полоса прогресса уровня в стиле оригинала: подпись сверху, процент по центру */
export function progressBar(label: string, value: number, kind: 'normal' | 'practice'): HTMLElement {
  const v = Math.max(0, Math.min(100, value));
  return h(
    'div',
    { class: `pbar pbar--${kind}` },
    h('div', { class: 'pbar__label' }, label),
    h(
      'div',
      { class: 'pbar__track' },
      h('div', { class: 'pbar__fill', style: `--v:${v}%` }),
      h('span', { class: 'pbar__text' }, `${Math.floor(v)}%`),
    ),
  );
}

export function screenHeader(title: string, onBack: () => void, right?: Node): HTMLElement {
  return h(
    'header',
    { class: 'screen-header rise', style: '--d:0' },
    h('div', { class: 'screen-header__left' }, button({ icon: ICONS.back, size: 'icon', title: 'Назад', sound: 'back', onClick: onBack })),
    h('h1', { class: 'screen-header__title' }, title),
    h('div', { class: 'screen-header__right' }, right ?? null),
  );
}
