import { h } from '../dom';
import { button } from './button';
import { audio } from '../../core/AudioManager';

export interface ConfirmOptions {
  title: string;
  text: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
}

export function confirmDialog(o: ConfirmOptions): Promise<boolean> {
  return new Promise((resolve) => {
    let closed = false;
    const close = (result: boolean) => {
      if (closed) return;
      closed = true;
      window.removeEventListener('keydown', onKey, true);
      overlay.classList.add('is-closing');
      window.setTimeout(() => overlay.remove(), 220);
      resolve(result);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== 'Escape' && e.code !== 'Enter') return;
      e.preventDefault();
      e.stopImmediatePropagation();
      if (e.code === 'Escape') {
        audio.sfx('back');
        close(false);
      } else {
        audio.sfx('click');
        close(true);
      }
    };

    const okBtn = button({ label: o.confirmLabel ?? 'Да', variant: o.danger ? 'red' : 'green', onClick: () => close(true) });
    const cancelBtn = button({ label: o.cancelLabel ?? 'Отмена', variant: 'dark', sound: 'back', onClick: () => close(false) });
    const overlay = h(
      'div',
      { class: 'modal' },
      h(
        'div',
        { class: 'modal__dialog panel', role: 'dialog', 'aria-modal': 'true' },
        h('h2', { class: 'modal__title' }, o.title),
        h('p', { class: 'modal__text' }, o.text),
        h('div', { class: 'modal__actions' }, cancelBtn, okBtn),
      ),
    );
    overlay.addEventListener('pointerdown', (e) => {
      if (e.target === overlay) close(false);
    });
    window.addEventListener('keydown', onKey, true);
    document.body.appendChild(overlay);
    okBtn.focus({ preventScroll: true });
  });
}
