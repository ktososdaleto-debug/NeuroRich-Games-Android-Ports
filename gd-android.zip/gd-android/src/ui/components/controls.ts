import { h } from '../dom';
import { audio } from '../../core/AudioManager';

function rowText(label: string, hint?: string): HTMLElement {
  return h(
    'span',
    { class: 'row__text' },
    h('span', { class: 'row__label' }, label),
    hint ? h('span', { class: 'row__hint' }, hint) : null,
  );
}

export function toggleRow(label: string, value: boolean, onChange: (v: boolean) => void, hint?: string): HTMLElement {
  const input = h('input', { type: 'checkbox', class: 'switch__input' });
  input.checked = value;
  input.addEventListener('change', () => {
    audio.sfx('toggle');
    onChange(input.checked);
  });
  return h(
    'label',
    { class: 'row' },
    rowText(label, hint),
    h('span', { class: 'switch' }, input, h('span', { class: 'switch__track' }, h('span', { class: 'switch__thumb' }))),
  );
}

/** value и onChange — в диапазоне 0..1 */
export function sliderRow(label: string, value: number, onChange: (v: number) => void, hint?: string): HTMLElement {
  const input = h('input', { type: 'range', min: '0', max: '100', step: '1', class: 'slider' });
  input.value = String(Math.round(value * 100));
  const out = h('span', { class: 'slider__value' }, `${input.value}%`);
  const paint = () => input.style.setProperty('--p', `${input.value}%`);
  input.addEventListener('input', () => {
    paint();
    out.textContent = `${input.value}%`;
    onChange(Number(input.value) / 100);
  });
  input.addEventListener('change', () => audio.sfx('toggle'));
  paint();
  return h('div', { class: 'row' }, rowText(label, hint), h('div', { class: 'slider-wrap' }, input, out));
}

export function segmentedRow<T extends string>(
  label: string,
  options: ReadonlyArray<{ value: T; label: string }>,
  value: T,
  onChange: (v: T) => void,
  hint?: string,
): HTMLElement {
  const items = options.map((o) => {
    const b = h('button', { class: 'segmented__item', type: 'button' }, o.label);
    b.classList.toggle('is-active', o.value === value);
    b.addEventListener('click', () => {
      items.forEach((x) => x.classList.remove('is-active'));
      b.classList.add('is-active');
      audio.sfx('toggle');
      onChange(o.value);
    });
    return b;
  });
  return h('div', { class: 'row' }, rowText(label, hint), h('div', { class: 'segmented' }, ...items));
}
