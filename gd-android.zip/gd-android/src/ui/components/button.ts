import { h } from '../dom';
import { audio, type Sfx } from '../../core/AudioManager';

export type ButtonVariant = 'green' | 'blue' | 'pink' | 'yellow' | 'red' | 'dark';
export type ButtonSize = 'sm' | 'md' | 'lg' | 'icon';

export interface ButtonOptions {
  label?: string;
  icon?: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  title?: string;
  /** null — без звука */
  sound?: Sfx | null;
  onClick?: (e: MouseEvent) => void;
}

/** Фирменная «пухлая» кнопка с обводкой, пружинным hover и бликом */
export function button(o: ButtonOptions): HTMLButtonElement {
  const el = h(
    'button',
    {
      class: `btn btn--${o.variant ?? 'green'} btn--${o.size ?? 'md'} ${o.className ?? ''}`.trim(),
      type: 'button',
      title: o.title,
      'aria-label': o.title ?? o.label,
    },
    o.icon ? h('span', { class: 'btn__icon', html: o.icon }) : null,
    o.label ? h('span', { class: 'btn__label' }, o.label) : null,
  );
  withSounds(el, o.sound === undefined ? 'click' : o.sound);
  if (o.onClick) el.addEventListener('click', o.onClick);
  return el;
}

/** Звук наведения и клика для любого кликабельного элемента */
export function withSounds(el: HTMLElement, click: Sfx | null = 'click'): void {
  el.addEventListener('pointerenter', () => audio.sfx('hover'));
  if (click) el.addEventListener('click', () => audio.sfx(click));
}
