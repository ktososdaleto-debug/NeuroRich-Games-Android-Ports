import { h, icon, replayClass } from '../dom';
import { ICONS as UI_ICONS } from '../icons';
import { button } from '../components/button';
import { screenHeader, starsBadge } from '../components/common';
import { toggleRow } from '../components/controls';
import { toast } from '../components/toast';
import { describeUnlock, effectOf, ICONS, PALETTE, type SkinConfig } from '../../data/skins';
import { createCubeCanvas } from '../../render/cubeArt';
import { EffectPreview } from '../../render/effectPreview';
import { isIconUnlocked, profile, totalStars, unlockCurrent } from '../../state/profile';
import { audio } from '../../core/AudioManager';
import type { AppContext, Screen } from '../types';

type ColorSlot = 'primary' | 'secondary';

export function createSkins(ctx: AppContext): Screen {
  const stars = totalStars();
  let skin: SkinConfig = { ...profile.get().skin };
  if (!ICONS.some((i) => i.id === skin.icon)) skin.icon = ICONS[0].id;

  // --- Превью
  const previewCube = h('div', { class: 'skin-preview__cube loop-anim' });
  // частицы вылетают от основания куба (линия земли — 20px от низа сцены)
  const fx = new EffectPreview(360, 300, 180, 280, 70);
  fx.canvas.classList.add('skin-preview__fx');
  const previewStage = h(
    'div',
    { class: 'skin-preview__stage' },
    fx.canvas,
    h('div', { class: 'skin-preview__shadow loop-anim' }),
    previewCube,
  );
  const previewName = h('div', { class: 'skin-preview__name' });
  const previewEffect = h('div', { class: 'skin-preview__effect' });

  // --- Сетка форм
  const iconCells = ICONS.map((def) => {
    const locked = !isIconUnlocked(def);
    const rule = def.unlock ? describeUnlock(def.unlock) : null;
    const cell = h('button', {
      class: `icon-cell${locked ? ' is-locked' : ''}`,
      type: 'button',
      title: locked && rule ? `${def.name} — нужно: ${rule.full}` : def.name,
    });
    cell.addEventListener('pointerenter', () => audio.sfx('hover'));
    cell.addEventListener('click', () => {
      if (locked && def.unlock && rule) {
        audio.sfx('error');
        replayClass(cell, 'shake');
        toast(`«${def.name}» откроется: ${rule.full} (сейчас ${unlockCurrent(def.unlock)})`, 'warn');
        return;
      }
      audio.sfx('select');
      update({ icon: def.id });
    });
    return { def, cell, locked, label: rule?.short ?? '' };
  });

  // --- Палитры
  const makeSwatches = (slot: ColorSlot) =>
    PALETTE.map((color) => {
      const b = h('button', { class: 'swatch', type: 'button', style: `--sw:${color}`, title: color });
      b.addEventListener('click', () => {
        audio.sfx('toggle');
        update({ [slot]: color } as Partial<SkinConfig>);
      });
      return { color, b };
    });
  const primary = makeSwatches('primary');
  const secondary = makeSwatches('secondary');

  const swapBtn = button({
    icon: UI_ICONS.swap,
    label: 'Поменять цвета',
    size: 'sm',
    variant: 'blue',
    onClick: () => update({ primary: skin.secondary, secondary: skin.primary }),
  });
  const glowToggle = toggleRow('Свечение', skin.glow, (v) => update({ glow: v }), 'Неоновый ореол дополнительного цвета');

  function render(bump: boolean): void {
    previewCube.replaceChildren(createCubeCanvas(140, skin, { pad: 40 }));
    previewName.textContent = ICONS.find((i) => i.id === skin.icon)?.name ?? '';
    const effect = effectOf(skin);
    previewEffect.textContent = effect ? `✦ ${effect.name}` : '';
    fx.setEffect(effect);
    for (const { def, cell, locked, label } of iconCells) {
      cell.replaceChildren(createCubeCanvas(52, { ...skin, icon: def.id, glow: false }, { pad: 6 }));
      if (locked) cell.append(h('span', { class: 'icon-cell__lock' }, icon(UI_ICONS.lock), h('span', null, label)));
      cell.classList.toggle('is-selected', def.id === skin.icon);
    }
    for (const { color, b } of primary) b.classList.toggle('is-selected', color === skin.primary);
    for (const { color, b } of secondary) b.classList.toggle('is-selected', color === skin.secondary);
    if (bump) replayClass(previewStage, 'bump');
  }

  function update(patch: Partial<SkinConfig>): void {
    skin = { ...skin, ...patch };
    profile.set({ skin });
    render(true);
  }

  render(false);

  const el = h(
    'div',
    { class: 'skins' },
    screenHeader('Иконки', () => ctx.router.back(), starsBadge(stars)),
    h(
      'div',
      { class: 'skins__layout' },
      h(
        'section',
        { class: 'panel skin-preview rise', style: '--d:1' },
        previewStage,
        previewName,
        previewEffect,
        h('div', { class: 'skin-preview__controls' }, swapBtn, glowToggle),
      ),
      h(
        'section',
        { class: 'panel skins__options rise', style: '--d:2' },
        h('h2', { class: 'panel__title' }, 'Особые скины'),
        h('p', { class: 'skins__note' }, 'С уникальными эффектами. Цвета ниже красят корабль, шар, НЛО и волну.'),
        h('div', { class: 'icon-grid' }, ...iconCells.filter((c) => c.def.image).map((c) => c.cell)),
        h('h2', { class: 'panel__title' }, 'Форма'),
        h('div', { class: 'icon-grid' }, ...iconCells.filter((c) => !c.def.image).map((c) => c.cell)),
        h('h2', { class: 'panel__title' }, 'Основной цвет'),
        h('div', { class: 'swatches' }, ...primary.map((s) => s.b)),
        h('h2', { class: 'panel__title' }, 'Дополнительный цвет'),
        h('div', { class: 'swatches' }, ...secondary.map((s) => s.b)),
      ),
    ),
  );

  return {
    el,
    leave() {
      fx.destroy();
    },
    back() {
      audio.sfx('back');
      ctx.router.back();
    },
  };
}
