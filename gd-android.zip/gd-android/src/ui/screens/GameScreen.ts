import { h, icon } from '../dom';
import { ICONS } from '../icons';
import { button, withSounds } from '../components/button';
import { progressBar } from '../components/common';
import { sliderRow } from '../components/controls';
import { LEVELS } from '../../data/levels';
import { getLevelData } from '../../levels';
import { getSong } from '../../audio/songs';
import { GameSession, type CompleteInfo, type SessionHooks } from '../../game/GameSession';
import { getLaunch } from '../../game/launch';
import { getProgress, profile } from '../../state/profile';
import { settings } from '../../state/settings';
import { audio } from '../../core/AudioManager';
import type { AppContext, Screen } from '../types';

const JUMP_KEYS = new Set(['Space', 'ArrowUp', 'KeyW']);

type Overlay = 'none' | 'pause' | 'death' | 'complete';

function formatTime(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function roundButton(svg: string, label: string, variant: 'green' | 'big' | 'practice', onClick: () => void): HTMLButtonElement {
  const b = h(
    'button',
    { class: `round-btn round-btn--${variant}`, type: 'button', 'aria-label': label },
    h('span', { class: 'round-btn__face' }, h('span', { class: 'round-btn__icon', html: svg })),
    h('span', { class: 'round-btn__label' }, label),
  );
  withSounds(b);
  b.addEventListener('click', onClick);
  return b;
}

export function createGameScreen(ctx: AppContext): Screen {
  const official = LEVELS[Math.min(Math.max(profile.get().lastLevelIndex, 0), LEVELS.length - 1)];
  const launch = getLaunch() ?? { meta: official, level: getLevelData(official.id), custom: false };
  const { meta, level, custom } = launch;
  const song = getSong(meta.songId);
  const held = new Set<string>();
  let session: GameSession | null = null;
  let overlay: Overlay = 'none';
  let lastDeathPercent = 0;

  // ---- HUD
  const progressFill = h('div', { class: 'hud-progress__fill' });
  const progressText = h('div', { class: 'hud-progress__text' }, '0%');
  const pauseBtn = h('button', { class: 'hud-pause', type: 'button', 'aria-label': 'Пауза', html: ICONS.pause });
  withSounds(pauseBtn);
  pauseBtn.addEventListener('click', () => openPause());
  const cpCount = h('span', { class: 'hud-practice__count' });
  const center = h('div', { class: 'hud-center' });
  const hud = h(
    'div',
    { class: 'hud' },
    h('div', { class: 'hud-progress' }, h('div', { class: 'hud-progress__track' }, progressFill), progressText),
    h('div', { class: 'hud-practice' }, 'Практика', cpCount),
    pauseBtn,
    h(
      'div',
      { class: 'hud-practice-bar' },
      button({ icon: ICONS.diamond, label: 'Чекпоинт', size: 'sm', sound: null, title: 'Поставить чекпоинт (Z)', onClick: () => session?.placeCheckpoint() }),
      button({ icon: ICONS.close, label: 'Удалить', size: 'sm', variant: 'red', sound: null, title: 'Удалить чекпоинт (X)', onClick: () => session?.removeCheckpoint() }),
    ),
    center,
  );
  const s = settings.get();
  hud.classList.toggle('no-bar', !s.showProgressBar);
  hud.classList.toggle('no-percent', !s.showPercent);

  // ---- Пауза
  const pauseBars = h('div', { class: 'pause__bars' });
  const modeLabel = h('div', { class: 'pause__mode' });
  const practiceBtn = roundButton(ICONS.diamond, 'Практика', 'practice', () => {
    showOverlay('none');
    session?.setPractice(!session.practice);
    syncPractice();
  });
  const pauseLayer = h(
    'div',
    { class: 'overlay' },
    h(
      'div',
      { class: 'panel pause' },
      h('h2', { class: 'pause__title' }, meta.name),
      modeLabel,
      pauseBars,
      h(
        'div',
        { class: 'pause__buttons' },
        roundButton(ICONS.home, 'Меню', 'green', exitToMenu),
        roundButton(ICONS.play, 'Продолжить', 'big', () => closePause()),
        roundButton(ICONS.restart, 'Заново', 'green', () => {
          showOverlay('none');
          session?.restart();
        }),
        practiceBtn,
      ),
      h(
        'div',
        { class: 'pause__sliders' },
        sliderRow('Музыка', s.musicVolume, (v) => settings.set({ musicVolume: v })),
        sliderRow('Звуки', s.sfxVolume, (v) => settings.set({ sfxVolume: v })),
      ),
    ),
  );

  // ---- Смерть (если быстрый рестарт выключен)
  const deathText = h('div', { class: 'deathmenu__text' });
  const deathLayer = h(
    'div',
    { class: 'overlay' },
    h(
      'div',
      { class: 'panel deathmenu' },
      h('h2', { class: 'deathmenu__title' }, 'Разбились!'),
      deathText,
      h(
        'div',
        { class: 'deathmenu__actions' },
        button({ label: 'Меню', icon: ICONS.home, variant: 'dark', onClick: exitToMenu }),
        button({ label: 'Заново', icon: ICONS.restart, onClick: () => retry(false) }),
      ),
    ),
  );

  // ---- Финиш
  const completeTitle = h('div', { class: 'complete__banner' });
  const completeStats = h('div', { class: 'complete__stats' });
  const completeStars = h('div', { class: 'complete__stars' });
  const completeLayer = h(
    'div',
    { class: 'overlay overlay--complete' },
    h(
      'div',
      { class: 'complete' },
      completeTitle,
      h(
        'div',
        { class: 'panel complete__panel' },
        completeStats,
        completeStars,
        h(
          'div',
          { class: 'complete__actions' },
          button({ label: 'Меню', icon: ICONS.home, variant: 'dark', onClick: exitToMenu }),
          button({ label: 'Ещё раз', icon: ICONS.restart, onClick: () => retry(true) }),
        ),
      ),
    ),
  );

  const el = h('div', { class: 'game' }, hud, pauseLayer, deathLayer, completeLayer, h('div', { class: 'game__curtain' }));

  // ---- Логика оверлеев
  function showOverlay(kind: Overlay): void {
    overlay = kind;
    pauseLayer.classList.toggle('is-open', kind === 'pause');
    deathLayer.classList.toggle('is-open', kind === 'death');
    completeLayer.classList.toggle('is-open', kind === 'complete');
  }

  function releaseAll(): void {
    held.clear();
    session?.setInput(false, performance.now());
  }

  function openPause(): void {
    releaseAll();
    if (!session || overlay !== 'none' || session.isComplete) return;
    session.pause();
    const p = getProgress(meta.id);
    pauseBars.replaceChildren(progressBar('Обычный режим', p.normal, 'normal'), progressBar('Практика', p.practice, 'practice'));
    modeLabel.textContent = session.practice ? 'Режим практики' : 'Обычный режим';
    practiceBtn.querySelector('.round-btn__label')!.textContent = session.practice ? 'Обычный' : 'Практика';
    showOverlay('pause');
  }

  function closePause(): void {
    if (overlay !== 'pause') return;
    showOverlay('none');
    session?.resume();
  }

  function retry(full: boolean): void {
    showOverlay('none');
    center.replaceChildren();
    if (full) session?.restart();
    else session?.respawn();
  }

  function exitToMenu(): void {
    showOverlay('none');
    ctx.router.back();
  }

  function syncPractice(): void {
    hud.classList.toggle('is-practice', !!session?.practice);
    cpCount.textContent = '';
  }

  function showNewBest(percent: number): void {
    const note = h('div', { class: 'newbest' }, h('div', { class: 'newbest__title' }, 'Новый рекорд!'), h('div', { class: 'newbest__value' }, `${percent}%`));
    center.replaceChildren(note);
    audio.sfx('record');
    window.setTimeout(() => note.remove(), 2000);
  }

  function showComplete(info: CompleteInfo): void {
    completeTitle.textContent = info.practice ? 'Практика пройдена!' : 'Уровень пройден!';
    const row = (label: string, value: string) => h('div', { class: 'complete__row' }, h('span', null, label), h('span', { class: 'complete__value' }, value));
    completeStats.replaceChildren(
      row('Попыток', String(info.attempts)),
      row('Прыжков', String(info.jumps)),
      row('Время', formatTime(info.time)),
    );
    if (custom) completeStars.replaceChildren('Уровень из редактора — звёзды не начисляются');
    else if (info.practice) completeStars.replaceChildren('Звёзды даются за прохождение в обычном режиме');
    else if (info.stars > 0) completeStars.replaceChildren(h('span', { class: 'complete__plus' }, `+${info.stars}`), icon(ICONS.star));
    else completeStars.replaceChildren('Звёзды за этот уровень уже получены');
    completeStars.classList.toggle('is-earned', info.stars > 0);
    showOverlay('complete');
  }

  const hooks: SessionHooks = {
    onAttempt() {
      center.replaceChildren();
    },
    onProgress(p) {
      progressFill.style.setProperty('--p', (p / 100).toFixed(4));
      progressText.textContent = `${Math.floor(p)}%`;
    },
    onDeath(info) {
      lastDeathPercent = info.percent;
      if (info.newBest) showNewBest(info.percent);
    },
    onDeathMenu() {
      deathText.textContent = `Пройдено ${lastDeathPercent}%`;
      showOverlay('death');
    },
    onComplete: showComplete,
    onCheckpoints(n) {
      cpCount.textContent = n ? ` · ${n}` : '';
    },
  };

  // ---- Ввод
  const syncInput = (stamp: number) => session?.setInput(held.size > 0, stamp);

  hud.addEventListener('pointerdown', (e) => {
    if ((e.target as HTMLElement).closest('button') || overlay !== 'none') return;
    e.preventDefault();
    held.add('pointer');
    syncInput(e.timeStamp);
  });
  const onPointerUp = (e: PointerEvent) => {
    if (held.delete('pointer')) syncInput(e.timeStamp);
  };
  const onKeyUp = (e: KeyboardEvent) => {
    if (held.delete(e.code)) syncInput(e.timeStamp);
  };
  const onBlur = () => openPause();
  const onVisibility = () => {
    if (document.hidden) openPause();
  };

  return {
    el,
    enter() {
      ctx.background?.setActive(false);
      audio.stopSong(0.15);
      if (!ctx.app) return;
      session = new GameSession(ctx.app, level, meta, song, hooks);
      session.start();
      window.addEventListener('pointerup', onPointerUp);
      window.addEventListener('pointercancel', onPointerUp);
      window.addEventListener('keyup', onKeyUp);
      window.addEventListener('blur', onBlur);
      document.addEventListener('visibilitychange', onVisibility);
    },
    leave() {
      session?.destroy();
      session = null;
      window.removeEventListener('pointerup', onPointerUp);
      window.removeEventListener('pointercancel', onPointerUp);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      document.removeEventListener('visibilitychange', onVisibility);
      ctx.background?.setActive(true);
      audio.startMenuMusic();
    },
    onKey(e) {
      if (e.repeat && !JUMP_KEYS.has(e.code)) return true;
      if (overlay === 'complete' || overlay === 'death') {
        if (e.code === 'Escape') exitToMenu();
        else if (e.code === 'Enter' || e.code === 'Space' || e.code === 'KeyR') retry(overlay === 'complete');
        return true;
      }
      if (e.code === 'Escape') {
        if (overlay === 'pause') closePause();
        else openPause();
        return true;
      }
      if (overlay === 'pause') return true;
      if (JUMP_KEYS.has(e.code)) {
        if (!e.repeat) {
          held.add(e.code);
          syncInput(e.timeStamp);
        }
        return true;
      }
      switch (e.code) {
        case 'KeyR':
          center.replaceChildren();
          session?.respawn();
          break;
        case 'KeyZ':
          session?.placeCheckpoint();
          break;
        case 'KeyX':
          session?.removeCheckpoint();
          break;
      }
      return true;
    },
  };
}
