import { h } from '../dom';
import { ICONS } from '../icons';
import { button } from '../components/button';
import { screenHeader } from '../components/common';
import { confirmDialog } from '../components/modal';
import { toast } from '../components/toast';
import { audio } from '../../core/AudioManager';
import { LEVELS } from '../../data/levels';
import { getLevelData } from '../../levels';
import { setLaunch } from '../../game/launch';
import {
  createCustomLevel,
  customFromLevelData,
  customMeta,
  deleteCustomLevel,
  exportCustomLevel,
  importCustomLevel,
  levelLength,
  listCustomLevels,
  songChoice,
  toLevelData,
  type CustomLevel,
} from '../../state/customLevels';
import { editorSession } from '../../editor/session';
import type { AppContext, Screen } from '../types';

function formatDate(ts: number): string {
  return new Date(ts).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function download(filename: string, text: string): void {
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  const a = h('a', { href: url, download: filename });
  document.body.append(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const safeFileName = (name: string) => name.replace(/[\\/:*?"<>|]+/g, '_').trim() || 'level';

export function createEditorList(ctx: AppContext): Screen {
  const list = h('div', { class: 'ed-list' });

  function open(level: CustomLevel): void {
    editorSession.levelId = level.id;
    ctx.router.go('editor');
  }

  function play(level: CustomLevel): void {
    if (!ctx.app) {
      toast('Игре нужен WebGL', 'warn');
      return;
    }
    setLaunch({ meta: customMeta(level), level: toLevelData(level), custom: true });
    ctx.router.go('game', 'fade');
  }

  function render(): void {
    const levels = listCustomLevels();
    list.replaceChildren();
    if (!levels.length) {
      list.append(
        h(
          'div',
          { class: 'ed-empty' },
          h('div', { class: 'ed-empty__title' }, 'Пока нет ни одного уровня'),
          h('div', null, 'Создайте новый или начните с копии официального — так проще разобраться, как всё устроено.'),
        ),
      );
      return;
    }
    levels.forEach((lvl, i) => {
      const card = h(
        'div',
        { class: 'ed-card rise', style: `--d:${Math.min(i, 8)};--accent:${lvl.colors.bg}` },
        h('div', { class: 'ed-card__swatch' }),
        h(
          'div',
          { class: 'ed-card__info' },
          h('div', { class: 'ed-card__name' }, lvl.name),
          h(
            'div',
            { class: 'ed-card__meta' },
            `♪ ${songChoice(lvl.songId).title} · ${lvl.objects.length} объектов · ${levelLength(lvl)} кл. · ${formatDate(lvl.updatedAt)}`,
          ),
        ),
        h(
          'div',
          { class: 'ed-card__actions' },
          button({ icon: ICONS.pencil, label: 'Изменить', size: 'sm', onClick: () => open(lvl) }),
          button({ icon: ICONS.play, label: 'Играть', size: 'sm', variant: 'blue', sound: 'play', onClick: () => play(lvl) }),
          button({
            icon: ICONS.download,
            size: 'icon',
            variant: 'dark',
            title: 'Сохранить в файл — чтобы отправить другу',
            onClick: () => {
              download(`${safeFileName(lvl.name)}.gdlevel.json`, exportCustomLevel(lvl));
              toast('Файл уровня сохранён — отправьте его другу');
            },
          }),
          button({
            icon: ICONS.copy,
            size: 'icon',
            variant: 'dark',
            title: 'Сделать копию',
            onClick: () => {
              createCustomLevel(`${lvl.name} (копия)`.slice(0, 40), { ...lvl, objects: lvl.objects.map((o) => ({ ...o })) });
              render();
            },
          }),
          button({
            icon: ICONS.close,
            size: 'icon',
            variant: 'red',
            title: 'Удалить',
            sound: 'back',
            onClick: async () => {
              const ok = await confirmDialog({
                title: 'Удалить уровень?',
                text: `«${lvl.name}» будет удалён без возможности восстановления.`,
                confirmLabel: 'Удалить',
                danger: true,
              });
              if (ok) {
                deleteCustomLevel(lvl.id);
                render();
              }
            },
          }),
        ),
      );
      list.append(card);
    });
  }

  // импорт файла уровня
  const fileInput = h('input', { type: 'file', accept: '.json,application/json', class: 'ed-hidden' });
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files?.[0];
    fileInput.value = '';
    if (!file) return;
    try {
      const lvl = importCustomLevel(await file.text());
      toast(`Уровень «${lvl.name}» добавлен`);
      render();
    } catch (err) {
      audio.sfx('error');
      toast(err instanceof Error ? err.message : 'Не удалось открыть файл', 'warn');
    }
  });

  const actions = h(
    'div',
    { class: 'ed-list__actions rise', style: '--d:1' },
    button({
      icon: ICONS.plus,
      label: 'Новый уровень',
      onClick: () => open(createCustomLevel(`Мой уровень ${listCustomLevels().length + 1}`)),
    }),
    button({ icon: ICONS.upload, label: 'Открыть файл', variant: 'blue', onClick: () => fileInput.click() }),
    ...LEVELS.map((meta) =>
      button({
        icon: ICONS.copy,
        label: `Копия «${meta.name}»`,
        size: 'sm',
        variant: 'dark',
        onClick: () => {
          customFromLevelData(`${meta.name} (копия)`, getLevelData(meta.id));
          toast('Копия создана — откройте её и посмотрите, как устроен уровень');
          render();
        },
      }),
    ),
  );

  const el = h(
    'div',
    { class: 'editor-list' },
    screenHeader('Редактор уровней', () => ctx.router.back()),
    actions,
    h('div', { class: 'ed-list__scroll panel rise', style: '--d:2' }, list),
    fileInput,
    h('div', { class: 'footer-hint' }, 'Уровни хранятся на этом компьютере. Чтобы поделиться — сохраните файл и отправьте другу, он откроет его кнопкой «Открыть файл».'),
  );

  render();

  return {
    el,
    enter() {
      audio.startMenuMusic();
    },
    back() {
      audio.sfx('back');
      ctx.router.back();
    },
  };
}
