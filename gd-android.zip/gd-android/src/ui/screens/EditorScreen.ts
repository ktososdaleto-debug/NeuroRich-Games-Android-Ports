import { h } from '../dom';
import { ICONS } from '../icons';
import { button, withSounds } from '../components/button';
import { toast } from '../components/toast';
import { audio } from '../../core/AudioManager';
import { getSong } from '../../audio/songs';
import { SPEED } from '../../game/physics';
import { setLaunch } from '../../game/launch';
import type { BlockTexture, ColorChannel, LevelObject, ObjectType, Zone } from '../../game/types';
import {
  customMeta,
  getCustomLevel,
  levelLength,
  SONG_CHOICES,
  toLevelData,
} from '../../state/customLevels';
import { EditorDoc } from '../../editor/EditorDoc';
import { EditorCanvas, type Tool } from '../../editor/EditorCanvas';
import {
  CHANNEL_NAMES,
  makeObject,
  PALETTE,
  PALETTE_GROUPS,
  paletteItem,
  TEXTURE_NAMES,
  ZONE_NAMES,
} from '../../editor/catalog';
import { drawEditorObject } from '../../editor/drawObject';
import { editorSession } from '../../editor/session';
import type { AppContext, Screen } from '../types';

const TOOL_HINTS: Record<Tool, string> = {
  build: 'ЛКМ — поставить, протяжка — рисовать кистью. Блок и лаву растягивайте мышью. R — повернуть шип',
  select: 'Клик — выбрать, Shift — добавить, рамка — несколько, перетаскивание — сдвиг. Ctrl+C / V / D',
  erase: 'ЛКМ — стереть, можно протяжкой',
};

const isField = (t: EventTarget | null) => t instanceof HTMLInputElement || t instanceof HTMLSelectElement || t instanceof HTMLTextAreaElement;

/** Иконка объекта для палитры */
function thumbnail(type: ObjectType, theme: 'classic' | 'minecraft', tex: BlockTexture): HTMLCanvasElement {
  const size = 44;
  const canvas = document.createElement('canvas');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = size * dpr;
  canvas.height = size * dpr;
  canvas.style.width = `${size}px`;
  canvas.style.height = `${size}px`;
  const c = canvas.getContext('2d')!;
  c.scale(dpr, dpr);
  const o = makeObject(type, 0, 0, { rot: 0, tex });
  if (o.type.startsWith('portal-')) o.h = 2;
  const isTrigger = o.type.startsWith('trigger');
  const span = o.type.startsWith('portal-') ? 2.3 : 1.3;
  const z = size / span;
  const ox = isTrigger ? o.x : 0.5;
  const oy = (o.h && o.type.startsWith('portal-') ? o.h : 1) / 2;
  drawEditorObject(c, o, { sx: (x) => size / 2 + (x - ox) * z, sy: (y) => size / 2 - (y - oy) * z, z }, theme, false);
  return canvas;
}

function field(label: string, control: HTMLElement): HTMLElement {
  return h('label', { class: 'ed-field' }, h('span', { class: 'ed-field__label' }, label), control);
}

function numberInput(value: number, step: number, min: number, onCommit: (v: number) => void): HTMLInputElement {
  const input = h('input', { type: 'number', class: 'ed-input', step: String(step), min: String(min) });
  input.value = String(value);
  input.addEventListener('change', () => {
    const v = Number(input.value);
    if (Number.isFinite(v)) onCommit(Math.max(min, v));
  });
  return input;
}

function selectInput<T extends string>(options: Record<T, string>, value: T, onChange: (v: T) => void): HTMLSelectElement {
  const select = h('select', { class: 'ed-input' });
  for (const [k, label] of Object.entries(options) as Array<[T, string]>) {
    const opt = h('option', { value: k }, label);
    if (k === value) opt.selected = true;
    select.append(opt);
  }
  select.addEventListener('change', () => onChange(select.value as T));
  return select;
}

function colorInput(value: string, onChange: (v: string) => void): HTMLInputElement {
  const input = h('input', { type: 'color', class: 'ed-color' });
  input.value = value;
  input.addEventListener('change', () => onChange(input.value));
  return input;
}

export function createEditorScreen(ctx: AppContext): Screen {
  const stored = editorSession.levelId ? getCustomLevel(editorSession.levelId) : null;
  if (!stored) {
    // уровень удалили или не выбрали — возвращаемся к списку
    const el = h('div', { class: 'editor' });
    return { el, enter: () => window.setTimeout(() => ctx.router.back(), 0) };
  }
  const doc = new EditorDoc(stored);
  const level = doc.level;
  const canvas = new EditorCanvas(doc, (info) => {
    cursorText.textContent = `x ${info.x} · y ${info.y} · доля ${info.beat.toFixed(2)} · такт ${Math.floor(info.beat / 4) + 1}`;
  });
  canvas.placeOpts.tex = level.theme === 'minecraft' ? 'grass' : 'stone';
  const cam = editorSession.cameras.get(level.id);
  if (cam) Object.assign(canvas, cam);

  // ---- Верхняя панель
  const nameBtn = h('button', { class: 'ed-name', type: 'button', title: 'Настройки уровня' }, level.name);
  withSounds(nameBtn);
  nameBtn.addEventListener('click', () => openSettings());

  const toolButtons = new Map<Tool, HTMLButtonElement>();
  const toolBtn = (tool: Tool, svg: string, title: string) => {
    const b = button({ icon: svg, size: 'icon', variant: 'dark', title, sound: 'toggle', onClick: () => setTool(tool) });
    toolButtons.set(tool, b);
    return b;
  };
  const undoBtn = button({ icon: ICONS.undo, size: 'icon', variant: 'dark', title: 'Отменить (Ctrl+Z)', sound: 'toggle', onClick: () => doc.undo() });
  const redoBtn = button({ icon: ICONS.redo, size: 'icon', variant: 'dark', title: 'Повторить (Ctrl+Y)', sound: 'toggle', onClick: () => doc.redo() });
  const snapBtn = button({ icon: ICONS.grid, label: '1', size: 'sm', variant: 'dark', title: 'Шаг сетки: 1 или ½ клетки (G)', sound: 'toggle', onClick: () => toggleSnap() });
  const musicBtn = button({ icon: ICONS.music, label: 'Музыка', size: 'sm', variant: 'blue', title: 'Прослушать трек с текущего места (Пробел)', sound: null, onClick: () => toggleMusic() });
  const testBtn = button({ icon: ICONS.play, label: 'Тест', size: 'sm', title: 'Сыграть уровень (Ctrl+Enter)', sound: 'play', onClick: () => playtest() });

  const top = h(
    'header',
    { class: 'editor-top' },
    button({ icon: ICONS.back, size: 'icon', title: 'К списку уровней', sound: 'back', onClick: () => exit() }),
    nameBtn,
    h('div', { class: 'ed-group' }, toolBtn('build', ICONS.pencil, 'Строить (B)'), toolBtn('select', ICONS.cursor, 'Выбор (V)'), toolBtn('erase', ICONS.eraser, 'Ластик (E)')),
    h('div', { class: 'ed-group' }, undoBtn, redoBtn),
    snapBtn,
    h('div', { class: 'ed-spacer' }),
    musicBtn,
    button({ icon: ICONS.gear, size: 'icon', variant: 'dark', title: 'Настройки уровня', onClick: () => openSettings() }),
    testBtn,
  );

  // ---- Палитра
  const paletteButtons = new Map<ObjectType, HTMLButtonElement>();
  const palette = h('aside', { class: 'panel editor-palette' });

  function renderPalette(): void {
    paletteButtons.clear();
    palette.replaceChildren();
    for (const group of PALETTE_GROUPS) {
      const items = PALETTE.filter((p) => p.group === group && (p.type !== 'trigger-zone' || level.theme === 'minecraft'));
      palette.append(h('div', { class: 'ed-palette__title' }, group));
      const grid = h('div', { class: 'ed-palette__grid' });
      for (const item of items) {
        const b = h(
          'button',
          { class: 'ed-item', type: 'button', title: item.key ? `${item.label} (${item.key})` : item.label },
          thumbnail(item.type, level.theme, canvas.placeOpts.tex),
          h('span', { class: 'ed-item__label' }, item.label),
          item.key ? h('span', { class: 'ed-item__key' }, item.key) : null,
        );
        withSounds(b, 'toggle');
        b.addEventListener('click', () => pick(item.type));
        paletteButtons.set(item.type, b);
        grid.append(b);
      }
      palette.append(grid);
      if (group === 'Блоки' && level.theme === 'minecraft') {
        palette.append(
          field(
            'Текстура',
            selectInput(TEXTURE_NAMES, canvas.placeOpts.tex, (tex) => {
              canvas.placeOpts.tex = tex;
              renderPalette();
            }),
          ),
        );
      }
    }
    syncToolbar();
  }

  // ---- Инспектор
  const inspector = h('aside', { class: 'panel editor-inspector' });

  function renderInspector(): void {
    const sel = [...doc.selection];
    inspector.replaceChildren();
    if (!sel.length) {
      inspector.append(
        h('div', { class: 'ed-insp__title' }, 'Подсказки'),
        h(
          'ul',
          { class: 'ed-tips' },
          h('li', null, 'Жёлтые линии — доли трека, яркие — такты. Ставьте препятствия на доли — будет в ритм.'),
          h('li', null, 'Куб прыгает ровно на 1 долю (при 156 BPM): шип в 2 клетках после доли — прыжок точно в бит.'),
          h('li', null, 'Порталы ставятся во всю высоту. После них появляется потолок (пунктир).'),
          h('li', null, 'Колесо — прокрутка, Ctrl+колесо — масштаб, ПКМ — двигать вид.'),
          h('li', null, 'Home / End — к старту или финишу, Пробел — музыка, Ctrl+Enter — тест.'),
        ),
        h('div', { class: 'ed-insp__stats' }, `Объектов: ${doc.objects.length} · длина ${levelLength(level)} кл.`),
      );
      return;
    }
    if (sel.length > 1) {
      inspector.append(
        h('div', { class: 'ed-insp__title' }, `Выбрано: ${sel.length}`),
        h(
          'div',
          { class: 'ed-insp__actions' },
          button({ label: 'Повернуть шипы (R)', size: 'sm', variant: 'blue', onClick: () => doc.rotate(sel) }),
          button({ label: 'Дублировать (Ctrl+D)', size: 'sm', variant: 'blue', onClick: () => doc.duplicate() }),
          button({ label: 'Удалить (Del)', size: 'sm', variant: 'red', onClick: () => doc.remove(sel) }),
        ),
      );
      return;
    }
    const o = sel[0];
    const set = (patch: Partial<LevelObject>) => doc.update(o, patch);
    const fields: HTMLElement[] = [
      field('X', numberInput(o.x, 0.5, -10, (x) => set({ x }))),
      field('Y', numberInput(o.y, 0.5, 0, (y) => set({ y }))),
    ];
    if (o.type === 'block') {
      fields.push(
        field('Ширина', numberInput(o.w ?? 1, 0.5, 0.5, (w) => set({ w }))),
        field('Высота', numberInput(o.h ?? 1, 0.5, 0.5, (hh) => set({ h: hh }))),
      );
      if (level.theme === 'minecraft') fields.push(field('Текстура', selectInput(TEXTURE_NAMES, o.tex ?? 'stone', (tex) => set({ tex }))));
    }
    if (o.type === 'lava') fields.push(field('Ширина', numberInput(o.w ?? 1, 0.5, 0.5, (w) => set({ w }))));
    if (o.type === 'spike' || o.type === 'small-spike') {
      fields.push(
        field(
          'Поворот',
          selectInput<'0' | '90' | '180' | '270'>({ '0': 'Вверх', '90': 'Вправо', '180': 'Вниз', '270': 'Влево' }, String(o.rot ?? 0) as '0', (r) =>
            set({ rot: Number(r) as LevelObject['rot'] }),
          ),
        ),
      );
    }
    if (o.type.startsWith('portal-')) fields.push(field('Высота', numberInput(o.h ?? 3, 1, 1, (hh) => set({ h: hh }))));
    if (o.type === 'trigger-color') {
      fields.push(
        field('Что красим', selectInput(CHANNEL_NAMES, o.channel ?? 'bg', (channel: ColorChannel) => set({ channel }))),
        field('Цвет', colorInput(o.color ?? '#ffffff', (color) => set({ color }))),
        field(
          'Плавно, доли',
          numberInput(+((o.duration ?? 0) / (canvas.beatBlocks || 4)).toFixed(2), 0.5, 0, (beats) => set({ duration: beats * canvas.beatBlocks })),
        ),
      );
    }
    if (o.type === 'trigger-zone') fields.push(field('Зона', selectInput(ZONE_NAMES, o.zone ?? 'surface', (zone: Zone) => set({ zone }))));

    inspector.append(
      h('div', { class: 'ed-insp__title' }, paletteItem(o.type).label),
      h('div', { class: 'ed-fields' }, ...fields),
      h(
        'div',
        { class: 'ed-insp__actions' },
        o.type === 'spike' || o.type === 'small-spike'
          ? button({ label: 'Повернуть (R)', size: 'sm', variant: 'blue', onClick: () => doc.rotate(sel) })
          : null,
        button({ label: 'Удалить (Del)', size: 'sm', variant: 'red', onClick: () => doc.remove(sel) }),
      ),
    );
  }

  // ---- Нижняя строка
  const cursorText = h('span', { class: 'ed-status__cursor' }, 'Наведите на поле');
  const hintText = h('span', { class: 'ed-status__hint' });

  const stage = h('div', { class: 'editor-stage' }, canvas.el);
  const body = h('div', { class: 'editor-body' }, palette, stage, inspector);
  const status = h('footer', { class: 'editor-status' }, cursorText, hintText);

  // ---- Настройки уровня
  const settingsLayer = h('div', { class: 'overlay' });

  function openSettings(): void {
    const nameInput = h('input', { type: 'text', class: 'ed-input', maxlength: '40' });
    nameInput.value = level.name;
    nameInput.addEventListener('input', () => {
      level.name = nameInput.value.trim() || 'Без названия';
      nameBtn.textContent = level.name;
      doc.changed();
    });
    const songs = Object.fromEntries(SONG_CHOICES.map((s) => [s.id, `${s.title} · ${s.bpm} BPM`])) as Record<string, string>;
    const colorField = (label: string, key: keyof typeof level.colors) =>
      field(
        label,
        colorInput(level.colors[key] ?? '#ffffff', (v) => {
          level.colors = { ...level.colors, [key]: v };
          doc.changed();
        }),
      );
    const autoLen = h('input', { type: 'checkbox' });
    autoLen.checked = level.length === null;
    const lenInput = numberInput(levelLength(level), 1, 20, (v) => {
      level.length = v;
      autoLen.checked = false;
      doc.changed();
    });
    autoLen.addEventListener('change', () => {
      level.length = autoLen.checked ? null : levelLength(level);
      lenInput.value = String(levelLength(level));
      doc.changed();
    });

    settingsLayer.replaceChildren(
      h(
        'div',
        { class: 'panel ed-settings' },
        h('h2', { class: 'panel__title' }, 'Настройки уровня'),
        h(
          'div',
          { class: 'ed-fields' },
          field('Название', nameInput),
          field(
            'Музыка',
            selectInput(songs, level.songId, (id) => {
              level.songId = id;
              doc.changed();
            }),
          ),
          field(
            'Оформление',
            selectInput({ classic: 'Классика (неон)', minecraft: 'Блоки (Minecraft)' }, level.theme, (theme) => {
              level.theme = theme;
              canvas.placeOpts.tex = theme === 'minecraft' ? 'grass' : 'stone';
              renderPalette();
              doc.changed();
            }),
          ),
          colorField('Цвет фона', 'bg'),
          colorField('Цвет земли', 'ground'),
          colorField('Цвет линий', 'line'),
          field('Длина: авто', autoLen),
          field('Длина, клеток', lenInput),
        ),
        h('div', { class: 'ed-settings__actions' }, button({ label: 'Готово', onClick: () => closeSettings() })),
      ),
    );
    settingsLayer.classList.add('is-open');
    nameInput.focus();
  }

  function closeSettings(): void {
    settingsLayer.classList.remove('is-open');
    doc.save();
  }

  const el = h('div', { class: 'editor' }, top, body, status, settingsLayer);

  // ---- Действия
  function setTool(tool: Tool): void {
    canvas.tool = tool;
    syncToolbar();
    canvas.invalidate();
  }

  function pick(type: ObjectType): void {
    canvas.item = type;
    setTool('build');
  }

  function toggleSnap(): void {
    canvas.snap = canvas.snap === 1 ? 0.5 : 1;
    syncToolbar();
    canvas.invalidate();
  }

  function syncToolbar(): void {
    for (const [tool, b] of toolButtons) b.classList.toggle('is-active', canvas.tool === tool);
    for (const [type, b] of paletteButtons) b.classList.toggle('is-active', canvas.tool === 'build' && canvas.item === type);
    snapBtn.querySelector('.btn__label')!.textContent = canvas.snap === 1 ? '1' : '½';
    undoBtn.disabled = !doc.canUndo;
    redoBtn.disabled = !doc.canRedo;
    hintText.textContent = TOOL_HINTS[canvas.tool];
  }

  let musicRaf = 0;
  function toggleMusic(): void {
    if (musicRaf) return stopMusic();
    const song = getSong(level.songId);
    const from = Math.max(0, canvas.camX + 2) / SPEED;
    audio.playSong(song, from);
    musicBtn.classList.add('is-active');
    const loop = () => {
      canvas.setPlayhead(Math.max(0, audio.songTime()) * SPEED);
      musicRaf = requestAnimationFrame(loop);
    };
    musicRaf = requestAnimationFrame(loop);
  }

  function stopMusic(): void {
    cancelAnimationFrame(musicRaf);
    musicRaf = 0;
    audio.stopSong(0.1);
    canvas.setPlayhead(null);
    musicBtn.classList.remove('is-active');
  }

  function rememberCamera(): void {
    editorSession.cameras.set(level.id, { camX: canvas.camX, camY: canvas.camY, zoom: canvas.zoom });
  }

  function playtest(): void {
    stopMusic();
    doc.save();
    rememberCamera();
    setLaunch({ meta: customMeta(level), level: toLevelData(level), custom: true });
    ctx.router.go('game', 'fade');
  }

  function exit(): void {
    doc.save();
    rememberCamera();
    ctx.router.back();
  }

  const offDoc = doc.onChange(() => {
    renderInspector();
    syncToolbar();
  });
  renderPalette();
  renderInspector();

  return {
    el,
    enter() {
      audio.stopSong(0.3);
    },
    leave() {
      stopMusic();
      doc.save();
      rememberCamera();
      offDoc();
      canvas.destroy();
    },
    back() {
      if (doc.selection.size) doc.select([]);
      else exit();
    },
    onKey(e) {
      if (settingsLayer.classList.contains('is-open')) {
        if (e.code === 'Escape' || (e.code === 'Enter' && !isField(e.target))) closeSettings();
        return e.code === 'Escape';
      }
      if (isField(e.target)) {
        if (e.code === 'Escape') (e.target as HTMLElement).blur();
        return e.code === 'Escape';
      }
      const ctrl = e.ctrlKey || e.metaKey;
      if (e.code === 'Space') {
        if (!e.repeat) toggleMusic();
        return true;
      }
      if (ctrl && e.code === 'Enter') {
        playtest();
        return true;
      }
      if (ctrl && e.code === 'KeyS') {
        doc.save();
        toast('Уровень сохранён');
        return true;
      }
      if (!ctrl && /^Digit[1-9]$/.test(e.code)) {
        const item = PALETTE.find((p) => p.key === e.code.slice(5));
        if (item) pick(item.type);
        return true;
      }
      if (canvas.handleKey(e)) {
        syncToolbar();
        return true;
      }
      return false;
    },
  };
}
