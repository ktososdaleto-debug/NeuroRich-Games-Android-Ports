import { h, kbd } from '../dom';
import { ICONS } from '../icons';
import { button } from '../components/button';
import { screenHeader } from '../components/common';
import { segmentedRow, sliderRow, toggleRow } from '../components/controls';
import { confirmDialog } from '../components/modal';
import { toast } from '../components/toast';
import { settings, type ParticleQuality, type Settings } from '../../state/settings';
import { resetProgress } from '../../state/profile';
import { isFullscreen, setFullscreen } from '../../core/fullscreen';
import { audio } from '../../core/AudioManager';
import { APP_VERSION } from '../../config';
import type { AppContext, Screen } from '../types';

const PARTICLE_OPTIONS: ReadonlyArray<{ value: ParticleQuality; label: string }> = [
  { value: 'off', label: 'Выкл' },
  { value: 'low', label: 'Мало' },
  { value: 'high', label: 'Много' },
];

const KEYS: Array<[string[], string]> = [
  [['Пробел', '↑', 'W', 'ЛКМ'], 'Прыжок (держите — прыжки подряд)'],
  [['Esc'], 'Пауза / назад'],
  [['R'], 'Рестарт (в практике — с чекпоинта)'],
  [['Z'], 'Поставить чекпоинт (практика)'],
  [['X'], 'Удалить чекпоинт'],
  [['←', '→'], 'Выбор уровня'],
  [['F11'], 'Полный экран'],
];

function section(title: string, svg: string, color: string, index: number, ...rows: Node[]): HTMLElement {
  return h(
    'section',
    { class: 'panel settings-section rise', style: `--d:${index + 1}` },
    h(
      'div',
      { class: 'settings-section__head' },
      h('span', { class: 'settings-section__icon', style: `--c:${color}`, html: svg }),
      h('h2', { class: 'settings-section__title' }, title),
    ),
    ...rows,
  );
}

export function createSettings(ctx: AppContext): Screen {
  const s = settings.get();
  const set = (patch: Partial<Settings>) => settings.set(patch);

  const keyList = h(
    'div',
    { class: 'keys' },
    ...KEYS.map(([keys, desc]) =>
      h('div', { class: 'keys__row' }, h('span', { class: 'keys__keys' }, ...keys.map(kbd)), h('span', { class: 'keys__desc' }, desc)),
    ),
  );

  const resetProgressBtn = button({
    label: 'Сбросить прогресс',
    variant: 'red',
    size: 'sm',
    onClick: async () => {
      const ok = await confirmDialog({
        title: 'Сбросить прогресс?',
        text: 'Пройденные уровни, звёзды и статистика будут удалены. Это действие нельзя отменить.',
        confirmLabel: 'Сбросить',
        danger: true,
      });
      if (ok) {
        resetProgress();
        toast('Прогресс сброшен');
      }
    },
  });

  const resetSettingsBtn = button({
    label: 'Настройки по умолчанию',
    variant: 'dark',
    size: 'sm',
    onClick: async () => {
      const ok = await confirmDialog({
        title: 'Вернуть настройки?',
        text: 'Громкость, графика и параметры игры вернутся к значениям по умолчанию.',
        confirmLabel: 'Вернуть',
      });
      if (ok) {
        settings.reset();
        ctx.router.refresh();
        toast('Настройки сброшены');
      }
    },
  });

  const grid = h(
    'div',
    { class: 'settings__grid' },
    section(
      'Звук',
      ICONS.speaker,
      'var(--pink-2)',
      0,
      sliderRow('Музыка', s.musicVolume, (v) => set({ musicVolume: v })),
      sliderRow('Звуковые эффекты', s.sfxVolume, (v) => set({ sfxVolume: v })),
      toggleRow('Музыка в меню', s.menuMusic, (v) => set({ menuMusic: v })),
    ),
    section(
      'Графика',
      ICONS.monitor,
      'var(--blue-2)',
      1,
      segmentedRow('Частицы', PARTICLE_OPTIONS, s.particles, (v) => set({ particles: v })),
      toggleRow('Анимации меню', s.menuAnimations, (v) => set({ menuAnimations: v }), 'Движение фона, логотипа и кнопок'),
      toggleRow('Показывать FPS', s.showFps, (v) => set({ showFps: v })),
      toggleRow('Полноэкранный режим', isFullscreen(), (v) => void setFullscreen(v)),
    ),
    section(
      'Игровой процесс',
      ICONS.cube,
      'var(--green-2)',
      2,
      toggleRow('Полоса прогресса', s.showProgressBar, (v) => set({ showProgressBar: v })),
      toggleRow('Процент прохождения', s.showPercent, (v) => set({ showPercent: v })),
      toggleRow('Счётчик попыток', s.showAttempts, (v) => set({ showAttempts: v })),
      toggleRow('Быстрый рестарт', s.autoRetry, (v) => set({ autoRetry: v }), 'Сразу начинать заново после ошибки'),
    ),
    section(
      'Управление',
      ICONS.keyboard,
      'var(--yellow-3)',
      3,
      keyList,
      h('p', { class: 'note' }, 'Переназначение клавиш появится в следующих обновлениях.'),
    ),
    section(
      'Данные',
      ICONS.data,
      'var(--red-2)',
      4,
      h('div', { class: 'data-actions' }, resetProgressBtn, resetSettingsBtn),
      h('p', { class: 'note' }, 'Прогресс и настройки хранятся локально на этом компьютере.'),
    ),
  );

  const el = h(
    'div',
    { class: 'settings' },
    screenHeader('Настройки', () => ctx.router.back()),
    h('div', { class: 'settings__body' }, grid),
    h('div', { class: 'footer-hint' }, `Geometry Dash · Claude Edition · v${APP_VERSION}`),
  );

  return {
    el,
    back() {
      audio.sfx('back');
      ctx.router.back();
    },
  };
}
