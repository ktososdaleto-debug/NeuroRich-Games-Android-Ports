import { h, icon, kbd, replayClass } from '../dom';
import { ICONS } from '../icons';
import { withSounds } from '../components/button';
import { progressBar, screenHeader, starsBadge } from '../components/common';
import { difficultyFace } from '../components/difficultyFace';
import { toast } from '../components/toast';
import { LEVELS, type LevelMeta } from '../../data/levels';
import { DIFFICULTIES } from '../../data/difficulty';
import { getProgress, profile, totalStars } from '../../state/profile';
import { audio } from '../../core/AudioManager';
import { setLaunch } from '../../game/launch';
import { getLevelData } from '../../levels';
import type { AppContext, Screen } from '../types';

const SWIPE_PX = 60;
const WHEEL_COOLDOWN_MS = 380;
const SOON_COLOR = '#4b4f7a';

function arrowButton(svg: string, label: string, onClick: () => void): HTMLButtonElement {
  const b = h('button', { class: 'arrow-btn', type: 'button', 'aria-label': label, html: svg });
  withSounds(b, null);
  b.addEventListener('click', onClick);
  return b;
}

export function createLevelSelect(ctx: AppContext): Screen {
  // последняя карточка — «скоро новые уровни», она не играется
  const cards = [...LEVELS.map((lvl) => buildLevelCard(lvl)), buildSoonCard()];
  const count = cards.length;
  let index = Math.min(Math.max(profile.get().lastLevelIndex, 0), LEVELS.length - 1);

  const track = h('div', { class: 'carousel__track' }, ...cards);
  const viewport = h('div', { class: 'carousel__viewport' }, track);
  const dots = cards.map((_, i) => {
    const color = LEVELS[i]?.color ?? SOON_COLOR;
    const d = h('button', { class: 'dot', type: 'button', 'aria-label': LEVELS[i]?.name ?? 'Скоро', style: `--accent:${color}` });
    d.addEventListener('click', () => select(i));
    return d;
  });

  const el = h(
    'div',
    { class: 'levels' },
    screenHeader('Уровни', () => ctx.router.back(), starsBadge(totalStars())),
    h(
      'div',
      { class: 'carousel rise', style: '--d:1' },
      arrowButton(ICONS.left, 'Предыдущий', () => select(index - 1)),
      viewport,
      arrowButton(ICONS.right, 'Следующий', () => select(index + 1)),
    ),
    h('div', { class: 'dots rise', style: '--d:2' }, ...dots),
    h('div', { class: 'footer-hint rise', style: '--d:3' }, kbd('←'), kbd('→'), ' выбор ', kbd('Enter'), ' играть ', kbd('Esc'), ' назад'),
  );

  function select(i: number, silent = false): void {
    index = (i + count) % count;
    track.style.transform = `translateX(${-index * 100}%)`;
    cards.forEach((c, k) => c.classList.toggle('is-active', k === index));
    dots.forEach((d, k) => d.classList.toggle('is-active', k === index));
    const lvl = LEVELS[index];
    ctx.background?.setAccent(lvl ? lvl.color : SOON_COLOR);
    if (!silent) {
      audio.sfx('select');
      if (lvl) profile.set({ lastLevelIndex: index });
    }
  }

  function play(): void {
    if (!LEVELS[index]) {
      audio.sfx('error');
      replayClass(cards[index], 'shake');
      return;
    }
    if (!ctx.app) {
      audio.sfx('error');
      toast('Игре нужен WebGL — обновите драйвер видеокарты или браузер', 'warn');
      return;
    }
    audio.sfx('play');
    replayClass(cards[index], 'is-launch');
    setLaunch({ meta: LEVELS[index], level: getLevelData(LEVELS[index].id), custom: false });
    ctx.router.go('game', 'fade');
  }

  // --- Свайпы мышью/пальцем (клик после свайпа игнорируется)
  let downX: number | null = null;
  let dragged = false;
  viewport.addEventListener('pointerdown', (e) => {
    downX = e.clientX;
    dragged = false;
  });
  viewport.addEventListener('pointermove', (e) => {
    if (downX !== null && Math.abs(e.clientX - downX) > 12) dragged = true;
  });
  viewport.addEventListener('pointerup', (e) => {
    if (downX === null) return;
    const dx = e.clientX - downX;
    downX = null;
    if (Math.abs(dx) > SWIPE_PX) select(index + (dx < 0 ? 1 : -1));
  });
  viewport.addEventListener('pointerleave', () => {
    downX = null;
  });

  let wheelLockedUntil = 0;
  viewport.addEventListener(
    'wheel',
    (e) => {
      const now = performance.now();
      const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
      if (now < wheelLockedUntil || Math.abs(d) < 8) return;
      wheelLockedUntil = now + WHEEL_COOLDOWN_MS;
      select(index + (d > 0 ? 1 : -1));
    },
    { passive: true },
  );

  cards.forEach((card, i) => {
    const panel = card.querySelector<HTMLElement>('.level-card__panel')!;
    panel.addEventListener('pointerenter', () => audio.sfx('hover'));
    panel.addEventListener('click', () => {
      if (dragged) return;
      if (i === index) play();
      else select(i);
    });
  });

  select(index, true);

  return {
    el,
    enter() {
      // прогресс-бары «наливаются» после появления экрана
      window.setTimeout(() => el.classList.add('is-ready'), 250);
    },
    leave() {
      ctx.background?.setAccent(null);
    },
    back() {
      audio.sfx('back');
      ctx.router.back();
    },
    onKey(e) {
      switch (e.code) {
        case 'ArrowLeft':
        case 'KeyA':
          select(index - 1);
          return true;
        case 'ArrowRight':
        case 'KeyD':
          select(index + 1);
          return true;
        case 'Enter':
        case 'Space':
          if (!e.repeat) play();
          return true;
      }
      return false;
    },
  };
}

function buildLevelCard(lvl: LevelMeta): HTMLElement {
  const prog = getProgress(lvl.id);
  const diff = DIFFICULTIES[lvl.difficulty];
  return h(
    'div',
    { class: 'level-card', style: `--accent:${lvl.color}` },
    h(
      'div',
      { class: 'level-card__panel' },
      h('div', { class: 'level-card__face', html: difficultyFace(lvl.difficulty) }),
      h(
        'div',
        { class: 'level-card__info' },
        h('div', { class: 'level-card__name' }, lvl.name),
        h(
          'div',
          { class: 'level-card__meta' },
          h('span', { class: 'tag', style: `--c:${diff.color}` }, diff.label),
          prog.completed ? h('span', { class: 'tag tag--done' }, 'Пройден') : null,
        ),
        h('div', { class: 'level-card__song' }, `♪ ${lvl.song.title} — ${lvl.song.author}`),
      ),
      h(
        'div',
        { class: `level-card__stars${prog.completed ? ' is-earned' : ''}` },
        h('span', null, String(lvl.stars)),
        icon(ICONS.star),
      ),
    ),
    h(
      'div',
      { class: 'level-card__bars' },
      progressBar('Обычный режим', prog.normal, 'normal'),
      progressBar('Практика', prog.practice, 'practice'),
    ),
    h('div', { class: 'level-card__stats' }, `Попыток: ${prog.attempts} · Прыжков: ${prog.jumps}`),
  );
}

function buildSoonCard(): HTMLElement {
  return h(
    'div',
    { class: 'level-card level-card--soon', style: `--accent:${SOON_COLOR}` },
    h(
      'div',
      { class: 'level-card__panel' },
      h('div', { class: 'level-card__soon-mark' }, '?'),
      h(
        'div',
        { class: 'level-card__info' },
        h('div', { class: 'level-card__name' }, 'Скоро…'),
        h('div', { class: 'level-card__song' }, 'Новые уровни уже в разработке'),
      ),
    ),
  );
}
