import { h, icon, kbd, replayClass } from '../dom';
import { ICONS } from '../icons';
import { button, withSounds } from '../components/button';
import { createLogo, starsBadge } from '../components/common';
import { createCubeCanvas } from '../../render/cubeArt';
import { audio } from '../../core/AudioManager';
import { toggleFullscreen } from '../../core/fullscreen';
import { settings } from '../../state/settings';
import { profile, totalStars } from '../../state/profile';
import { APP_STAGE, APP_VERSION } from '../../config';
import type { AppContext, Screen } from '../types';

export function createMainMenu(ctx: AppContext): Screen {
  const skin = profile.get().skin;

  // --- Центральная кнопка «Играть»
  const playBtn = h(
    'button',
    { class: 'play-btn', type: 'button', 'aria-label': 'Играть' },
    h('span', { class: 'play-btn__ring loop-anim' }),
    h('span', { class: 'play-btn__body loop-anim' }, h('span', { class: 'play-btn__icon', html: ICONS.play })),
    h('span', { class: 'play-btn__pulse' }),
    h('span', { class: 'play-btn__label' }, 'Играть'),
  );
  withSounds(playBtn, 'play');
  playBtn.addEventListener('click', () => ctx.router.go('levels'));

  // --- Боковые кнопки
  const cube = createCubeCanvas(78, skin, { pad: 20 });
  cube.classList.add('menu-cube');
  const skinsBtn = h(
    'button',
    { class: 'side-btn side-btn--left', type: 'button', 'aria-label': 'Иконки' },
    cube,
    h('span', { class: 'side-btn__label' }, 'Иконки'),
  );
  withSounds(skinsBtn);
  skinsBtn.addEventListener('click', () => ctx.router.go('skins'));

  const editorBtn = h(
    'button',
    { class: 'side-btn side-btn--right', type: 'button', 'aria-label': 'Редактор' },
    h('span', { class: 'side-btn__icon', html: ICONS.pencil }),
    h('span', { class: 'side-btn__label' }, 'Редактор'),
  );
  withSounds(editorBtn);
  editorBtn.addEventListener('click', () => ctx.router.go('editorList'));

  const settingsBtn = button({
    icon: ICONS.gear,
    size: 'icon',
    variant: 'dark',
    title: 'Настройки (O)',
    onClick: () => ctx.router.go('settings'),
  });

  // --- Верхняя панель
  const musicBtn = button({
    icon: settings.get().menuMusic ? ICONS.music : ICONS.musicOff,
    size: 'icon',
    variant: 'dark',
    title: 'Музыка вкл/выкл',
    sound: 'toggle',
    onClick: () => settings.set({ menuMusic: !settings.get().menuMusic }),
  });
  const offSettings = settings.subscribe((s, prev) => {
    if (s.menuMusic === prev.menuMusic) return;
    musicBtn.querySelector('.btn__icon')!.innerHTML = s.menuMusic ? ICONS.music : ICONS.musicOff;
  });
  const fsBtn = button({
    icon: ICONS.fullscreen,
    size: 'icon',
    variant: 'dark',
    title: 'Полный экран',
    onClick: () => void toggleFullscreen(),
  });

  const el = h(
    'div',
    { class: 'main-menu' },
    h(
      'div',
      { class: 'main-menu__top rise', style: '--d:3' },
      starsBadge(totalStars()),
      h('div', { class: 'main-menu__top-right' }, musicBtn, fsBtn, settingsBtn),
    ),
    h('div', { class: 'main-menu__logo' }, createLogo()),
    h(
      'div',
      { class: 'main-menu__actions' },
      h('div', { class: 'pop', style: '--d:2' }, skinsBtn),
      h('div', { class: 'pop', style: '--d:1' }, playBtn),
      h('div', { class: 'pop', style: '--d:3' }, editorBtn),
    ),
    h(
      'footer',
      { class: 'main-menu__footer rise', style: '--d:5' },
      h('span', { class: 'footer-keys' }, kbd('Пробел'), ' играть  ', kbd('I'), ' иконки  ', kbd('E'), ' редактор  ', kbd('O'), ' настройки'),
      h('span', { class: 'version' }, icon(ICONS.cube), ` v${APP_VERSION} · ${APP_STAGE}`),
    ),
  );

  let offBeat: (() => void) | null = null;

  return {
    el,
    enter() {
      offBeat = audio.onBeat(() => replayClass(playBtn, 'beat'));
    },
    leave() {
      offBeat?.();
      offSettings();
    },
    onKey(e) {
      if (e.repeat) return false;
      switch (e.code) {
        case 'Space':
        case 'Enter':
          audio.sfx('play');
          ctx.router.go('levels');
          return true;
        case 'KeyI':
          audio.sfx('click');
          ctx.router.go('skins');
          return true;
        case 'KeyO':
          audio.sfx('click');
          ctx.router.go('settings');
          return true;
        case 'KeyE':
          audio.sfx('click');
          ctx.router.go('editorList');
          return true;
      }
      return false;
    },
  };
}
