import { h } from '../dom';
import { createLogo } from '../components/common';
import { audio } from '../../core/AudioManager';
import { skinImagesReady } from '../../render/skinImages';
import type { AppContext, Screen } from '../types';

const TIPS = [
  'Полируем шипы…',
  'Настраиваем гравитацию…',
  'Считаем кубы…',
  'Разогреваем порталы…',
  'Синхронизируем ритм…',
  'Подкручиваем неон…',
];

const MIN_LOADING_MS = 1400;
const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);

/**
 * Экран загрузки. Помимо красоты он нужен браузеру: звук можно включить
 * только после первого клика/нажатия клавиши.
 * На следующих этапах здесь будет реальная загрузка ассетов (треки, уровни).
 */
export function createSplash(ctx: AppContext): Screen {
  const fill = h('div', { class: 'loadbar__fill' });
  const percent = h('div', { class: 'loadbar__text' }, '0%');
  const tip = h('div', { class: 'splash__tip' }, TIPS[Math.floor(Math.random() * TIPS.length)]);
  const hint = h('div', { class: 'splash__hint' }, 'Нажмите, чтобы начать');
  const el = h(
    'div',
    { class: 'splash' },
    h('div', { class: 'splash__logo' }, createLogo()),
    h('div', { class: 'splash__loader' }, h('div', { class: 'loadbar' }, fill, percent), tip),
    hint,
  );

  let ready = false;
  let started = false;
  let raf = 0;

  const start = () => {
    if (!ready || started) return;
    started = true;
    audio.unlock();
    audio.startMenuMusic();
    audio.sfx('play');
    ctx.router.go('main', 'zoom');
  };
  el.addEventListener('pointerdown', start);

  return {
    el,
    enter() {
      const t0 = performance.now();
      let fontsReady = false;
      void Promise.all([document.fonts.ready, skinImagesReady]).then(() => {
        fontsReady = true;
      });
      const tick = (now: number) => {
        const k = easeOutCubic(Math.min(1, (now - t0) / MIN_LOADING_MS));
        const p = fontsReady ? k : Math.min(k, 0.9);
        fill.style.setProperty('--p', p.toFixed(3));
        percent.textContent = `${Math.round(p * 100)}%`;
        if (p >= 1) {
          ready = true;
          tip.textContent = 'Готово!';
          el.classList.add('is-ready');
          return;
        }
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    },
    leave() {
      cancelAnimationFrame(raf);
    },
    onKey(e) {
      if (!e.repeat) start();
      return true;
    },
  };
}
