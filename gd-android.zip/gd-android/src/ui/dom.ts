export type Child = Node | string | number | null | undefined | false;
export type Props = Record<string, unknown>;

/**
 * Крошечный hyperscript: h('div', { class: 'x' }, 'текст', otherNode).
 * Особые props: class, html (innerHTML), on<Event> (обработчик); остальное — атрибуты.
 */
export function h<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  props?: Props | null,
  ...children: Array<Child | Child[]>
): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  if (props) {
    for (const [key, value] of Object.entries(props)) {
      if (value === null || value === undefined || value === false) continue;
      if (key === 'class') el.className = String(value);
      else if (key === 'html') el.innerHTML = String(value);
      else if (key.startsWith('on') && typeof value === 'function') {
        el.addEventListener(key.slice(2).toLowerCase(), value as EventListener);
      } else el.setAttribute(key, value === true ? '' : String(value));
    }
  }
  append(el, children);
  return el;
}

export function append(el: Element, children: Array<Child | Child[]>): void {
  for (const c of children.flat()) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : String(c));
  }
}

/** Иконка из SVG-строки */
export function icon(svg: string, className = ''): HTMLSpanElement {
  return h('span', { class: `icon ${className}`.trim(), html: svg });
}

export function kbd(text: string): HTMLElement {
  return h('kbd', null, text);
}

/** Перезапуск CSS-анимации, навешанной классом */
export function replayClass(el: HTMLElement, className: string): void {
  el.classList.remove(className);
  void el.offsetWidth;
  el.classList.add(className);
}
