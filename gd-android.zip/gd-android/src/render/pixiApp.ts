import { Application } from 'pixi.js';

/** Одно WebGL-приложение на всю игру: в нём по очереди живут фон меню и уровень */
export async function createPixiApp(host: HTMLElement): Promise<Application> {
  const app = new Application();
  await app.init({
    resizeTo: window,
    antialias: true,
    autoDensity: true,
    resolution: Math.min(window.devicePixelRatio || 1, 2),
    background: 0x0b0d2a,
    powerPreference: 'high-performance',
  });
  host.appendChild(app.canvas);
  return app;
}
