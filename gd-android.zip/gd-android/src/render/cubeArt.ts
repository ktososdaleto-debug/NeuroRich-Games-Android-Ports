import type { SkinConfig } from '../data/skins';
import { getSkinImage } from './skinImages';

/**
 * Процедурная отрисовка иконок куба на Canvas 2D.
 * Один и тот же код рисует превью в меню и текстуру игрока в WebGL (через Texture.from(canvas)).
 * Все узоры задаются в координатах 0..100 — масштаб выставляется снаружи.
 */

type Ctx = CanvasRenderingContext2D;
type Pattern = (c: Ctx, primary: string, secondary: string) => void;

const INK = '#000';
/** Толщина чёрной обводки в координатах 0..100 */
const B = 5;

function box(c: Ctx, x: number, y: number, w: number, h: number, fill: string): void {
  c.fillStyle = INK;
  c.fillRect(x, y, w, h);
  c.fillStyle = fill;
  c.fillRect(x + B, y + B, w - 2 * B, h - 2 * B);
}

function poly(c: Ctx, pts: number[], fill: string): void {
  c.beginPath();
  c.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) c.lineTo(pts[i], pts[i + 1]);
  c.closePath();
  c.lineJoin = 'round';
  c.lineWidth = B * 2;
  c.strokeStyle = INK;
  c.stroke();
  c.fillStyle = fill;
  c.fill();
}

function circle(c: Ctx, cx: number, cy: number, r: number, fill: string): void {
  c.beginPath();
  c.arc(cx, cy, r, 0, Math.PI * 2);
  c.lineWidth = B * 2;
  c.strokeStyle = INK;
  c.stroke();
  c.fillStyle = fill;
  c.fill();
}

function clipInner(c: Ctx): void {
  c.beginPath();
  c.rect(B, B, 100 - 2 * B, 100 - 2 * B);
  c.clip();
}

const PIXEL_FACE = [
  '........',
  '.ss..ss.',
  '.s#..s#.',
  '........',
  's......s',
  '.ssssss.',
  '..s##s..',
  '........',
];

const PATTERNS: Record<string, Pattern> = {
  classic: (c, _p, s) => box(c, 24, 24, 52, 52, s),

  smile: (c, _p, s) => {
    box(c, 20, 20, 22, 26, s);
    box(c, 58, 20, 22, 26, s);
    poly(c, [20, 58, 80, 58, 70, 80, 30, 80], s);
  },

  angry: (c, _p, s) => {
    poly(c, [16, 26, 44, 38, 44, 50, 16, 50], s);
    poly(c, [84, 26, 56, 38, 56, 50, 84, 50], s);
    box(c, 28, 62, 44, 16, s);
  },

  cross: (c, _p, s) => {
    c.save();
    clipInner(c);
    c.lineCap = 'square';
    for (const [w, color] of [[26, INK], [16, s]] as const) {
      c.lineWidth = w;
      c.strokeStyle = color;
      c.beginPath();
      c.moveTo(18, 18);
      c.lineTo(82, 82);
      c.moveTo(82, 18);
      c.lineTo(18, 82);
      c.stroke();
    }
    c.restore();
  },

  grid: (c, p, s) => {
    box(c, 14, 14, 34, 34, s);
    box(c, 52, 14, 34, 34, p);
    box(c, 14, 52, 34, 34, p);
    box(c, 52, 52, 34, 34, s);
  },

  diamond: (c, p, s) => {
    poly(c, [50, 13, 87, 50, 50, 87, 13, 50], s);
    poly(c, [50, 35, 65, 50, 50, 65, 35, 50], p);
  },

  ring: (c, p, s) => {
    circle(c, 50, 50, 32, s);
    circle(c, 50, 50, 18, p);
    circle(c, 50, 50, 7, s);
  },

  robot: (c, _p, s) => {
    box(c, 12, 24, 76, 30, s);
    c.fillStyle = INK;
    c.fillRect(24, 32, 16, 14);
    c.fillRect(60, 32, 16, 14);
    box(c, 26, 62, 12, 18, s);
    box(c, 44, 62, 12, 18, s);
    box(c, 62, 62, 12, 18, s);
  },

  stripes: (c, _p, s) => {
    c.save();
    clipInner(c);
    c.lineCap = 'butt';
    for (const [w, color] of [[20, INK], [10, s]] as const) {
      c.lineWidth = w;
      c.strokeStyle = color;
      c.beginPath();
      for (let k = -100; k <= 100; k += 34) {
        c.moveTo(k, 100);
        c.lineTo(k + 100, 0);
      }
      c.stroke();
    }
    c.restore();
  },

  target: (c, p, s) => {
    circle(c, 50, 50, 36, s);
    circle(c, 50, 50, 24, p);
    circle(c, 50, 50, 11, s);
  },

  pixel: (c, _p, s) => {
    const cell = 10;
    PIXEL_FACE.forEach((row, y) => {
      [...row].forEach((ch, x) => {
        if (ch === '.') return;
        c.fillStyle = ch === '#' ? INK : s;
        c.fillRect(10 + x * cell, 10 + y * cell, cell, cell);
      });
    });
  },

  demon: (c, _p, s) => {
    poly(c, [9, 9, 32, 9, 14, 34], s);
    poly(c, [91, 9, 68, 9, 86, 34], s);
    poly(c, [20, 38, 44, 48, 22, 54], s);
    poly(c, [80, 38, 56, 48, 78, 54], s);
    poly(c, [22, 64, 78, 64, 72, 82, 62, 72, 50, 84, 38, 72, 28, 82], s);
  },
};

/** Рисует куб размером size×size с левым верхним углом в (x, y). */
export function drawCube(c: Ctx, x: number, y: number, size: number, skin: SkinConfig): void {
  c.save();
  c.translate(x, y);

  if (skin.glow) {
    // shadowBlur задаётся в пикселях устройства и не масштабируется transform'ом
    c.shadowColor = skin.secondary;
    c.shadowBlur = size * 0.28;
  }

  // Особый скин — готовая картинка со своей обводкой
  const image = getSkinImage(skin.icon);
  if (image) {
    c.imageSmoothingQuality = 'high';
    c.drawImage(image, 0, 0, size, size);
    c.restore();
    return;
  }

  c.fillStyle = INK;
  c.fillRect(0, 0, size, size);
  c.shadowBlur = 0;
  c.shadowColor = 'transparent';

  c.scale(size / 100, size / 100);
  c.fillStyle = skin.primary;
  c.fillRect(B, B, 100 - 2 * B, 100 - 2 * B);
  (PATTERNS[skin.icon] ?? PATTERNS.classic)(c, skin.primary, skin.secondary);

  // лёгкий блик сверху
  c.fillStyle = 'rgba(255,255,255,0.12)';
  c.fillRect(B, B, 100 - 2 * B, 18);
  c.restore();
}

export interface CubeCanvasOptions {
  /** Отступ вокруг куба (место под свечение) в CSS-пикселях */
  pad?: number;
  /** Плотность пикселей; по умолчанию — как у экрана (не больше 2) */
  dpr?: number;
}

export function createCubeCanvas(size: number, skin: SkinConfig, opts: CubeCanvasOptions = {}): HTMLCanvasElement {
  const pad = opts.pad ?? 0;
  const dpr = opts.dpr ?? Math.min(window.devicePixelRatio || 1, 2);
  const full = size + pad * 2;
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(full * dpr);
  canvas.height = Math.round(full * dpr);
  canvas.style.width = `${full}px`;
  canvas.style.height = `${full}px`;
  const c = canvas.getContext('2d')!;
  c.scale(dpr, dpr);
  drawCube(c, pad, pad, size, skin);
  return canvas;
}
