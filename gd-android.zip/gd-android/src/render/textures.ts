import { mulberry32 } from '../core/random';

function canvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return [c, c.getContext('2d')!];
}

/** Вертикальное затемнение сверху и снизу — придаёт глубину однотонному фону */
export function makeShadeCanvas(): HTMLCanvasElement {
  const [c, ctx] = canvas(2, 256);
  const grad = ctx.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0, 'rgba(0,0,0,0.35)');
  grad.addColorStop(0.45, 'rgba(0,0,0,0)');
  grad.addColorStop(0.8, 'rgba(0,0,0,0.1)');
  grad.addColorStop(1, 'rgba(0,0,0,0.4)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 2, 256);
  return c;
}

/** Радиальное свечение (растягивается в эллипс) */
export function makeGlowCanvas(): HTMLCanvasElement {
  const [c, ctx] = canvas(256, 256);
  const grad = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
  grad.addColorStop(0, 'rgba(255,255,255,0.9)');
  grad.addColorStop(0.25, 'rgba(255,255,255,0.35)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);
  return c;
}

/** Линия земли, гаснущая к краям экрана */
export function makeHLineCanvas(): HTMLCanvasElement {
  const [c, ctx] = canvas(512, 4);
  const grad = ctx.createLinearGradient(0, 0, 512, 0);
  grad.addColorStop(0, 'rgba(255,255,255,0)');
  grad.addColorStop(0.2, 'rgba(255,255,255,1)');
  grad.addColorStop(0.8, 'rgba(255,255,255,1)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 4);
  return c;
}

/** Бесшовный узор из крупных квадратов — фон уровня в духе оригинала */
export function makePatternCanvas(): HTMLCanvasElement {
  const size = 256;
  const [c, ctx] = canvas(size, size);
  const rnd = mulberry32(7);
  const squares: Array<[number, number, number]> = [];
  for (let i = 0; i < 9; i++) squares.push([rnd() * size, rnd() * size, 30 + rnd() * 70]);
  ctx.lineWidth = 3;
  for (const [x, y, s] of squares) {
    for (const dx of [-size, 0, size]) {
      for (const dy of [-size, 0, size]) {
        ctx.fillStyle = 'rgba(255,255,255,0.18)';
        ctx.fillRect(x + dx, y + dy, s, s);
        ctx.strokeStyle = 'rgba(255,255,255,0.55)';
        ctx.strokeRect(x + dx + 1.5, y + dy + 1.5, s - 3, s - 3);
      }
    }
  }
  return c;
}
