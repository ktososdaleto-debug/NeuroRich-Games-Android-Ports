import type { EffectDef, ParticleShape } from '../data/effects';

interface P {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  rot: number;
  spin: number;
}

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const css = (n: number) => `#${n.toString(16).padStart(6, '0')}`;

/** Рисует одну частицу эффекта (размер — в пикселях) */
export function drawParticle2D(c: CanvasRenderingContext2D, shape: ParticleShape, x: number, y: number, s: number, rot: number, vx: number, vy: number): void {
  c.save();
  c.translate(x, y);
  switch (shape) {
    case 'circle':
    case 'ember':
    case 'smoke':
      c.beginPath();
      c.arc(0, 0, s / 2, 0, Math.PI * 2);
      c.fill();
      break;
    case 'star': {
      c.rotate(rot);
      c.beginPath();
      for (let i = 0; i < 8; i++) {
        const r = i % 2 === 0 ? s / 2 : s / 7;
        const a = (i * Math.PI) / 4;
        c.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      }
      c.closePath();
      c.fill();
      break;
    }
    case 'spark': {
      const len = Math.hypot(vx, vy) || 1;
      c.lineWidth = Math.max(1, s / 6);
      c.strokeStyle = c.fillStyle;
      c.beginPath();
      c.moveTo(0, 0);
      c.lineTo((-vx / len) * s, (-vy / len) * s);
      c.stroke();
      break;
    }
    case 'flake':
      c.rotate(rot);
      c.lineWidth = Math.max(1, s / 7);
      c.strokeStyle = c.fillStyle;
      c.beginPath();
      for (let i = 0; i < 3; i++) {
        const a = (i * Math.PI) / 3;
        c.moveTo(Math.cos(a) * s / 2, Math.sin(a) * s / 2);
        c.lineTo(-Math.cos(a) * s / 2, -Math.sin(a) * s / 2);
      }
      c.stroke();
      break;
    case 'sprinkle':
      c.rotate(rot);
      c.fillRect(-s / 2, -s / 6, s, s / 3);
      break;
    default:
      c.rotate(rot);
      c.fillRect(-s / 2, -s / 2, s, s);
  }
  c.restore();
}

/** Альфа частицы по доле оставшейся жизни k (дым растёт и тает) */
export function particleAlpha(shape: ParticleShape, k: number): number {
  return shape === 'smoke' ? k * 0.55 : k;
}

export function particleScale(shape: ParticleShape, k: number): number {
  return shape === 'smoke' ? 1.6 - 0.6 * k : 0.4 + 0.6 * k;
}

/**
 * Превью эффекта скина: частицы вылетают из «основания» куба, как шлейф при беге.
 * unit — сколько пикселей в одной клетке (размер куба на превью).
 */
export class EffectPreview {
  readonly canvas = document.createElement('canvas');
  private readonly ctx = this.canvas.getContext('2d')!;
  private particles: P[] = [];
  private effect: EffectDef | null = null;
  private raf = 0;
  private last = 0;
  private acc = 0;

  constructor(
    private readonly width: number,
    private readonly height: number,
    private readonly originX: number,
    private readonly originY: number,
    private readonly unit: number,
  ) {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = width * dpr;
    this.canvas.height = height * dpr;
    this.canvas.style.width = `${width}px`;
    this.canvas.style.height = `${height}px`;
    this.ctx.scale(dpr, dpr);
  }

  setEffect(effect: EffectDef | null): void {
    this.effect = effect;
    this.particles = [];
    if (effect && !this.raf) {
      this.last = performance.now();
      this.raf = requestAnimationFrame(this.frame);
    }
    if (!effect) this.ctx.clearRect(0, 0, this.width, this.height);
  }

  destroy(): void {
    cancelAnimationFrame(this.raf);
    this.raf = 0;
  }

  private readonly frame = (now: number): void => {
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    const e = this.effect;
    const u = this.unit;
    if (!e) {
      this.raf = 0;
      return;
    }
    this.acc += dt * e.rate;
    while (this.acc >= 1) {
      this.acc -= 1;
      const life = rand(e.life[0], e.life[1]);
      const a = Math.random() * Math.PI * 2;
      this.particles.push({
        x: this.originX + rand(-0.4, 0.4) * u,
        y: this.originY - rand(0, 0.3) * u,
        vx: (Math.cos(a) * e.speed - 2.5) * u,
        vy: (Math.sin(a) * e.speed - e.rise) * u,
        life,
        max: life,
        size: rand(e.size[0], e.size[1]) * u,
        color: css(e.colors[Math.floor(Math.random() * e.colors.length)]),
        rot: Math.random() * Math.PI,
        spin: rand(-4, 4),
      });
    }
    const c = this.ctx;
    c.clearRect(0, 0, this.width, this.height);
    c.globalCompositeOperation = e.additive ? 'lighter' : 'source-over';
    for (const p of this.particles) {
      p.life -= dt;
      p.vy += e.gravity * u * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.spin * dt;
      const k = Math.max(0, p.life / p.max);
      c.globalAlpha = particleAlpha(e.shape, k);
      c.fillStyle = p.color;
      drawParticle2D(c, e.shape, p.x, p.y, p.size * particleScale(e.shape, k), p.rot, p.vx, p.vy);
    }
    c.globalAlpha = 1;
    c.globalCompositeOperation = 'source-over';
    this.particles = this.particles.filter((p) => p.life > 0);
    this.raf = requestAnimationFrame(this.frame);
  };
}
