import type { SkinConfig } from '../data/skins';
import type { GameMode } from '../game/types';
import { drawCube } from './cubeArt';

/*
 * Иконки режимов, собранные из текущего скина. Холст 192×192, 128 px = 1 клетка
 * (тот же масштаб, что у текстуры куба), центр холста = центр хитбокса игрока.
 */
export const VEHICLE_CANVAS = 192;
const C = VEHICLE_CANVAS / 2;
const INK = '#000';

function outlinePath(c: CanvasRenderingContext2D, fill: string, width = 10): void {
  c.lineJoin = 'round';
  c.lineWidth = width;
  c.strokeStyle = INK;
  c.stroke();
  c.fillStyle = fill;
  c.fill();
}

function drawShip(c: CanvasRenderingContext2D, skin: SkinConfig): void {
  // кабина с маленьким кубом
  drawCube(c, C - 34, C - 62, 56, skin);
  // корпус
  c.beginPath();
  c.moveTo(C - 86, C - 6);
  c.lineTo(C + 30, C - 6);
  c.lineTo(C + 88, C + 18);
  c.lineTo(C + 30, C + 46);
  c.lineTo(C - 70, C + 46);
  c.lineTo(C - 86, C + 22);
  c.closePath();
  outlinePath(c, skin.primary);
  c.beginPath();
  c.moveTo(C - 60, C + 10);
  c.lineTo(C + 34, C + 10);
  c.lineTo(C + 58, C + 20);
  c.lineTo(C + 30, C + 32);
  c.lineTo(C - 60, C + 32);
  c.closePath();
  outlinePath(c, skin.secondary, 6);
}

function drawBall(c: CanvasRenderingContext2D, skin: SkinConfig): void {
  const r = 62;
  c.save();
  c.beginPath();
  c.arc(C, C, r, 0, Math.PI * 2);
  c.clip();
  c.fillStyle = skin.primary;
  c.fillRect(C - r, C - r, r * 2, r * 2);
  drawCube(c, C - r, C - r, r * 2, { ...skin, glow: false });
  c.restore();
  c.beginPath();
  c.arc(C, C, r, 0, Math.PI * 2);
  c.lineWidth = 10;
  c.strokeStyle = INK;
  c.stroke();
  c.beginPath();
  c.arc(C, C, r - 14, 0, Math.PI * 2);
  c.lineWidth = 5;
  c.strokeStyle = skin.secondary;
  c.stroke();
}

function drawUfo(c: CanvasRenderingContext2D, skin: SkinConfig): void {
  // купол
  c.beginPath();
  c.arc(C, C - 4, 44, Math.PI, 0);
  c.closePath();
  outlinePath(c, 'rgba(170, 230, 255, 0.55)', 8);
  drawCube(c, C - 24, C - 42, 48, skin);
  // тарелка
  c.beginPath();
  c.ellipse(C, C + 14, 84, 26, 0, 0, Math.PI * 2);
  outlinePath(c, skin.primary);
  c.beginPath();
  c.ellipse(C, C + 22, 56, 12, 0, 0, Math.PI * 2);
  outlinePath(c, skin.secondary, 5);
  c.fillStyle = '#fff';
  for (const dx of [-58, 0, 58]) {
    c.beginPath();
    c.arc(C + dx, C + 12, 6, 0, Math.PI * 2);
    c.fill();
  }
}

function drawWave(c: CanvasRenderingContext2D, skin: SkinConfig): void {
  const tri = () => {
    c.beginPath();
    c.moveTo(C - 44, C - 40);
    c.lineTo(C + 52, C);
    c.lineTo(C - 44, C + 40);
    c.lineTo(C - 28, C);
    c.closePath();
  };
  tri();
  outlinePath(c, skin.primary);
  c.save();
  tri();
  c.clip();
  drawCube(c, C - 46, C - 46, 92, { ...skin, glow: false });
  c.restore();
  tri();
  c.lineWidth = 8;
  c.strokeStyle = INK;
  c.stroke();
}

export function createVehicleCanvas(mode: Exclude<GameMode, 'cube'>, skin: SkinConfig): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = VEHICLE_CANVAS;
  canvas.height = VEHICLE_CANVAS;
  const c = canvas.getContext('2d')!;
  if (skin.glow) {
    c.shadowColor = skin.secondary;
    c.shadowBlur = 24;
  }
  switch (mode) {
    case 'ship':
      drawShip(c, skin);
      break;
    case 'ball':
      drawBall(c, skin);
      break;
    case 'ufo':
      drawUfo(c, skin);
      break;
    case 'wave':
      drawWave(c, skin);
      break;
  }
  return canvas;
}
