import { ICONS } from '../data/skins';

const images = new Map<string, HTMLImageElement>();

function load(id: string, src: string): Promise<void> {
  return new Promise((resolve) => {
    const img = new Image();
    img.decoding = 'async';
    img.onload = () => {
      images.set(id, img);
      resolve();
    };
    // не загрузилась — скин нарисуется классическим узором
    img.onerror = () => resolve();
    img.src = import.meta.env.BASE_URL + src;
  });
}

/** Загрузка картинок особых скинов. Экран загрузки ждёт этот промис. */
export const skinImagesReady: Promise<void> = Promise.all(
  ICONS.filter((i) => i.image).map((i) => load(i.id, i.image!)),
).then(() => undefined);

export function getSkinImage(iconId: string): HTMLImageElement | null {
  return images.get(iconId) ?? null;
}
