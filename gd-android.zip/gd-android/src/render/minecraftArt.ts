import { mulberry32 } from '../core/random';
import type { BlockTexture } from '../game/types';

/*
 * Пиксельные текстуры 16×16 в духе Minecraft, нарисованные кодом (без чужих ассетов).
 * Масштабируются без сглаживания, поэтому остаются чёткими «пикселями».
 */

const N = 16;
type Ctx = CanvasRenderingContext2D;

function tile(draw: (c: Ctx, rnd: () => number) => void, seed: number, w = N, h = N): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const c = canvas.getContext('2d')!;
  draw(c, mulberry32(seed));
  return canvas;
}

function px(c: Ctx, x: number, y: number, color: string): void {
  c.fillStyle = color;
  c.fillRect(x, y, 1, 1);
}

/** Заливка «шумом» из палитры */
function noise(c: Ctx, rnd: () => number, palette: string[], y0 = 0, y1 = N): void {
  for (let y = y0; y < y1; y++) {
    for (let x = 0; x < N; x++) px(c, x, y, palette[Math.floor(rnd() * palette.length)]);
  }
}

/** Пятна руды/вкраплений */
function specks(c: Ctx, rnd: () => number, colors: string[], count: number): void {
  for (let i = 0; i < count; i++) {
    const x = 1 + Math.floor(rnd() * 13);
    const y = 1 + Math.floor(rnd() * 13);
    px(c, x, y, colors[0]);
    px(c, x + 1, y, colors[1] ?? colors[0]);
    if (rnd() > 0.4) px(c, x, y + 1, colors[1] ?? colors[0]);
  }
}

const DIRT = ['#866043', '#79553a', '#966c4a', '#6c4a30'];
const STONE = ['#7f7f7f', '#747474', '#8a8a8a', '#6b6b6b'];
const GRASS = ['#5f9f35', '#6dab3c', '#548c2f', '#79b845'];

export const makeDirt = () => tile((c, r) => noise(c, r, DIRT), 11);

export const makeGrassTop = () =>
  tile((c, r) => {
    noise(c, r, DIRT);
    noise(c, r, GRASS, 0, 3);
    // свисающие травинки
    for (let x = 0; x < N; x++) {
      const len = Math.floor(r() * 3);
      for (let y = 3; y < 3 + len; y++) px(c, x, y, GRASS[Math.floor(r() * GRASS.length)]);
    }
  }, 12);

export const makeStone = () => tile((c, r) => noise(c, r, STONE), 13);

export function makeOre(colors: string[], seed: number): HTMLCanvasElement {
  return tile((c, r) => {
    noise(c, r, STONE);
    specks(c, r, colors, 4);
  }, seed);
}

export const makeCobble = () =>
  tile((c, r) => {
    noise(c, r, ['#7a7a7a', '#8c8c8c', '#6e6e6e']);
    c.fillStyle = '#4e4e4e';
    // «швы» между камнями
    for (const [x, y, w, h] of [
      [0, 4, 7, 1], [7, 0, 1, 5], [9, 6, 7, 1], [3, 5, 1, 6], [0, 11, 9, 1], [12, 7, 1, 6], [6, 12, 1, 4], [9, 13, 7, 1],
    ]) c.fillRect(x, y, w, h);
  }, 14);

export const makePlanks = () =>
  tile((c, r) => {
    noise(c, r, ['#a2824e', '#9c7c4a', '#ad8b54']);
    c.fillStyle = '#6b5130';
    for (const y of [3, 7, 11, 15]) c.fillRect(0, y, N, 1);
    for (const [x, y] of [[4, 0], [11, 4], [6, 8], [13, 12]]) c.fillRect(x, y, 1, 3);
  }, 15);

export const makeLog = () =>
  tile((c, r) => {
    for (let x = 0; x < N; x++) {
      const col = x % 4 === 0 ? '#3e2d17' : x % 4 === 2 ? '#5b4426' : '#6b5130';
      for (let y = 0; y < N; y++) px(c, x, y, r() > 0.85 ? '#4a361c' : col);
    }
  }, 16);

export const makeLeaves = () =>
  tile((c, r) => {
    noise(c, r, ['#3f7d23', '#4a8f2a', '#36701e', '#2b5c17']);
    for (let i = 0; i < 18; i++) px(c, Math.floor(r() * N), Math.floor(r() * N), '#1d3f10');
  }, 17);

export const makeNetherrack = () =>
  tile((c, r) => {
    noise(c, r, ['#6f2d2d', '#7d3434', '#5e2424', '#8a3b3b']);
    specks(c, r, ['#4a1818', '#a14545'], 5);
  }, 18);

export const makeObsidian = () =>
  tile((c, r) => {
    noise(c, r, ['#14101e', '#1b1428', '#100c18']);
    specks(c, r, ['#3b2a5c', '#5a3f8a'], 4);
  }, 19);

export const makeEndstone = () =>
  tile((c, r) => {
    noise(c, r, ['#dedca0', '#d2cf8f', '#e6e4ad', '#c8c483']);
    specks(c, r, ['#b3ae6c', '#c2bd7a'], 5);
  }, 20);

export const makeLava = () =>
  tile((c, r) => {
    noise(c, r, ['#ff8a00', '#ff6a00', '#ffa31a', '#e65100']);
    specks(c, r, ['#ffd23f', '#ffe066'], 5);
  }, 21);

/** Пиксельный шип: камень с тёмной обводкой, остриём вверх */
export const makeSpike = () =>
  tile((c) => {
    for (let y = 1; y < N; y++) {
      const half = Math.ceil((y * 7) / 15);
      for (let x = 8 - half; x < 8 + half; x++) {
        const edge = x === 8 - half || x === 7 + half || y === N - 1;
        const light = x < 8;
        px(c, x, y, edge ? '#2a2a2a' : light ? '#b8b8b8' : '#8c8c8c');
      }
    }
    px(c, 7, 0, '#2a2a2a');
    px(c, 8, 0, '#2a2a2a');
  }, 22);

/** Пиксельные облака для неба поверхности (тайл 64×32) */
export const makeClouds = () =>
  tile(
    (c) => {
      c.fillStyle = 'rgba(255,255,255,0.92)';
      c.fillRect(4, 8, 24, 6);
      c.fillRect(10, 4, 12, 4);
      c.fillRect(38, 20, 18, 5);
      c.fillRect(42, 17, 8, 3);
      c.fillStyle = 'rgba(220,230,240,0.9)';
      c.fillRect(4, 13, 24, 2);
      c.fillRect(38, 24, 18, 1);
    },
    23,
    64,
    32,
  );

/** Набор текстур блоков. stone дополнительно имеет варианты с рудой. */
export interface BlockTextureSet {
  canvases: Record<BlockTexture | 'grassTop' | 'lava' | 'spike' | 'clouds' | 'oreCoal' | 'oreIron' | 'oreDiamond', HTMLCanvasElement>;
}

export function makeBlockTextures(): BlockTextureSet {
  return {
    canvases: {
      grass: makeDirt(),
      grassTop: makeGrassTop(),
      dirt: makeDirt(),
      stone: makeStone(),
      oreCoal: makeOre(['#1e1e1e', '#333333'], 31),
      oreIron: makeOre(['#d8af93', '#c49a7c'], 32),
      oreDiamond: makeOre(['#4ee6dc', '#2bb8b0'], 33),
      cobble: makeCobble(),
      planks: makePlanks(),
      log: makeLog(),
      leaves: makeLeaves(),
      netherrack: makeNetherrack(),
      obsidian: makeObsidian(),
      endstone: makeEndstone(),
      lava: makeLava(),
      spike: makeSpike(),
      clouds: makeClouds(),
    },
  };
}
