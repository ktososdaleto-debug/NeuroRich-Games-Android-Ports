import { Container, Graphics, Sprite, Texture, type Application } from 'pixi.js';
import { effectOf, type SkinConfig } from '../data/skins';
import type { ParticleQuality } from '../state/settings';
import { hexToRgb, hslToRgb, lerpRgb, rgbToNum, scaleRgb, type RGB } from '../core/color';
import { mulberry32 } from '../core/random';
import { createCubeCanvas } from './cubeArt';
import { makeGlowCanvas, makeShadeCanvas } from './textures';

/*
 * Живой фон меню в духе Geometry Dash: переливающийся цвет, параллакс-слои,
 * бегущая земля и демо-куб, который сам прыгает через шипы.
 * Всё в «юнитах»: 1 юнит = размер куба = размер клетки уровня.
 */

const PLAYER_SCREEN_X = 0.26;
/** юнитов в секунду */
const SPEED = 8.4;
const JUMP_TIME = 0.46;
const JUMP_HEIGHT = 2.15;
const GRAVITY = (8 * JUMP_HEIGHT) / (JUMP_TIME * JUMP_TIME);
const JUMP_VELOCITY = (4 * JUMP_HEIGHT) / JUMP_TIME;
/** Прыгаем так, чтобы вершина дуги пришлась на центр препятствия */
const JUMP_LEAD = (SPEED * JUMP_TIME) / 2;

const SKIN_TEXTURE_SIZE = 128;
const SKIN_TEXTURE_PAD = 32;

const MOTE_COUNT: Record<ParticleQuality, number> = { off: 0, low: 14, high: 36 };
const TRAIL_RATE: Record<ParticleQuality, number> = { off: 0, low: 14, high: 36 };

interface Obstacle {
  x: number;
  width: number;
  kind: 'spike' | 'block';
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  rot: number;
  spin: number;
  alpha: number;
}

export class MenuBackground {
  private readonly root = new Container();
  private active = true;
  private readonly sky = new Graphics();
  private readonly shade = new Sprite();
  private readonly farLayer = new Graphics();
  private readonly midLayer = new Graphics();
  private readonly motesGfx = new Graphics();
  private readonly groundFill = new Graphics();
  private readonly groundDetail = new Graphics();
  private readonly groundGlow = new Sprite();
  private readonly obstacleGfx = new Graphics();
  private readonly trailGfx = new Graphics();
  private readonly player = new Sprite();

  private width = 0;
  private height = 0;
  private unit = 40;
  private groundY = 0;
  private layerWidth = 0;

  /** Пройденное расстояние в юнитах */
  private scroll = 0;
  private obstacles: Obstacle[] = [];
  private playerY = 0;
  private playerVY = 0;
  private grounded = true;
  private playerRot = 0;

  private trail: Particle[] = [];
  private motes: Particle[] = [];
  private trailAccumulator = 0;
  private trailColor = 0xffffff;

  private hue = 215;
  private color: RGB = hslToRgb(215, 0.78, 0.42);
  private accent: RGB | null = null;
  private beat = 0;
  private motion = 1;
  private quality: ParticleQuality = 'high';
  private readonly rng = mulberry32(0x9e3779b9);
  private playerTexture: Texture | null = null;
  private skinKey = '';

  constructor(private readonly app: Application) {
    this.shade.texture = Texture.from(makeShadeCanvas());
    this.groundGlow.texture = Texture.from(makeGlowCanvas());
    this.groundGlow.anchor.set(0.5);
    this.groundGlow.blendMode = 'add';
    this.player.anchor.set(0.5);
    this.farLayer.alpha = 0.16;

    this.app.stage.addChild(this.root);
    this.root.addChild(
      this.sky,
      this.farLayer,
      this.midLayer,
      this.shade,
      this.motesGfx,
      this.groundFill,
      this.groundDetail,
      this.groundGlow,
      this.obstacleGfx,
      this.trailGfx,
      this.player,
    );

    this.layout();
    this.app.ticker.add((ticker) => this.update(Math.min(ticker.deltaMS / 1000, 1 / 20)));
  }

  // ---- Публичное API ---------------------------------------------------------

  /** Во время уровня фон меню скрыт и не обновляется */
  setActive(active: boolean): void {
    this.active = active;
    this.root.visible = active;
  }

  setSkin(skin: SkinConfig, force = false): void {
    const key = JSON.stringify(skin);
    if (key === this.skinKey && !force) return;
    this.skinKey = key;
    const prev = this.playerTexture;
    this.playerTexture = Texture.from(createCubeCanvas(SKIN_TEXTURE_SIZE, skin, { pad: SKIN_TEXTURE_PAD, dpr: 1 }));
    this.player.texture = this.playerTexture;
    prev?.destroy(true);
    this.trailColor = effectOf(skin)?.colors[0] ?? rgbToNum(hexToRgb(skin.primary));
  }

  /** Перекрасить фон в цвет уровня (null — вернуть радужный перелив) */
  setAccent(hex: string | null): void {
    this.accent = hex ? scaleRgb(hexToRgb(hex), 0.75) : null;
  }

  /** Вспышка в такт музыке */
  pulse(): void {
    this.beat = 1;
  }

  setMotion(enabled: boolean): void {
    this.motion = enabled ? 1 : 0;
  }

  setParticleQuality(q: ParticleQuality): void {
    this.quality = q;
    if (q === 'off') this.trail = [];
  }

  // ---- Кадр -----------------------------------------------------------------

  private update(dt: number): void {
    if (!this.active) return;
    this.layout();
    const step = dt * this.motion;
    this.scroll += SPEED * step;
    this.beat *= Math.exp(-dt * 5);

    const u = this.unit;
    this.farLayer.x = -((this.scroll * u * 0.1) % this.layerWidth);
    this.midLayer.x = -((this.scroll * u * 0.35) % this.layerWidth);

    this.updateColors(dt);
    this.updateObstacles();
    this.updatePlayer(step);
    this.updateParticles(step);
    this.drawGround();
    this.drawObstacles();
  }

  private layout(): void {
    const { width, height } = this.app.screen;
    if (width === this.width && height === this.height) return;
    this.width = width;
    this.height = height;
    this.unit = Math.max(26, Math.min(72, height * 0.075));
    this.groundY = Math.round(height * 0.8);
    this.layerWidth = Math.ceil(width / this.unit + 6) * this.unit;

    this.sky.clear().rect(0, 0, width, height).fill(0xffffff);
    this.shade.width = width;
    this.shade.height = height;
    this.groundFill.clear().rect(0, this.groundY, width, height - this.groundY).fill(0xffffff);
    this.groundGlow.position.set(width / 2, this.groundY);
    this.groundGlow.width = width * 0.9;
    this.groundGlow.height = this.unit * 2.2;
    this.player.scale.set(this.unit / SKIN_TEXTURE_SIZE);

    this.buildFarLayer();
    this.buildMidLayer();
    this.motes = [];
  }

  private updateColors(dt: number): void {
    this.hue = (this.hue + dt * 7 * this.motion) % 360;
    const target = this.accent ?? hslToRgb(this.hue, 0.78, 0.42);
    this.color = lerpRgb(this.color, target, 1 - Math.exp(-dt * 2.2));
    const c = this.color;
    this.sky.tint = rgbToNum(scaleRgb(c, 1 + this.beat * 0.12));
    this.farLayer.tint = rgbToNum(scaleRgb(c, 1.8));
    this.midLayer.tint = rgbToNum(scaleRgb(c, 0.55));
    this.groundFill.tint = rgbToNum(scaleRgb(c, 0.4));
    this.groundGlow.alpha = 0.35 + this.beat * 0.45;
  }

  // ---- Параллакс ------------------------------------------------------------
  // Каждый слой — полоса шириной layerWidth, нарисованная трижды (−1, 0, +1),
  // поэтому сдвиг по модулю ширины даёт бесшовную прокрутку.

  private buildFarLayer(): void {
    const g = this.farLayer.clear();
    const u = this.unit;
    const W = this.layerWidth;
    const rnd = mulberry32(17);
    const squares: Array<[number, number, number]> = [];
    for (let x = 0; x < W; x += u * (2 + rnd() * 2.5)) {
      const size = u * (1.4 + rnd() * 2.6);
      squares.push([x, rnd() * (this.groundY - size * 0.5) - size * 0.3, size]);
    }
    for (const k of [-1, 0, 1]) {
      for (const [x, y, s] of squares) {
        g.rect(x + k * W, y, s, s).fill({ color: 0xffffff, alpha: 0.5 }).stroke({ width: 3, color: 0xffffff });
      }
    }
  }

  private buildMidLayer(): void {
    const g = this.midLayer.clear();
    const u = this.unit;
    const W = this.layerWidth;
    const gy = this.groundY;
    const rnd = mulberry32(91);
    const towers: Array<[number, number, number]> = [];
    let x = 0;
    while (x < W - u) {
      const w = Math.round(1 + rnd() * 2);
      const h = Math.round(1 + rnd() * 4);
      if (x + w * u > W) break;
      towers.push([x, w, h]);
      x += (w + 1 + Math.floor(rnd() * 3)) * u;
    }
    for (const k of [-1, 0, 1]) {
      for (const [tx, tw, th] of towers) {
        const left = tx + k * W;
        g.rect(left, gy - th * u, tw * u, th * u).fill(0xffffff);
        for (let i = 0; i < tw; i++) {
          for (let j = 1; j <= th; j++) {
            g.rect(left + i * u + 4, gy - j * u + 4, u - 8, u - 8).stroke({ width: 2, color: 0x000000, alpha: 0.18 });
          }
        }
      }
    }
  }

  // ---- Демо-уровень ---------------------------------------------------------

  private updateObstacles(): void {
    const view = this.width / this.unit;
    this.obstacles = this.obstacles.filter((o) => o.x + o.width > this.scroll - 2);
    let last: Obstacle | undefined = this.obstacles[this.obstacles.length - 1];
    let cursor = last ? last.x + last.width : this.scroll + view * PLAYER_SCREEN_X + 10;
    while (cursor < this.scroll + view + 4) {
      const r = this.rng();
      const ob: Obstacle =
        r < 0.55
          ? { kind: 'spike', width: 1, x: 0 }
          : r < 0.82
            ? { kind: 'spike', width: 2, x: 0 }
            : { kind: 'block', width: 1, x: 0 };
      ob.x = cursor + (last ? 5 + this.rng() * 7 : 0);
      this.obstacles.push(ob);
      last = ob;
      cursor = ob.x + ob.width;
    }
  }

  private updatePlayer(step: number): void {
    const u = this.unit;
    const playerX = this.scroll + (this.width * PLAYER_SCREEN_X) / u;

    if (this.grounded && step > 0) {
      const next = this.obstacles.find((o) => o.x + o.width / 2 > playerX);
      if (next && next.x + next.width / 2 - playerX <= JUMP_LEAD) this.jump();
    }

    if (!this.grounded) {
      this.playerVY -= GRAVITY * step;
      this.playerY += this.playerVY * step;
      // пол-оборота за прыжок — приземляемся ровно на грань
      this.playerRot += (Math.PI / JUMP_TIME) * step;
      if (this.playerY <= 0) {
        this.playerY = 0;
        this.playerVY = 0;
        this.grounded = true;
        this.burst(5, 0.6);
      }
    } else {
      const quarter = Math.PI / 2;
      const target = Math.round(this.playerRot / quarter) * quarter;
      this.playerRot += (target - this.playerRot) * Math.min(1, step * 18);
    }

    this.player.position.set(this.width * PLAYER_SCREEN_X, this.groundY - (this.playerY + 0.5) * u);
    this.player.rotation = this.playerRot;
  }

  private jump(): void {
    this.grounded = false;
    this.playerVY = JUMP_VELOCITY;
    this.burst(8, 1);
  }

  // ---- Частицы --------------------------------------------------------------

  private updateParticles(step: number): void {
    const u = this.unit;

    const rate = TRAIL_RATE[this.quality];
    if (this.grounded && rate > 0 && step > 0) {
      this.trailAccumulator += rate * step;
      while (this.trailAccumulator >= 1) {
        this.trailAccumulator -= 1;
        this.trail.push(this.makeTrailParticle(1));
      }
    }
    for (const p of this.trail) {
      p.life -= step;
      p.x += p.vx * step;
      p.y += p.vy * step;
      p.vy += u * 6 * step;
    }
    this.trail = this.trail.filter((p) => p.life > 0);

    const target = MOTE_COUNT[this.quality];
    while (this.motes.length < target) this.motes.push(this.makeMote());
    if (this.motes.length > target) this.motes.length = target;
    for (const m of this.motes) {
      m.life -= step;
      m.x += m.vx * step;
      m.y += m.vy * step;
      m.rot += m.spin * step;
      if (m.life <= 0) Object.assign(m, this.makeMote());
    }

    const mg = this.motesGfx.clear();
    for (const m of this.motes) {
      const a = m.alpha * Math.sin(Math.PI * (m.life / m.maxLife));
      if (a <= 0.003) continue;
      mg.poly(rotatedSquare(m.x, m.y, m.size, m.rot)).fill({ color: 0xffffff, alpha: a });
    }

    const tg = this.trailGfx.clear();
    for (const p of this.trail) {
      const k = p.life / p.maxLife;
      const s = p.size * (0.4 + 0.6 * k);
      tg.rect(p.x - s / 2, p.y - s / 2, s, s).fill({ color: this.trailColor, alpha: k * 0.9 });
    }
  }

  private burst(count: number, power: number): void {
    if (this.quality === 'off') return;
    const n = this.quality === 'low' ? Math.ceil(count / 2) : count;
    for (let i = 0; i < n; i++) {
      const p = this.makeTrailParticle(power * 1.4);
      p.vy *= 1.6;
      this.trail.push(p);
    }
  }

  private makeTrailParticle(power: number): Particle {
    const u = this.unit;
    const r = this.rng;
    const life = 0.35 + r() * 0.35;
    return {
      x: this.width * PLAYER_SCREEN_X - u * 0.45 + r() * u * 0.2,
      y: this.groundY - 2 - r() * u * 0.15,
      vx: -SPEED * u * 0.35 * (0.6 + r() * 0.8) * power,
      vy: -u * (1 + r() * 2.5) * power,
      life,
      maxLife: life,
      size: u * (0.1 + r() * 0.12),
      rot: 0,
      spin: 0,
      alpha: 1,
    };
  }

  private makeMote(): Particle {
    const u = this.unit;
    const r = this.rng;
    const life = 4 + r() * 6;
    return {
      x: r() * this.width,
      y: r() * this.groundY,
      vx: -u * (0.2 + r() * 0.8),
      vy: -u * (0.1 + r() * 0.5),
      life,
      maxLife: life,
      size: u * (0.15 + r() * 0.35),
      rot: r() * Math.PI,
      spin: (r() - 0.5) * 1.5,
      alpha: 0.05 + r() * 0.15,
    };
  }

  // ---- Отрисовка ------------------------------------------------------------

  private drawGround(): void {
    const g = this.groundDetail.clear();
    const u = this.unit;
    const gy = this.groundY;
    const { width: w, height: h } = this;
    const tile = u * 2;
    const offset = (this.scroll * u) % tile;

    for (let x = -offset; x < w; x += tile) g.moveTo(x, gy).lineTo(x, h);
    g.moveTo(0, gy + tile).lineTo(w, gy + tile);
    g.stroke({ width: 2, color: 0x000000, alpha: 0.22 });

    g.rect(0, gy, w, u * 0.35).fill({ color: 0x000000, alpha: 0.15 });
    g.rect(0, gy - 1.5, w, 3).fill({ color: 0xffffff, alpha: 0.9 });
  }

  private drawObstacles(): void {
    const g = this.obstacleGfx.clear();
    const u = this.unit;
    const gy = this.groundY;
    for (const o of this.obstacles) {
      const sx = (o.x - this.scroll) * u;
      if (sx > this.width + u || sx + o.width * u < -u) continue;
      if (o.kind === 'spike') {
        for (let i = 0; i < o.width; i++) {
          const x = sx + i * u;
          g.poly([x + u * 0.06, gy, x + u / 2, gy - u * 0.92, x + u * 0.94, gy])
            .fill({ color: 0x000000, alpha: 0.92 })
            .stroke({ width: 2.5, color: 0xffffff, alpha: 0.95, join: 'round' });
        }
      } else {
        g.rect(sx, gy - u, u, u)
          .fill({ color: 0x000000, alpha: 0.9 })
          .stroke({ width: 2.5, color: 0xffffff, alpha: 0.95 });
        g.rect(sx + u * 0.22, gy - u * 0.78, u * 0.56, u * 0.56).stroke({ width: 1.5, color: 0xffffff, alpha: 0.35 });
      }
    }
  }
}

function rotatedSquare(cx: number, cy: number, size: number, rot: number): number[] {
  const h = size / 2;
  const cos = Math.cos(rot);
  const sin = Math.sin(rot);
  const pts: number[] = [];
  for (const [dx, dy] of [[-h, -h], [h, -h], [h, h], [-h, h]]) {
    pts.push(cx + dx * cos - dy * sin, cy + dx * sin + dy * cos);
  }
  return pts;
}
