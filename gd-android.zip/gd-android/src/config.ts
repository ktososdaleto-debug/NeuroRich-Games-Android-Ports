export const APP_VERSION = '1.0.0';
export const APP_STAGE = 'Редактор уровней';
