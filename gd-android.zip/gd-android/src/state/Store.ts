import { loadJSON, saveJSON } from '../core/Storage';

export type Listener<T> = (value: Readonly<T>, prev: Readonly<T>) => void;

/**
 * Минимальное реактивное хранилище с автосохранением в localStorage.
 * Значение иммутабельно: set() всегда создаёт новый объект, поэтому
 * подписчики могут сравнивать prev и value по ссылкам.
 */
export class Store<T extends object> {
  private value: T;
  private readonly listeners = new Set<Listener<T>>();

  constructor(
    private readonly key: string,
    private readonly defaults: T,
  ) {
    this.value = { ...defaults, ...(loadJSON<Partial<T>>(key) ?? {}) };
  }

  get(): Readonly<T> {
    return this.value;
  }

  set(patch: Partial<T>): void {
    const prev = this.value;
    this.value = { ...prev, ...patch };
    saveJSON(this.key, this.value);
    for (const fn of this.listeners) fn(this.value, prev);
  }

  reset(): void {
    this.set({ ...this.defaults });
  }

  /** Возвращает функцию отписки. immediate — сразу вызвать с текущим значением. */
  subscribe(fn: Listener<T>, immediate = false): () => void {
    this.listeners.add(fn);
    if (immediate) fn(this.value, this.value);
    return () => {
      this.listeners.delete(fn);
    };
  }
}
