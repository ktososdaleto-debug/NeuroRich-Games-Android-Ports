import { Store } from './Store';
import type { LevelData, LevelObject, LevelTheme, ObjectType } from '../game/types';
import type { LevelMeta } from '../data/levels';

/** Уровень, созданный в редакторе */
export interface CustomLevel {
  id: string;
  name: string;
  songId: string;
  theme: LevelTheme;
  colors: LevelData['colors'];
  objects: LevelObject[];
  /** null — длина считается автоматически по последнему объекту */
  length: number | null;
  createdAt: number;
  updatedAt: number;
}

export interface SongChoice {
  id: string;
  title: string;
  bpm: number;
}

/** Треки, под которые можно делать уровни */
export const SONG_CHOICES: SongChoice[] = [
  { id: 'first-jump', title: 'Неоновый старт', bpm: 156 },
  { id: 'block-world', title: 'Пиксельный рассвет', bpm: 156 },
  { id: 'menu', title: 'Мелодия меню', bpm: 124 },
];

export const songChoice = (id: string): SongChoice => SONG_CHOICES.find((s) => s.id === id) ?? SONG_CHOICES[0];

const store = new Store<{ levels: CustomLevel[] }>('custom-levels', { levels: [] });

export function listCustomLevels(): CustomLevel[] {
  return [...store.get().levels].sort((a, b) => b.updatedAt - a.updatedAt);
}

export function getCustomLevel(id: string): CustomLevel | null {
  return store.get().levels.find((l) => l.id === id) ?? null;
}

export function saveCustomLevel(level: CustomLevel): void {
  const levels = store.get().levels.filter((l) => l.id !== level.id);
  store.set({ levels: [...levels, { ...level, updatedAt: Date.now() }] });
}

export function deleteCustomLevel(id: string): void {
  store.set({ levels: store.get().levels.filter((l) => l.id !== id) });
}

const newId = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;

export function createCustomLevel(name: string, from?: Partial<CustomLevel>): CustomLevel {
  const now = Date.now();
  const level: CustomLevel = {
    songId: 'first-jump',
    theme: 'classic',
    colors: { bg: '#2a5fe0', ground: '#1d3fae', line: '#ffffff', obj: '#ffffff' },
    objects: [],
    length: null,
    ...from,
    name,
    id: newId(),
    createdAt: now,
    updatedAt: now,
  };
  saveCustomLevel(level);
  return level;
}

/** Копия официального уровня — удобно, чтобы посмотреть, как он устроен */
export function customFromLevelData(name: string, data: LevelData): CustomLevel {
  return createCustomLevel(name, {
    songId: data.songId,
    theme: data.theme ?? 'classic',
    colors: { ...data.colors },
    objects: data.objects.map((o) => ({ ...o })),
    length: data.length,
  });
}

/** Длина уровня: по последнему объекту плюс разбег до финиша */
export function levelLength(level: CustomLevel): number {
  if (level.length) return level.length;
  let end = 30;
  for (const o of level.objects) {
    if (!o.type.startsWith('trigger')) end = Math.max(end, o.x + (o.w ?? 1));
  }
  return Math.ceil(end + 12);
}

export function toLevelData(level: CustomLevel): LevelData {
  return {
    version: 1,
    id: `custom:${level.id}`,
    songId: level.songId,
    theme: level.theme,
    length: levelLength(level),
    colors: level.colors,
    objects: [...level.objects].sort((a, b) => a.x - b.x),
  };
}

export function customMeta(level: CustomLevel): LevelMeta {
  const song = songChoice(level.songId);
  return {
    id: `custom:${level.id}`,
    name: level.name,
    difficulty: 'normal',
    stars: 0,
    color: level.colors.bg,
    songId: level.songId,
    song: { title: song.title, author: 'Claude Synth' },
  };
}

// ---- Обмен уровнями через файл ----------------------------------------------

const FORMAT = 'gd-claude-level';

const OBJECT_TYPES = new Set<ObjectType>([
  'block', 'spike', 'small-spike', 'lava', 'pad-yellow', 'orb-yellow',
  'portal-cube', 'portal-ship', 'portal-ball', 'portal-ufo', 'portal-wave',
  'portal-gravity-up', 'portal-gravity-down', 'trigger-color', 'trigger-flash', 'trigger-zone',
]);

export function exportCustomLevel(level: CustomLevel): string {
  const { id: _id, createdAt: _c, updatedAt: _u, ...rest } = level;
  return JSON.stringify({ format: FORMAT, version: 1, level: rest });
}

/** Разбирает файл уровня; бросает ошибку с понятным текстом, если файл чужой или битый */
export function importCustomLevel(text: string): CustomLevel {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('Это не файл уровня');
  }
  const p = parsed as { format?: string; level?: Partial<CustomLevel> };
  if (p.format !== FORMAT || !p.level || !Array.isArray(p.level.objects)) throw new Error('Это не файл уровня');
  const num = (v: unknown) => typeof v === 'number' && Number.isFinite(v);
  const objects = p.level.objects.filter(
    (o): o is LevelObject => !!o && OBJECT_TYPES.has(o.type) && num(o.x) && num(o.y),
  );
  const colors = p.level.colors ?? { bg: '#2a5fe0', ground: '#1d3fae', line: '#ffffff' };
  return createCustomLevel(String(p.level.name ?? 'Уровень друга').slice(0, 40), {
    songId: songChoice(String(p.level.songId)).id,
    theme: p.level.theme === 'minecraft' ? 'minecraft' : 'classic',
    colors,
    objects,
    length: num(p.level.length) ? (p.level.length as number) : null,
  });
}
