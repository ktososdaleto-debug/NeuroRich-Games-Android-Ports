import { Store } from './Store';
import { DEFAULT_SKIN, ICONS, type IconDef, type SkinConfig, type UnlockRule } from '../data/skins';
import { LEVELS } from '../data/levels';

export interface LevelProgress {
  /** Лучший процент в обычном режиме, 0..100 */
  normal: number;
  /** Лучший процент в режиме практики, 0..100 */
  practice: number;
  attempts: number;
  jumps: number;
  completed: boolean;
}

export interface PlayerStats {
  attempts: number;
  jumps: number;
}

export const EMPTY_PROGRESS: LevelProgress = { normal: 0, practice: 0, attempts: 0, jumps: 0, completed: false };

export interface Profile {
  skin: SkinConfig;
  levels: Record<string, LevelProgress>;
  lastLevelIndex: number;
  stats: PlayerStats;
}

export const profile = new Store<Profile>('profile', {
  skin: DEFAULT_SKIN,
  levels: {},
  lastLevelIndex: 0,
  stats: { attempts: 0, jumps: 0 },
});

export const MAX_STARS = LEVELS.reduce((sum, l) => sum + l.stars, 0);

export function getProgress(levelId: string): LevelProgress {
  return profile.get().levels[levelId] ?? EMPTY_PROGRESS;
}

/** Звёзды считаются из пройденных уровней, а не хранятся отдельно — так их нельзя «рассинхронизировать». */
export function totalStars(p: Readonly<Profile> = profile.get()): number {
  return LEVELS.reduce((sum, l) => sum + (p.levels[l.id]?.completed ? l.stars : 0), 0);
}

// ---- Запись результатов игры ------------------------------------------------

function patchLevel(
  id: string,
  fn: (p: LevelProgress) => LevelProgress,
  add: Partial<PlayerStats> = {},
): { prev: LevelProgress; next: LevelProgress } {
  const prof = profile.get();
  const prev = prof.levels[id] ?? EMPTY_PROGRESS;
  const next = fn(prev);
  profile.set({
    levels: { ...prof.levels, [id]: next },
    stats: {
      attempts: prof.stats.attempts + (add.attempts ?? 0),
      jumps: prof.stats.jumps + (add.jumps ?? 0),
    },
  });
  return { prev, next };
}

/** Начало попытки. jumps — прыжки, накопленные с прошлой записи. Возвращает номер попытки на уровне. */
export function recordAttemptStart(id: string, jumps = 0): number {
  return patchLevel(id, (p) => ({ ...p, attempts: p.attempts + 1, jumps: p.jumps + jumps }), { attempts: 1, jumps }).next
    .attempts;
}

/** Смерть: обновляем лучший процент */
export function recordRun(id: string, r: { practice: boolean; percent: number; jumps: number }): { newBest: boolean } {
  const { prev } = patchLevel(
    id,
    (p) => ({
      ...p,
      jumps: p.jumps + r.jumps,
      normal: r.practice ? p.normal : Math.max(p.normal, r.percent),
      practice: r.practice ? Math.max(p.practice, r.percent) : p.practice,
    }),
    { jumps: r.jumps },
  );
  return { newBest: !r.practice && r.percent > prev.normal };
}

export function recordCompletion(
  id: string,
  r: { practice: boolean; jumps: number },
): { firstClear: boolean; progress: LevelProgress } {
  const { prev, next } = patchLevel(
    id,
    (p) => ({
      ...p,
      jumps: p.jumps + r.jumps,
      normal: r.practice ? p.normal : 100,
      practice: 100,
      completed: p.completed || !r.practice,
    }),
    { jumps: r.jumps },
  );
  return { firstClear: !r.practice && !prev.completed, progress: next };
}

export function recordJumps(id: string, jumps: number): void {
  if (jumps > 0) patchLevel(id, (p) => ({ ...p, jumps: p.jumps + jumps }), { jumps });
}

// ---- Разблокировка иконок ---------------------------------------------------

export function unlockCurrent(rule: UnlockRule, p: Readonly<Profile> = profile.get()): number {
  switch (rule.kind) {
    case 'stars':
      return totalStars(p);
    case 'attempts':
      return p.stats.attempts;
    case 'jumps':
      return p.stats.jumps;
    case 'best':
      return Math.max(0, ...Object.values(p.levels).map((l) => l.normal));
  }
}

export function isIconUnlocked(def: IconDef, p: Readonly<Profile> = profile.get()): boolean {
  return !def.unlock || unlockCurrent(def.unlock, p) >= def.unlock.value;
}

export function resetProgress(): void {
  profile.set({ levels: {}, lastLevelIndex: 0, stats: { attempts: 0, jumps: 0 } });
  const p = profile.get();
  const icon = ICONS.find((i) => i.id === p.skin.icon);
  // После сброса выбранная иконка может стать закрытой — возвращаем стандартную.
  if (!icon || !isIconUnlocked(icon, p)) profile.set({ skin: { ...p.skin, icon: DEFAULT_SKIN.icon } });
}
