import { Store } from './Store';

export type ParticleQuality = 'off' | 'low' | 'high';

export interface Settings {
  /** 0..1 */
  musicVolume: number;
  /** 0..1 */
  sfxVolume: number;
  menuMusic: boolean;
  particles: ParticleQuality;
  menuAnimations: boolean;
  showFps: boolean;
  // Игровой HUD — используется начиная с этапа 2
  showProgressBar: boolean;
  showPercent: boolean;
  showAttempts: boolean;
  autoRetry: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  musicVolume: 0.7,
  sfxVolume: 0.8,
  menuMusic: true,
  particles: 'high',
  menuAnimations: true,
  showFps: false,
  showProgressBar: true,
  showPercent: true,
  showAttempts: true,
  autoRetry: true,
};

export const settings = new Store<Settings>('settings', DEFAULT_SETTINGS);
