import type { BlockTexture, ColorChannel, LevelData, LevelObject, LevelTheme, ObjectType, Zone } from '../game/types';
import { CORRIDOR_TOP, JUMP_TIME, SPEED } from '../game/physics';

/*
 * Построитель уровней «по долям».
 *
 * Игрок стартует в x = 0 одновременно с началом трека и движется с постоянной скоростью,
 * поэтому каждой доле музыки соответствует точная позиция:
 *     центр куба в долю k  =  4·k + 0.5   (4 клетки на долю, см. physics.ts)
 *
 * Прыжок с земли длится ровно одну долю, его вершина (2.1 клетки) — через 2 клетки.
 * Отсюда правила, по которым паттерны ниже ставят препятствия:
 *   • одиночный шип — центром под вершиной прыжка        (окно нажатия ≈ ±118 мс)
 *   • двойной шип — тоже центром под вершиной             (окно ≈ ±70 мс)
 *   • блок, на который надо запрыгнуть, — в 2 клетках от передней грани куба
 *   • тройных шипов нет: при такой физике окно было бы всего ±22 мс
 *
 * Паттерны с нажатием записывают его в solution — по нему движок может сам пройти уровень.
 */

/** Секунд в доле: трек уровня написан в 156 BPM */
export const BEAT = JUMP_TIME;
export const BLOCKS_PER_BEAT = SPEED * BEAT;

/** Центр куба по x в момент доли k */
export const cx = (k: number): number => BLOCKS_PER_BEAT * k + 0.5;

export class LevelBuilder {
  private readonly objects: LevelObject[] = [];
  private readonly clicks: number[] = [];
  private startColors: LevelData['colors'] = { bg: '#2a5fe0', ground: '#1d3fae', line: '#ffffff' };
  private levelTheme: LevelTheme = 'classic';
  private defaultTex: BlockTexture | undefined;

  constructor(
    private readonly id: string,
    private readonly songId: string,
  ) {}

  colors(c: LevelData['colors']): this {
    this.startColors = c;
    return this;
  }

  theme(t: LevelTheme): this {
    this.levelTheme = t;
    return this;
  }

  /** Текстура для следующих блоков (тема minecraft) */
  texture(tex: BlockTexture): this {
    this.defaultTex = tex;
    return this;
  }

  /** Смена зоны (земля/потолок/небо темы minecraft) к доле beat */
  zone(beat: number, zone: Zone): this {
    this.objects.push({ type: 'trigger-zone', x: cx(beat) - 1, y: 0, zone });
    return this;
  }

  /** Портал режима или гравитации; h — высота (по умолчанию весь коридор) */
  portal(type: Extract<ObjectType, `portal-${string}`>, x: number, y = 0, h = CORRIDOR_TOP): this {
    this.objects.push({ type, x, y, h });
    return this;
  }

  lava(x0: number, x1: number): this {
    this.objects.push({ type: 'lava', x: x0, y: 0, w: x1 - x0 });
    return this;
  }

  /**
   * Ворота для режимов с коридором: стена шириной w с проёмом от lo до hi.
   * Снизу — блок высотой lo, сверху — блок от hi до потолка.
   */
  gate(x: number, w: number, lo: number, hi: number, tex?: BlockTexture): this {
    if (lo > 0) this.block(x, x + w, lo, 0, tex);
    if (hi < CORRIDOR_TOP) this.block(x, x + w, CORRIDOR_TOP - hi, hi, tex);
    return this;
  }

  /** Шипы, свисающие с потолка коридора */
  ceilingSpikes(x: number, count = 1): this {
    for (let i = 0; i < count; i++) this.objects.push({ type: 'spike', x: x + i, y: CORRIDOR_TOP - 1, rot: 180 });
    return this;
  }

  // ---- Простые объекты ------------------------------------------------------

  /** Нажатие в долю k (дробная доля — восьмые и т.п.) */
  jump(k: number): this {
    this.clicks.push(k);
    return this;
  }

  /** Сплошной блок от x0 до x1 высотой h, стоящий на y */
  block(x0: number, x1: number, h: number, y = 0, tex = this.defaultTex): this {
    this.objects.push({ type: 'block', x: x0, y, w: x1 - x0, h, ...(tex ? { tex } : {}) });
    return this;
  }

  spikesAt(x: number, count = 1, y = 0): this {
    for (let i = 0; i < count; i++) this.objects.push({ type: 'spike', x: x + i, y });
    return this;
  }

  padAt(x: number, y = 0): this {
    this.objects.push({ type: 'pad-yellow', x, y });
    return this;
  }

  /** Орб по координатам центра */
  orbAt(centerX: number, centerY: number): this {
    this.objects.push({ type: 'orb-yellow', x: centerX - 0.5, y: centerY - 0.5 });
    return this;
  }

  /** Перекрасить канал к доле beat за durationBeats долей */
  color(beat: number, channel: ColorChannel, color: string, durationBeats = 0.5): this {
    this.objects.push({ type: 'trigger-color', x: cx(beat), y: 0, channel, color, duration: durationBeats * BLOCKS_PER_BEAT });
    return this;
  }

  flash(beat: number): this {
    this.objects.push({ type: 'trigger-flash', x: cx(beat), y: 0 });
    return this;
  }

  // ---- Ритмические паттерны (p — высота опоры, на которой стоит игрок) -------

  /** Одиночный шип, перепрыгиваемый нажатием в долю k */
  spike(k: number, p = 0): this {
    return this.spikesAt(cx(k) + 1.5, 1, p).jump(k);
  }

  /** Двойной шип под нажатие в долю k */
  spike2(k: number, p = 0): this {
    return this.spikesAt(cx(k) + 1, 2, p).jump(k);
  }

  /**
   * Яма из 4 шипов с орбом в вершине прыжка:
   * прыжок в долю k, орб — на «и» (k + ½), приземление ≈ k + 1.7.
   */
  orbPit(k: number): this {
    return this.orbAt(cx(k) + 2, 2.6).spikesAt(cx(k) + 1, 4).jump(k).jump(k + 0.5);
  }

  /** Батут в долю k и 4 шипа под дугой; приземление в k + 1.5 */
  padPit(k: number): this {
    return this.padAt(cx(k) + 0.4).spikesAt(cx(k) + 1.4, 4);
  }

  /**
   * withSolution: false — для уровней с кораблём/волной, где эталон «по долям» не записать;
   * их проходимость проверяет поиск (game/solver.ts).
   */
  build(length: number, withSolution = true): LevelData {
    const objects = [...this.objects].sort((a, b) => a.x - b.x);
    const solution = [...new Set(this.clicks)].sort((a, b) => a - b).map((k) => k * BEAT);
    return {
      version: 1,
      id: this.id,
      songId: this.songId,
      theme: this.levelTheme,
      length,
      colors: this.startColors,
      objects,
      ...(withSolution ? { solution } : {}),
    };
  }
}
