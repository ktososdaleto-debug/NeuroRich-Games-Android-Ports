import type { LevelData } from '../game/types';
import { runSolution } from '../game/verify';
import { BUILDERS } from './registry';

const cache = new Map<string, LevelData>();

export function getLevelData(id: string): LevelData {
  let data = cache.get(id);
  if (!data) {
    const build = BUILDERS[id];
    if (!build) throw new Error(`Уровень «${id}» не найден`);
    data = build();
    cache.set(id, data);
    if (import.meta.env.DEV) verifyInDev(data);
  }
  return data;
}

/**
 * В режиме разработки уровень проверяет себя сам: по эталонным нажатиям (если они есть),
 * а иначе — поиском прохождения в фоновом потоке. Итог — в консоли браузера (F12).
 */
function verifyInDev(level: LevelData): void {
  if (level.solution) {
    const r = runSolution(level);
    if (r.ok) console.info(`[уровень ${level.id}] автопрохождение: OK (${r.time.toFixed(1)} с)`);
    else console.warn(`[уровень ${level.id}] автопрохождение: ПРОВАЛ на ${r.percent}% (t = ${r.time.toFixed(2)} с)`);
    return;
  }
  console.info(`[уровень ${level.id}] ищу прохождение в фоне…`);
  const worker = new Worker(new URL('../game/solverWorker.ts', import.meta.url), { type: 'module' });
  worker.onmessage = (e: MessageEvent<{ ok: boolean; percent: number; ms: number; timedOut: boolean }>) => {
    const r = e.data;
    const time = `${(r.ms / 1000).toFixed(1)} с`;
    if (r.ok) console.info(`[уровень ${level.id}] автопрохождение: OK, путь найден за ${time}`);
    else if (r.timedOut) console.warn(`[уровень ${level.id}] проверка не уложилась во время, дошли до ${r.percent}%`);
    else console.warn(`[уровень ${level.id}] автопрохождение: ПРОВАЛ, дальше ${r.percent}% пройти нельзя`);
    worker.terminate();
  };
  worker.postMessage({ id: level.id });
}
