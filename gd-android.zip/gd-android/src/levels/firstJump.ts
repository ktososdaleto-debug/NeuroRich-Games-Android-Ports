import type { LevelData } from '../game/types';
import { LevelBuilder, cx } from './builder';

/*
 * «Первый прыжок» — под трек «Неоновый старт» (156 BPM, 48 тактов, ~74 с).
 * Числа в вызовах — номера долей (4 доли в такте). Почти все нажатия приходятся
 * на сильные доли, орбы — на «и» между ними. Блоки заданы диапазоном [x0, x1).
 */
export function buildFirstJump(): LevelData {
  const b = new LevelBuilder('first-jump', 'first-jump');
  b.colors({ bg: '#2a5fe0', ground: '#1d3fae', line: '#ffffff' });

  // ── Вступление (такты 1–4): разгон, первые шипы на сильные доли
  b.spike(8).spike(12).spike(14);

  // ── Куплет (такты 5–12)
  b.spike(16).spike(18);
  b.jump(20).block(83, 96, 1).spike(22, 1);
  b.spike2(26);
  b.spike(28).spike(29);
  b.jump(30).block(123, 130, 1);
  b.jump(32).block(131, 146, 2).spike(34, 2);
  b.spike(38).spike2(40);
  b.spike(42).spike(43);
  b.jump(44).block(179, 192, 1).spike(46, 1);

  // ── Нарастание (такты 13–16): лестница на высоту 4 под барабанную дробь
  b.color(48, 'bg', '#3b3fd9', 16).color(48, 'ground', '#2a2a9e', 16);
  b.jump(50).block(203, 211, 1);
  b.jump(52).block(211, 219, 2);
  b.jump(54).block(219, 227, 3);
  b.jump(56).block(227, 243, 4).spike(58, 4);
  b.spike(62);

  // ── Дроп 1 (такты 17–24): батуты, орбы, высокие платформы
  b.flash(64).color(64, 'bg', '#9a2fe0').color(64, 'ground', '#5d17a6');
  b.padPit(64);
  b.spike(66).spike(67);
  b.orbPit(68);
  b.spike2(71);
  b.padAt(cx(72) + 0.4).block(292, 306, 3).spike(74, 3);
  b.jump(76).spikesAt(306).block(307, 322, 3).spike2(78, 3);
  b.color(80, 'bg', '#d12fae', 4).color(80, 'ground', '#7d1068', 4);
  b.spike(82).spike(83);
  b.orbPit(84);
  b.spike(87).spike2(88);
  b.jump(90).block(363, 376, 1).spike(92, 1);
  b.spike(95);

  // ── Брейк (такты 25–28): тише и темнее, спокойные ступени
  b.color(96, 'bg', '#14246b', 4).color(96, 'ground', '#0c1747', 4).color(96, 'line', '#9fd4ff', 4);
  b.spike(98);
  b.jump(100).block(403, 411, 1);
  b.jump(102).block(411, 425, 2).spike(104, 2);
  b.spike(108).spike(110).spike(111);

  // ── Нарастание 2 (такты 29–32): шип на каждую долю и снова лестница
  b.color(112, 'bg', '#127a7a', 16).color(112, 'ground', '#0a4d4d', 16).color(112, 'line', '#ffffff', 8);
  b.spike(112).spike(113).spike2(114);
  b.jump(116).block(467, 475, 1);
  b.jump(118).block(475, 483, 2);
  b.jump(120).block(483, 496, 3).spike(122, 3);
  b.spike(126).spike(127);

  // ── Дроп 2 (такты 33–44): самая плотная часть
  b.flash(128).color(128, 'bg', '#e0262f').color(128, 'ground', '#8a0f17');
  b.padPit(128);
  b.orbPit(130);
  b.spike2(133).spike(134);
  b.padAt(cx(136) + 0.4).block(548, 562, 3).spike2(138, 3);
  b.jump(140).spikesAt(562).block(563, 571, 3);
  // с платформы — орб над пропастью на соседнюю платформу
  b.jump(142).orbAt(cx(142) + 2, 3 + 2.6).jump(142.5).spikesAt(571, 3).block(574, 592, 3);
  b.color(144, 'bg', '#ff6a00', 4).color(144, 'ground', '#a33d00', 4);
  b.spike(144, 3).spike2(146, 3);
  b.spike(150).spike(151);
  b.orbPit(152);
  b.spike(155);
  b.padPit(156);
  b.spike2(158);
  b.color(160, 'bg', '#e0262f', 4).color(160, 'ground', '#8a0f17', 4);
  b.spike(160).spike(161).spike(162);
  b.jump(163).block(655, 667, 1).spike(165, 1);
  b.orbPit(168);
  b.spike2(171).spike(172).spike(173);

  // ── Концовка (такты 45–48): пара последних прыжков и финиш
  b.color(176, 'bg', '#2a5fe0', 8).color(176, 'ground', '#1d3fae', 8);
  b.spike(176).spike(180);

  return b.build(760);
}
