import type { LevelData } from '../game/types';
import { LevelBuilder, cx } from './builder';

/*
 * «Блочный мир» — уровень в стиле Minecraft под трек «Пиксельный рассвет»
 * (156 BPM, 56 тактов, ~86 с). Пять режимов, по одному на «измерение»:
 *
 *   доли   0–47   Поверхность — куб: трава, деревья, батуты, орбы
 *   доли  48–79   Пещера      — корабль: каменные ворота, проём 4 клетки
 *   доли  80–111  Шахта       — шар: шипы на полу и потолке, переворот в долю
 *   доли 112–143  Незер       — НЛО над лавой: нажатие в каждую долю держит высоту
 *   доли 144–175  Энд         — волна: обсидиановые ворота каждые 2 доли
 *   доли 176–219  Рассвет     — снова куб, финальный забег
 *
 * Порталы стоят ровно на сильных долях — в момент смены партии в музыке.
 * Проёмы в коридорных режимах — не меньше 4 клеток, а сдвиг между соседними
 * воротами — не больше 3 клеток, поэтому каждый участок проходится с запасом.
 */

/** Шар: переворот на потолок в долю k и обратно в k + 2 (пол и потолок с шипами) */
function ballZig(b: LevelBuilder, k: number): void {
  b.spikesAt(cx(k) + 2, 5).ceilingSpikes(cx(k + 2) + 2, 5).jump(k).jump(k + 2);
}

/** Шар: быстрый переворот обратно на «и» (k + 1½) */
function ballQuick(b: LevelBuilder, k: number): void {
  b.spikesAt(cx(k) + 2, 3).ceilingSpikes(cx(k + 1.5) + 2, 4).jump(k).jump(k + 1.5);
}

export function buildBlockWorld(): LevelData {
  const b = new LevelBuilder('block-world', 'block-world');
  b.theme('minecraft').colors({ bg: '#7ec8ff', ground: '#ffffff', line: '#ffffff', obj: '#ffffff' });

  // ── Поверхность (такты 1–12): куб ────────────────────────────────────────────
  b.zone(0, 'surface').texture('grass');
  b.spike(8).spike(12).spike(14);
  b.jump(16).block(67, 80, 1).spike(18, 1);
  b.spike2(22);
  b.padPit(24);
  b.spike(26).spike(27);
  b.orbPit(28);
  // «дерево»: ступени из булыжника и досок
  b.jump(31).block(127, 135, 1, 0, 'cobble');
  b.jump(33).block(135, 147, 2, 0, 'planks').spike(35, 2);
  b.spike(38).spike(39).spike2(40);
  b.spike(42).spike(43).spike(44);

  // ── Пещера (такты 13–20): корабль ───────────────────────────────────────────
  b.zone(48, 'cave').flash(48).color(48, 'bg', '#2d313b', 1).texture('stone');
  b.portal('portal-ship', 192);
  // ворота каждые 3 доли: [x, нижний край проёма]
  for (const [x, lo] of [
    [204, 2], [216, 4], [228, 1], [240, 3], [252, 5], [264, 2], [276, 4], [288, 1], [300, 3],
  ]) {
    b.gate(x, 2, lo, lo + 4);
  }
  b.spikesAt(231, 8); // нельзя ползти по полу
  b.ceilingSpikes(255, 8); // и прижиматься к потолку

  // ── Шахта (такты 21–28): шар ────────────────────────────────────────────────
  b.color(80, 'bg', '#3b2414', 4).portal('portal-ball', 320);
  ballZig(b, 84);
  ballZig(b, 88);
  ballQuick(b, 92);
  ballZig(b, 96);
  ballZig(b, 100);
  ballQuick(b, 104);

  // ── Незер (такты 29–36): НЛО над лавой ──────────────────────────────────────
  b.zone(112, 'nether').flash(112).color(112, 'bg', '#5c1010', 1).texture('netherrack');
  b.portal('portal-ufo', 448);
  b.lava(456, 572);
  for (const [x, lo] of [
    [460, 1], [472, 2], [484, 3], [496, 1], [508, 3], [520, 2], [532, 4], [544, 2], [556, 3],
  ]) {
    b.gate(x, 2, lo, lo + 4);
  }

  // ── Энд (такты 37–44): волна ────────────────────────────────────────────────
  b.zone(144, 'end').flash(144).color(144, 'bg', '#140b24', 1).texture('obsidian');
  b.portal('portal-wave', 576);
  for (const [x, lo] of [
    [588, 3], [596, 1], [604, 4], [612, 2], [620, 5], [628, 2], [636, 0],
    [644, 3], [652, 1], [660, 4], [668, 2], [676, 4], [684, 2],
  ]) {
    b.gate(x, 1, lo, lo + 4);
  }
  b.spikesAt(598, 5);
  b.ceilingSpikes(614, 5);

  // ── Рассвет (такты 45–56): финальный забег кубом ────────────────────────────
  b.zone(176, 'surface').flash(176).color(176, 'bg', '#ff9e5e', 1).color(196, 'bg', '#7ec8ff', 12).texture('grass');
  b.portal('portal-cube', 704);
  b.spike(180).spike2(182);
  b.padPit(184);
  b.spike(186).spike(187);
  b.orbPit(188);
  b.jump(191).block(767, 775, 1, 0, 'planks');
  b.jump(193).block(775, 783, 2, 0, 'planks');
  b.jump(195).block(783, 795, 3, 0, 'log').spike(197, 3);
  b.spike(200).spike(201).spike2(202);
  b.padPit(204);
  b.orbPit(206);
  b.spike(210).spike(212).spike(214);

  return b.build(880, false);
}
