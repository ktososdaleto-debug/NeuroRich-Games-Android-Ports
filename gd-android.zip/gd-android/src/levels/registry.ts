import type { LevelData } from '../game/types';
import { buildFirstJump } from './firstJump';
import { buildBlockWorld } from './blockWorld';

/** Все уровни игры. Без DOM — используется и в основном потоке, и в воркере проверки. */
export const BUILDERS: Record<string, () => LevelData> = {
  'first-jump': buildFirstJump,
  'block-world': buildBlockWorld,
};
