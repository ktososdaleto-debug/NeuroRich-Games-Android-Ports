import type { LevelObject } from './types';

/**
 * Перевод точки из локальных координат клетки объекта (0..1) в мир,
 * с учётом поворота объекта вокруг центра клетки (по часовой стрелке).
 */
export function cellToWorld(o: LevelObject, lx: number, ly: number): [number, number] {
  const dx = lx - 0.5;
  const dy = ly - 0.5;
  let rx = dx;
  let ry = dy;
  switch (o.rot ?? 0) {
    case 90:
      rx = dy;
      ry = -dx;
      break;
    case 180:
      rx = -dx;
      ry = -dy;
      break;
    case 270:
      rx = -dy;
      ry = dx;
      break;
  }
  return [o.x + 0.5 + rx, o.y + 0.5 + ry];
}
