/*
 * Константы физики куба. Единицы — клетки и секунды.
 *
 * Скорость и длительность прыжка подобраны так, что под трек 156 BPM
 * одна доля = ровно 4 клетки, а прыжок с земли длится ровно одну долю:
 * нажал в долю — приземлился в следующую долю.
 */

/** Шаг фиксированной симуляции */
export const DT = 1 / 240;

/** Горизонтальная скорость, клеток/с */
export const SPEED = 10.4;
/** Время прыжка с земли до земли, с */
export const JUMP_TIME = 60 / 156;
/** Высота прыжка, клеток */
export const JUMP_HEIGHT = 2.1;

export const GRAVITY = (8 * JUMP_HEIGHT) / (JUMP_TIME * JUMP_TIME);
export const JUMP_VELOCITY = (4 * JUMP_HEIGHT) / JUMP_TIME;
export const MAX_FALL = 32;

/** Жёлтый батут: прыжок в 1.5 раза сильнее (≈4.7 клетки вверх) */
export const PAD_BOOST = 1.5;
/** Жёлтый орб: обычный прыжок прямо в воздухе */
export const ORB_BOOST = 1;

/** Полоборота за прыжок — приземляемся ровно на грань */
export const ROTATION_SPEED = Math.PI / JUMP_TIME;

// ---- Другие режимы ----------------------------------------------------------

/** Во всех режимах, кроме куба, есть потолок: коридор от земли до этой высоты */
export const CORRIDOR_TOP = 9;

/** Корабль: держите — летит вверх, отпустите — вниз */
export const SHIP_UP = 52;
export const SHIP_DOWN = 42;
export const SHIP_MAX = 8.5;

/** Шар: нажатие меняет гравитацию; от пола до потолка ≈ одна доля */
export const BALL_GRAVITY = 79;
export const BALL_KICK = 3;

/** НЛО: каждое нажатие — подскок; нажатия в каждую долю держат высоту */
export const UFO_GRAVITY = 60;
export const UFO_JUMP = 12;
export const UFO_MAX_FALL = 14;

/** Волна: держите — вверх под 45°, отпустите — вниз под 45° */
export const WAVE_SPEED = SPEED;

/** Насколько «ниже верха» блока куб ещё может на него встать, клеток */
export const LAND_SNAP = 0.25;
/** Нажатие, сделанное чуть раньше входа в орб, всё ещё засчитывается, с */
export const PRESS_BUFFER = 0.1;
