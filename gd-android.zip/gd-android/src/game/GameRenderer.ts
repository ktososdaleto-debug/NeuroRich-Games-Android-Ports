import { Container, Graphics, Sprite, Text, Texture, TilingSprite, type Application } from 'pixi.js';
import type { GameMode, LevelData, LevelObject, Zone } from './types';
import type { SimEvent, Simulation } from './Simulation';
import { ColorTrack } from './colors';
import { cellToWorld } from './geometry';
import { CORRIDOR_TOP, SPEED } from './physics';
import { createCubeCanvas } from '../render/cubeArt';
import { createVehicleCanvas } from '../render/vehicleArt';
import { makeBlockTextures } from '../render/minecraftArt';
import { makeGlowCanvas, makeHLineCanvas, makePatternCanvas, makeShadeCanvas } from '../render/textures';
import { hexToRgb, lerpRgb, rgbToNum, scaleRgb, type RGB } from '../core/color';
import { effectOf, type SkinConfig } from '../data/skins';
import type { EffectDef, ParticleShape } from '../data/effects';
import type { ParticleQuality } from '../state/settings';

const TEX = 128;
const TEX_PAD = 32;
const WHITE: RGB = [1, 1, 1];
const PARTICLES: Record<ParticleQuality, number> = { off: 0, low: 0.5, high: 1 };
/** Камера держит игрока примерно на этой высоте над низом экрана */
const CAMERA_LIFT = 2.6;
const WAVE_TRAIL_POINTS = 90;

const PORTAL_COLORS: Record<string, number> = {
  'portal-cube': 0x5dff5d,
  'portal-ship': 0xff5fd8,
  'portal-ball': 0xff7a1a,
  'portal-ufo': 0xffb31a,
  'portal-wave': 0x3fd8ff,
  'portal-gravity-up': 0xffe14a,
  'portal-gravity-down': 0x3f9bff,
};

/** Земля, потолок и небо для зон темы minecraft */
const ZONE_GROUND: Record<Zone, { top: string; body: string; clouds: boolean }> = {
  surface: { top: 'grassTop', body: 'dirt', clouds: true },
  cave: { top: 'stone', body: 'stone', clouds: false },
  nether: { top: 'netherrack', body: 'netherrack', clouds: false },
  end: { top: 'endstone', body: 'endstone', clouds: false },
};

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: number;
  shape: ParticleShape | 'ring';
  additive: boolean;
  gravity: number;
  rot: number;
  spin: number;
}

/** Первый индекс, у которого x >= value (массив отсортирован по x) */
function lowerBound(list: LevelObject[], value: number): number {
  let lo = 0;
  let hi = list.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (list[mid].x < value) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}

const rand = (a: number, b: number) => a + Math.random() * (b - a);

/** Пул спрайтов: каждый кадр раздаём заново, лишние прячем */
class SpritePool {
  readonly root = new Container();
  private readonly sprites: Sprite[] = [];
  private used = 0;

  begin(): void {
    this.used = 0;
  }

  take(texture: Texture): Sprite {
    let s = this.sprites[this.used];
    if (!s) {
      s = new Sprite(texture);
      this.sprites.push(s);
      this.root.addChild(s);
    }
    s.texture = texture;
    s.visible = true;
    s.rotation = 0;
    s.anchor.set(0);
    this.used++;
    return s;
  }

  end(): void {
    for (let i = this.used; i < this.sprites.length; i++) this.sprites[i].visible = false;
  }
}

/**
 * Отрисовка уровня. Ничего не решает сам — только показывает состояние Simulation.
 * Видимые объекты перерисовываются каждый кадр прямо в экранных пикселях:
 * на экране их всего десятки, а чёткость линий не зависит от масштаба.
 */
export class GameRenderer {
  private readonly root = new Container();
  private readonly sky = new Graphics();
  private readonly pattern: TilingSprite;
  private readonly clouds: TilingSprite | null = null;
  private readonly shade = new Sprite();
  private readonly attempt: Text;
  private readonly ceilingFill = new Graphics();
  private readonly levelFill = new Graphics();
  private readonly levelLine = new Graphics();
  private readonly tiles = new SpritePool();
  private readonly dyn = new Graphics();
  private readonly groundFill = new Graphics();
  private readonly groundDetail = new Graphics();
  private readonly groundLine = new Sprite();
  private readonly groundGlow = new Sprite();
  private readonly waveTrail = new Graphics();
  private readonly fx = new Graphics();
  private readonly fxAdd = new Graphics();
  private readonly aura = new Sprite();
  private readonly player = new Sprite();
  private readonly flash = new Graphics();
  private readonly textures: Texture[] = [];

  // тема minecraft
  private readonly mc: Record<string, Texture> | null = null;
  private readonly groundTop: TilingSprite | null = null;
  private readonly groundBody: TilingSprite | null = null;
  private readonly ceilingBody: TilingSprite | null = null;
  private readonly zones: Array<{ x: number; zone: Zone }> = [];
  private cloudAlpha = 0;

  private readonly colors: ColorTrack;
  private readonly statics: LevelObject[];
  private readonly maxStaticWidth: number;
  private readonly pads: LevelObject[];
  private readonly orbs: LevelObject[];
  private readonly portals: LevelObject[];
  private readonly usedOrbs = new Set<LevelObject>();
  private checkpoints: Array<{ x: number; y: number }> = [];
  private particles: Particle[] = [];
  private wavePoints: Array<[number, number]> = [];
  private readonly modeTextures = new Map<GameMode, Texture>();
  private shownMode: GameMode | null = null;
  private readonly primary: number;
  private readonly secondary: number;
  private readonly effect: EffectDef | null;
  private readonly particleMul: number;

  private W = 0;
  private H = 0;
  private u = 60;
  private groundBase = 0;
  private playerScreenX = 0;
  private camX = 0;
  private camY = 0;
  private shake = 0;
  private flashLevel = 0;
  private trailAcc = 0;
  private clock = 0;
  private attemptX = 0;
  private attemptY = 0;
  private exitT = -1;
  private exitBurst = false;

  constructor(
    private readonly app: Application,
    private readonly level: LevelData,
    private readonly skin: SkinConfig,
    quality: ParticleQuality,
  ) {
    this.colors = new ColorTrack(level);
    this.statics = level.objects.filter((o) => o.type === 'block' || o.type === 'spike' || o.type === 'small-spike' || o.type === 'lava');
    this.maxStaticWidth = Math.max(1, ...this.statics.map((o) => o.w ?? 1));
    this.pads = level.objects.filter((o) => o.type === 'pad-yellow');
    this.orbs = level.objects.filter((o) => o.type === 'orb-yellow');
    this.portals = level.objects.filter((o) => o.type.startsWith('portal-'));
    this.effect = effectOf(skin);
    this.primary = this.effect?.colors[0] ?? rgbToNum(hexToRgb(skin.primary));
    this.secondary = rgbToNum(hexToRgb(skin.secondary));
    this.particleMul = PARTICLES[quality];

    this.shade.texture = this.tex(makeShadeCanvas());
    this.pattern = new TilingSprite({ texture: this.tex(makePatternCanvas()), width: 1, height: 1 });
    this.pattern.alpha = 0.22;
    this.groundLine.texture = this.tex(makeHLineCanvas());
    this.groundLine.anchor.set(0.5);
    const glow = this.tex(makeGlowCanvas());
    this.groundGlow.texture = glow;
    this.groundGlow.anchor.set(0.5);
    this.groundGlow.blendMode = 'add';
    this.aura.texture = glow;
    this.aura.anchor.set(0.5);
    this.aura.blendMode = 'add';
    this.aura.visible = !!this.effect?.aura;
    if (this.effect?.aura) this.aura.tint = this.effect.aura;
    this.player.anchor.set(0.5);
    this.flash.alpha = 0;
    this.fxAdd.blendMode = 'add';

    this.attempt = new Text({
      text: '',
      style: {
        fontFamily: 'Russo One, sans-serif',
        fontSize: 64,
        fill: 0xffffff,
        stroke: { color: 0x000000, width: 10, join: 'round' },
      },
    });
    this.attempt.anchor.set(0.5);

    if (level.theme === 'minecraft') {
      const set = makeBlockTextures().canvases;
      const mc: Record<string, Texture> = {};
      for (const [name, canvas] of Object.entries(set)) {
        const t = this.tex(canvas);
        t.source.scaleMode = 'nearest';
        mc[name] = t;
      }
      this.mc = mc;
      this.clouds = new TilingSprite({ texture: mc.clouds, width: 1, height: 1 });
      this.groundTop = new TilingSprite({ texture: mc.grassTop, width: 1, height: 1 });
      this.groundBody = new TilingSprite({ texture: mc.dirt, width: 1, height: 1 });
      this.ceilingBody = new TilingSprite({ texture: mc.stone, width: 1, height: 1 });
      this.pattern.visible = false;
      for (const o of level.objects) if (o.type === 'trigger-zone' && o.zone) this.zones.push({ x: o.x, zone: o.zone });
      this.zones.sort((a, b) => a.x - b.x);
    }

    this.root.addChild(this.sky, this.pattern);
    if (this.clouds) this.root.addChild(this.clouds);
    this.root.addChild(this.shade, this.attempt, this.ceilingFill);
    if (this.ceilingBody) this.root.addChild(this.ceilingBody);
    this.root.addChild(this.levelFill, this.tiles.root, this.levelLine, this.dyn, this.groundFill);
    if (this.groundTop && this.groundBody) this.root.addChild(this.groundBody, this.groundTop);
    this.root.addChild(
      this.groundDetail,
      this.groundLine,
      this.groundGlow,
      this.waveTrail,
      this.fx,
      this.fxAdd,
      this.aura,
      this.player,
      this.flash,
    );
    app.stage.addChild(this.root);
  }

  // ---- Публичное API ---------------------------------------------------------

  /** Новая попытка (с начала или с чекпоинта) */
  reset(sim: Simulation, attempt: number, showAttempt: boolean): void {
    this.layout();
    this.particles = [];
    this.wavePoints = [];
    this.usedOrbs.clear();
    this.player.visible = true;
    this.aura.visible = !!this.effect?.aura;
    this.exitT = -1;
    this.exitBurst = false;
    this.shake = 0;
    this.camY = this.cameraTarget(sim);
    this.attemptX = sim.x + 8;
    this.attemptY = Math.max(4.6, sim.y + 4);
    this.attempt.text = `Попытка ${attempt}`;
    this.attempt.visible = showAttempt;
  }

  addCheckpoint(x: number, y: number): void {
    this.checkpoints.push({ x, y });
  }

  removeCheckpoint(): void {
    this.checkpoints.pop();
  }

  clearCheckpoints(): void {
    this.checkpoints = [];
  }

  onEvent(e: SimEvent): void {
    const cx = e.x + 0.5;
    switch (e.type) {
      case 'jump':
        this.burst(cx - 0.3, e.y + 0.05, 5, 3, this.primary, 0.14);
        break;
      case 'land':
        this.burst(cx, e.y + 0.05, 4, 2, this.primary, 0.12);
        break;
      case 'pad':
        this.ring(cx, e.y + 0.2, 1.6, 0xffd21f);
        this.burst(cx, e.y + 0.1, 10, 5, 0xffe14a, 0.16);
        break;
      case 'portal':
        this.ring(cx, e.y + 0.5, 2.4, 0xffffff);
        this.flashLevel = Math.max(this.flashLevel, 0.25);
        break;
      case 'orb': {
        let best: LevelObject | null = null;
        let bestD = Infinity;
        for (const o of this.orbs) {
          const d = Math.hypot(o.x + 0.5 - cx, o.y + 0.5 - (e.y + 0.5));
          if (d < bestD) {
            bestD = d;
            best = o;
          }
        }
        if (best && bestD < 2) {
          this.usedOrbs.add(best);
          this.ring(best.x + 0.5, best.y + 0.5, 1.8, 0xffe14a);
        }
        break;
      }
      case 'death':
        this.explode(cx, e.y + 0.5);
        this.player.visible = false;
        this.aura.visible = false;
        this.shake = this.effect?.deathScale ? 1.6 : 1;
        this.flashLevel = Math.max(this.flashLevel, this.effect?.deathScale ? 0.6 : 0.35);
        break;
      case 'complete':
        this.exitT = 0;
        this.flashLevel = 0.6;
        break;
    }
  }

  render(sim: Simulation, dt: number, beat: number, intensity: number): void {
    this.layout();
    this.clock += dt;
    const u = this.u;

    // После финиша иконка улетает в свет, камера останавливается
    let px = sim.x;
    let py = sim.y;
    let rot = sim.rot;
    if (sim.complete && this.exitT >= 0) {
      this.exitT += dt;
      const t = this.exitT;
      px += SPEED * t;
      py += 3 * t * t;
      rot += 8 * t;
      if (t > 0.45 && !this.exitBurst) {
        this.exitBurst = true;
        this.explode(px + 0.5, py + 0.5);
        this.player.visible = false;
        this.aura.visible = false;
      }
    } else {
      this.camX = sim.x + 0.5 - this.playerScreenX / u;
    }
    this.camY += (this.cameraTarget(sim) - this.camY) * (1 - Math.exp(-dt * 5));

    const pulse = beat >= 0 ? intensity * Math.exp(-(beat - Math.floor(beat)) * 4.5) : 0;
    const at = Math.min(sim.x, this.level.length) + 0.5;
    const bg = this.colors.at('bg', at);
    const ground = this.colors.at('ground', at);
    const objTint = rgbToNum(this.colors.at('obj', at));
    const lineTint = rgbToNum(lerpRgb(this.colors.at('line', at), WHITE, pulse * 0.35));

    this.sky.tint = rgbToNum(scaleRgb(bg, 1 + pulse * 0.1));
    this.pattern.tint = rgbToNum(scaleRgb(bg, 1.4));
    this.pattern.tilePosition.set(-this.camX * u * 0.15, this.camY * u * 0.1);

    const gy = this.sy(0);
    const zone = this.zoneAt(at);
    if (this.mc) this.drawMinecraftGround(gy, ground, zone, sim.corridor, dt);
    else this.drawGround(gy, ground, lineTint, pulse, sim.corridor);

    const x0 = this.camX - 1;
    const x1 = this.camX + this.W / u + 1;
    this.drawStatics(x0, x1, lineTint, objTint);
    this.drawDynamic(x0, x1, gy, pulse);

    this.updatePlayerSprite(sim.mode);
    if (this.player.visible) {
      const sx = this.sx(px + 0.5);
      const sy = this.sy(py + 0.5);
      this.player.position.set(sx, sy);
      this.player.rotation = rot;
      this.aura.position.set(sx, sy);
      this.aura.width = u * 2.6;
      this.aura.height = u * 2.6;
      this.aura.alpha = 0.35 + pulse * 0.35;
    }
    this.updateWaveTrail(sim, px, py);
    if (!sim.dead && !sim.complete) this.emitTrail(dt, sim, px, py);
    this.updateParticles(dt);

    this.attempt.position.set(this.sx(this.attemptX), this.sy(this.attemptY));

    const flashTarget = sim.dead || sim.complete ? 0 : this.colors.flashAt(at);
    this.flashLevel = Math.max(flashTarget, this.flashLevel * Math.exp(-dt * 3));
    this.flash.alpha = this.flashLevel * 0.8;

    if (this.shake > 0.01) {
      this.root.position.set((Math.random() - 0.5) * this.shake * u * 0.3, (Math.random() - 0.5) * this.shake * u * 0.3);
      this.shake *= Math.exp(-dt * 8);
    } else if (this.shake !== 0) {
      this.shake = 0;
      this.root.position.set(0, 0);
    }
  }

  destroy(): void {
    this.app.stage.removeChild(this.root);
    this.root.destroy({ children: true });
    for (const t of this.textures) t.destroy(true);
  }

  // ---- Внутреннее ------------------------------------------------------------

  private tex(canvas: HTMLCanvasElement): Texture {
    const t = Texture.from(canvas);
    this.textures.push(t);
    return t;
  }

  private sx(wx: number): number {
    return (wx - this.camX) * this.u;
  }

  private sy(wy: number): number {
    return this.groundBase - (wy - this.camY) * this.u;
  }

  /** В режимах с коридором камера показывает весь коридор, у куба — следит за высотой */
  private cameraTarget(sim: Simulation): number {
    if (sim.corridor) return CORRIDOR_TOP / 2 - (this.groundBase - this.H / 2) / this.u;
    return Math.max(0, sim.y - CAMERA_LIFT);
  }

  private zoneAt(x: number): Zone {
    let zone: Zone = 'surface';
    for (const z of this.zones) {
      if (z.x > x) break;
      zone = z.zone;
    }
    return zone;
  }

  private layout(): void {
    const { width, height } = this.app.screen;
    if (width === this.W && height === this.H) return;
    this.W = width;
    this.H = height;
    this.u = Math.min(height / 10.5, width / 15);
    this.groundBase = Math.round(height * 0.74);
    this.playerScreenX = Math.min(width * 0.32, this.u * 7);
    this.sky.clear().rect(0, 0, width, height).fill(0xffffff);
    this.pattern.width = width;
    this.pattern.height = height;
    this.pattern.tileScale.set((this.u * 8) / 256);
    if (this.clouds) {
      this.clouds.width = width;
      this.clouds.height = height * 0.5;
      this.clouds.tileScale.set(this.u / 8);
    }
    this.shade.width = width;
    this.shade.height = height;
    this.flash.clear().rect(0, 0, width, height).fill(0xffffff);
    this.player.scale.set(this.u / TEX);
    this.attempt.scale.set((this.u * 0.8) / 64);
    this.groundLine.width = width;
    this.groundLine.height = 4;
    this.groundGlow.width = this.u * 14;
    this.groundGlow.height = this.u * 2;
  }

  private updatePlayerSprite(mode: GameMode): void {
    if (mode === this.shownMode) return;
    this.shownMode = mode;
    let t = this.modeTextures.get(mode);
    if (!t) {
      const canvas =
        mode === 'cube' ? createCubeCanvas(TEX, this.skin, { pad: TEX_PAD, dpr: 1 }) : createVehicleCanvas(mode, this.skin);
      t = this.tex(canvas);
      this.modeTextures.set(mode, t);
    }
    this.player.texture = t;
    this.wavePoints = [];
  }

  // ---- Земля и потолок -------------------------------------------------------

  private drawGround(gy: number, ground: RGB, lineTint: number, pulse: number, corridor: boolean): void {
    const { W, H, u } = this;
    const gf = this.groundFill.clear();
    const gd = this.groundDetail.clear();
    const tile = u * 4;
    const off = (((this.camX * u) % tile) + tile) % tile;
    if (gy < H) {
      gf.rect(0, gy, W, H - gy).fill(0xffffff);
      for (let x = -off; x < W; x += tile) {
        gd.rect(x + 2, gy + 4, tile - 4, H - gy).stroke({ width: 2, color: 0x000000, alpha: 0.2 });
      }
      gd.rect(0, gy, W, u * 0.6).fill({ color: 0x000000, alpha: 0.18 });
    }
    gf.tint = rgbToNum(ground);

    // потолок коридора — перевёрнутая земля
    const cf = this.ceilingFill.clear();
    if (corridor) {
      const cy = this.sy(CORRIDOR_TOP);
      if (cy > 0) {
        cf.rect(0, 0, W, cy).fill(rgbToNum(ground));
        cf.rect(0, cy - u * 0.6, W, u * 0.6).fill({ color: 0x000000, alpha: 0.18 });
        cf.rect(0, cy - 2, W, 4).fill(lineTint);
      }
    }

    this.groundLine.position.set(W / 2, gy);
    this.groundLine.tint = lineTint;
    this.groundGlow.position.set(this.playerScreenX, gy);
    this.groundGlow.tint = lineTint;
    this.groundGlow.alpha = 0.25 + pulse * 0.45;
  }

  private drawMinecraftGround(gy: number, ground: RGB, zone: Zone, corridor: boolean, dt: number): void {
    const mc = this.mc!;
    const { W, H, u } = this;
    const z = ZONE_GROUND[zone];
    const tint = rgbToNum(ground);
    const scroll = -this.camX * u;
    const top = this.groundTop!;
    const body = this.groundBody!;
    top.texture = mc[z.top];
    body.texture = mc[z.body];
    for (const s of [top, body]) {
      s.tileScale.set(u / 16);
      s.tilePosition.x = scroll;
      s.width = W;
      s.tint = tint;
    }
    top.position.set(0, gy);
    top.height = Math.max(0, Math.min(u, H - gy));
    body.position.set(0, gy + u);
    body.height = Math.max(0, H - gy - u);
    top.visible = gy < H;
    body.visible = gy + u < H;

    const ceil = this.ceilingBody!;
    const cy = this.sy(CORRIDOR_TOP);
    ceil.visible = corridor && cy > 0;
    if (ceil.visible) {
      ceil.texture = mc[z.body];
      ceil.tileScale.set(u / 16);
      ceil.tilePosition.set(scroll, cy % u);
      ceil.position.set(0, 0);
      ceil.width = W;
      ceil.height = cy;
      ceil.tint = tint;
    }
    const cf = this.ceilingFill.clear();
    if (ceil.visible) cf.rect(0, cy - 3, W, 6).fill({ color: 0x000000, alpha: 0.45 });

    if (this.clouds) {
      this.cloudAlpha += ((z.clouds ? 0.85 : 0) - this.cloudAlpha) * Math.min(1, dt * 3);
      this.clouds.alpha = this.cloudAlpha;
      this.clouds.visible = this.cloudAlpha > 0.01;
      this.clouds.tilePosition.set(-this.camX * u * 0.2 - this.clock * 6, u * 0.6);
    }
    this.groundFill.clear();
    this.groundDetail.clear().rect(0, gy - 1, W, 3).fill({ color: 0x000000, alpha: 0.35 });
    this.groundLine.visible = false;
    this.groundGlow.visible = false;
  }

  // ---- Объекты уровня --------------------------------------------------------

  private drawStatics(x0: number, x1: number, lineTint: number, objTint: number): void {
    const f = this.levelFill.clear();
    const l = this.levelLine.clear();
    l.tint = this.mc ? 0xffffff : lineTint;
    this.tiles.begin();
    const lw = Math.max(2, this.u * 0.06);
    const thin = Math.max(1, this.u * 0.025);
    for (let i = lowerBound(this.statics, x0 - this.maxStaticWidth); i < this.statics.length; i++) {
      const o = this.statics[i];
      if (o.x > x1) break;
      if (o.x + (o.w ?? 1) < x0) continue;
      if (o.type === 'lava') this.drawLava(f, o);
      else if (this.mc) {
        if (o.type === 'block') this.drawMinecraftBlock(l, o, objTint);
        else this.drawMinecraftSpike(o, objTint);
      } else if (o.type === 'block') this.drawBlock(f, l, o, lw, thin);
      else this.drawSpike(f, l, o, lw, thin);
    }
    this.tiles.end();
  }

  private drawBlock(f: Graphics, l: Graphics, o: LevelObject, lw: number, thin: number): void {
    const u = this.u;
    const w = o.w ?? 1;
    const h = o.h ?? 1;
    const left = this.sx(o.x);
    const top = this.sy(o.y + h);
    const pw = w * u;
    const ph = h * u;
    f.rect(left, top, pw, ph).fill({ color: 0x000000, alpha: 0.85 });
    f.rect(left, top, pw, Math.min(ph, u * 0.4)).fill({ color: 0xffffff, alpha: 0.05 });
    if (w > 1 || h > 1) {
      for (let i = 1; i < w; i++) l.moveTo(left + i * u, top).lineTo(left + i * u, top + ph);
      for (let j = 1; j < h; j++) l.moveTo(left, top + j * u).lineTo(left + pw, top + j * u);
      l.stroke({ width: thin, color: 0xffffff, alpha: 0.18 });
    }
    l.rect(left + lw / 2, top + lw / 2, pw - lw, ph - lw).stroke({ width: lw, color: 0xffffff });
  }

  private drawSpike(f: Graphics, l: Graphics, o: LevelObject, lw: number, thin: number): void {
    const height = o.type === 'small-spike' ? 0.45 : 0.92;
    const local: Array<[number, number]> = [
      [0.08, 0],
      [0.5, height],
      [0.92, 0],
    ];
    const pts: number[] = [];
    const inner: number[] = [];
    for (const [lx, ly] of local) {
      const [wx, wy] = cellToWorld(o, lx, ly);
      pts.push(this.sx(wx), this.sy(wy));
      const [ix, iy] = cellToWorld(o, 0.5 + (lx - 0.5) * 0.5, height * 0.25 + ly * 0.5);
      inner.push(this.sx(ix), this.sy(iy));
    }
    f.poly(pts).fill({ color: 0x000000, alpha: 0.92 });
    l.poly(pts).stroke({ width: lw, color: 0xffffff, join: 'round' });
    l.poly(inner).stroke({ width: thin, color: 0xffffff, alpha: 0.3, join: 'round' });
  }

  private drawLava(f: Graphics, o: LevelObject): void {
    const u = this.u;
    const w = o.w ?? 1;
    const glow = 0.5 + 0.5 * Math.sin(this.clock * 4);
    if (this.mc) {
      const mc = this.mc;
      const tint = rgbToNum(lerpRgb([1, 1, 1], [1, 0.85, 0.6], glow));
      for (let i = 0; i < w; i++) {
        const s = this.tiles.take(mc.lava);
        s.position.set(this.sx(o.x + i), this.sy(o.y + 0.6));
        s.width = u + 0.5;
        s.height = u * 0.6 + 0.5;
        s.tint = tint;
      }
      return;
    }
    const left = this.sx(o.x);
    const top = this.sy(o.y + 0.45);
    f.rect(left, top, w * u, 0.45 * u).fill({ color: 0xff6a00 });
    f.rect(left, top, w * u, 0.12 * u).fill({ color: 0xffd23f, alpha: 0.6 + glow * 0.4 });
  }

  /** Тайл блока: у травы верхний ряд — дёрн, в камне иногда попадается руда */
  private tileTexture(o: LevelObject, i: number, j: number, h: number): Texture {
    const mc = this.mc!;
    const tex = o.tex ?? 'stone';
    if (tex === 'grass') return j === h - 1 ? mc.grassTop : mc.dirt;
    if (tex === 'stone') {
      const hash = Math.abs(Math.sin((o.x + i) * 12.9898 + (o.y + j) * 78.233) * 43758.5453) % 1;
      if (hash > 0.97) return mc.oreDiamond;
      if (hash > 0.92) return mc.oreIron;
      if (hash > 0.84) return mc.oreCoal;
    }
    return mc[tex];
  }

  private drawMinecraftBlock(l: Graphics, o: LevelObject, tint: number): void {
    const u = this.u;
    const w = o.w ?? 1;
    const h = o.h ?? 1;
    for (let i = 0; i < w; i++) {
      for (let j = 0; j < h; j++) {
        const s = this.tiles.take(this.tileTexture(o, i, j, h));
        s.position.set(this.sx(o.x + i), this.sy(o.y + j + 1));
        s.width = u + 0.5;
        s.height = u + 0.5;
        s.tint = tint;
      }
    }
    const lw = Math.max(2, u * 0.05);
    l.rect(this.sx(o.x) + lw / 2, this.sy(o.y + h) + lw / 2, w * u - lw, h * u - lw).stroke({ width: lw, color: 0x000000, alpha: 0.55 });
  }

  private drawMinecraftSpike(o: LevelObject, tint: number): void {
    const s = this.tiles.take(this.mc!.spike);
    s.anchor.set(0.5);
    s.position.set(this.sx(o.x + 0.5), this.sy(o.y + 0.5));
    const scale = o.type === 'small-spike' ? 0.5 : 1;
    s.width = this.u;
    s.height = this.u * scale;
    if (scale < 1) s.position.y += (this.u * (1 - scale)) / 2;
    s.rotation = ((o.rot ?? 0) * Math.PI) / 180;
    s.tint = tint;
  }

  private drawDynamic(x0: number, x1: number, gy: number, pulse: number): void {
    const g = this.dyn.clear();
    const u = this.u;
    const edge = Math.max(2, u * 0.05);

    for (const p of this.portals) {
      if (p.x > x1 || p.x + 1 < x0) continue;
      const h = p.h ?? 3;
      const color = PORTAL_COLORS[p.type] ?? 0xffffff;
      const cx = this.sx(p.x + 0.5);
      const cy = this.sy(p.y + h / 2);
      const rx = u * 0.42;
      const ry = (h * u) / 2;
      g.ellipse(cx, cy, rx * 1.7, ry * 1.04).fill({ color, alpha: 0.12 + pulse * 0.18 });
      g.ellipse(cx, cy, rx, ry).stroke({ width: u * 0.2, color: 0x000000 });
      g.ellipse(cx, cy, rx, ry).stroke({ width: u * 0.12, color });
      g.ellipse(cx, cy, rx * 0.55, ry * 0.86).stroke({ width: Math.max(1, u * 0.04), color: 0xffffff, alpha: 0.65 });
    }

    for (const p of this.pads) {
      if (p.x > x1 || p.x + 1 < x0) continue;
      const base = this.sy(p.y);
      g.ellipse(this.sx(p.x + 0.5), base - u * 0.25, u * 0.45, u * (0.2 + pulse * 0.06)).fill({
        color: 0xfff27a,
        alpha: 0.15 + pulse * 0.25,
      });
      g.poly([
        this.sx(p.x + 0.06), base,
        this.sx(p.x + 0.94), base,
        this.sx(p.x + 0.8), base - u * 0.22,
        this.sx(p.x + 0.2), base - u * 0.22,
      ])
        .fill(0xffd21f)
        .stroke({ width: edge, color: 0x000000 });
    }

    for (const o of this.orbs) {
      if (o.x > x1 || o.x + 1 < x0) continue;
      const ox = this.sx(o.x + 0.5);
      const oy = this.sy(o.y + 0.5);
      const used = this.usedOrbs.has(o);
      if (!used) g.circle(ox, oy, u * (0.56 + pulse * 0.08)).stroke({ width: edge, color: 0xffe14a, alpha: 0.65 });
      g.circle(ox, oy, u * 0.34 * (1 + pulse * 0.15))
        .fill(used ? 0x9c8a3a : 0xffe14a)
        .stroke({ width: Math.max(2, u * 0.06), color: 0x000000 });
      g.circle(ox - u * 0.1, oy - u * 0.1, u * 0.09).fill({ color: 0xffffff, alpha: 0.65 });
    }

    for (const c of this.checkpoints) {
      if (c.x > x1 || c.x + 1 < x0) continue;
      const cx = this.sx(c.x + 0.5);
      const cy = this.sy(c.y + 0.5);
      const r = u * 0.32;
      g.poly([cx, cy - r, cx + r * 0.75, cy, cx, cy + r, cx - r * 0.75, cy])
        .fill(0x5dff7a)
        .stroke({ width: edge, color: 0x000000 });
    }

    // Финиш — стена света
    const L = this.level.length;
    if (L < x1 + 1) {
      const gx = this.sx(L);
      for (let i = 8; i >= 1; i--) {
        g.rect(gx - i * u * 0.3, 0, u * 0.3, gy).fill({ color: 0xffffff, alpha: 0.5 * (1 - i / 9) });
      }
      g.rect(gx, 0, Math.max(0, this.W - gx + 20), gy).fill({ color: 0xffffff, alpha: 0.92 });
    }
  }

  // ---- Шлейф волны -----------------------------------------------------------

  private updateWaveTrail(sim: Simulation, px: number, py: number): void {
    const g = this.waveTrail.clear();
    if (sim.mode !== 'wave' || sim.complete) {
      if (sim.mode !== 'wave') this.wavePoints = [];
      return;
    }
    if (!sim.dead) {
      this.wavePoints.push([px + 0.5, py + 0.5]);
      if (this.wavePoints.length > WAVE_TRAIL_POINTS) this.wavePoints.shift();
    }
    if (this.wavePoints.length < 2) return;
    const pts: number[] = [];
    for (const [wx, wy] of this.wavePoints) pts.push(this.sx(wx), this.sy(wy));
    const u = this.u;
    const path = () => {
      g.moveTo(pts[0], pts[1]);
      for (let i = 2; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]);
    };
    path();
    g.stroke({ width: u * 0.28, color: this.primary, alpha: 0.35, join: 'round', cap: 'round' });
    path();
    g.stroke({ width: u * 0.12, color: this.primary, join: 'round', cap: 'round' });
    path();
    g.stroke({ width: u * 0.04, color: 0xffffff, alpha: 0.9, join: 'round', cap: 'round' });
  }

  // ---- Частицы (в мировых координатах) ---------------------------------------

  private emitTrail(dt: number, sim: Simulation, px: number, py: number): void {
    if (this.particleMul === 0) return;
    const e = this.effect;
    if (e) {
      // эффект особого скина — во всех режимах
      this.trailAcc += dt * e.rate * this.particleMul;
      while (this.trailAcc >= 1) {
        this.trailAcc -= 1;
        const a = Math.random() * Math.PI * 2;
        const life = rand(e.life[0], e.life[1]);
        this.particles.push({
          x: px + rand(0.1, 0.5),
          y: py + rand(0.1, 0.9),
          vx: SPEED * 0.6 + Math.cos(a) * e.speed,
          vy: Math.sin(a) * e.speed + e.rise,
          life,
          max: life,
          size: rand(e.size[0], e.size[1]),
          color: e.colors[Math.floor(Math.random() * e.colors.length)],
          shape: e.shape,
          additive: e.additive,
          gravity: e.gravity,
          rot: Math.random() * Math.PI,
          spin: rand(-4, 4),
        });
      }
      return;
    }
    // обычный скин: пыль из-под куба/шара и выхлоп корабля/НЛО
    const exhaust = sim.mode === 'ship' || sim.mode === 'ufo';
    if (!exhaust && !sim.grounded) return;
    this.trailAcc += dt * 40 * this.particleMul;
    while (this.trailAcc >= 1) {
      this.trailAcc -= 1;
      const life = rand(0.25, 0.45);
      const floorY = sim.grav === 1 ? py + 0.05 : py + 0.95;
      this.particles.push({
        x: px + (exhaust ? -0.1 : 0.05 + Math.random() * 0.1),
        y: exhaust ? py + 0.4 + rand(-0.1, 0.1) : floorY,
        vx: SPEED * (exhaust ? 0.3 : 0.55) + Math.random() * 1.5,
        vy: exhaust ? rand(-0.8, 0.8) : (1 + Math.random() * 2.5) * sim.grav,
        life,
        max: life,
        size: rand(0.08, 0.16),
        color: exhaust ? (Math.random() > 0.5 ? 0xffb31a : this.primary) : this.primary,
        shape: 'square',
        additive: false,
        gravity: exhaust ? 0 : 9 * sim.grav,
        rot: 0,
        spin: 0,
      });
    }
  }

  private burst(x: number, y: number, count: number, speed: number, color: number, size: number): void {
    const n = Math.round(count * this.particleMul);
    for (let i = 0; i < n; i++) {
      const a = Math.PI * (0.15 + Math.random() * 0.7);
      const v = speed * (0.5 + Math.random() * 0.6);
      const life = 0.3 + Math.random() * 0.25;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * v + SPEED * 0.5,
        vy: Math.sin(a) * v,
        life,
        max: life,
        size: size * (0.6 + Math.random() * 0.6),
        color,
        shape: 'square',
        additive: false,
        gravity: 10,
        rot: 0,
        spin: 0,
      });
    }
  }

  private ring(x: number, y: number, size: number, color: number): void {
    this.particles.push({ x, y, vx: 0, vy: 0, life: 0.4, max: 0.4, size, color, shape: 'ring', additive: false, gravity: 0, rot: 0, spin: 0 });
  }

  /** Взрыв иконки: осколки и волны (у особых скинов — в их цветах и масштабе) */
  private explode(x: number, y: number): void {
    const scale = this.effect?.deathScale ?? 1;
    const colors = this.effect?.deathColors ?? [this.primary, this.secondary, 0xffffff];
    this.ring(x, y, 3 * scale, 0xffffff);
    this.ring(x, y, 2 * scale, colors[0]);
    const n = Math.max(8, Math.round(24 * scale * this.particleMul));
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const v = (3 + Math.random() * 7) * Math.sqrt(scale);
      const life = 0.5 + Math.random() * 0.4;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * v,
        vy: Math.sin(a) * v + 2,
        life,
        max: life,
        size: 0.15 + Math.random() * 0.2,
        color: colors[i % colors.length],
        shape: this.effect && this.effect.shape !== 'spark' ? this.effect.shape : 'square',
        additive: false,
        gravity: 12,
        rot: Math.random() * Math.PI,
        spin: rand(-6, 6),
      });
    }
  }

  private updateParticles(dt: number): void {
    for (const p of this.particles) {
      p.life -= dt;
      p.vy -= p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.spin * dt;
    }
    this.particles = this.particles.filter((p) => p.life > 0);

    const normal = this.fx.clear();
    const add = this.fxAdd.clear();
    const u = this.u;
    for (const p of this.particles) {
      const g = p.additive ? add : normal;
      const k = p.life / p.max;
      const sx = this.sx(p.x);
      const sy = this.sy(p.y);
      if (p.shape === 'ring') {
        g.circle(sx, sy, Math.max(1, (1 - k) * p.size * u)).stroke({ width: Math.max(1, 0.14 * u * k), color: p.color, alpha: k });
        continue;
      }
      const smoke = p.shape === 'smoke';
      const s = p.size * u * (smoke ? 1.6 - 0.6 * k : 0.4 + 0.6 * k);
      const alpha = smoke ? k * 0.55 : k;
      this.drawShape(g, p, sx, sy, s, alpha);
    }
  }

  private drawShape(g: Graphics, p: Particle, sx: number, sy: number, s: number, alpha: number): void {
    const style = { color: p.color, alpha };
    switch (p.shape) {
      case 'circle':
      case 'ember':
      case 'smoke':
        g.circle(sx, sy, s / 2).fill(style);
        break;
      case 'star': {
        const pts: number[] = [];
        for (let i = 0; i < 8; i++) {
          const r = i % 2 === 0 ? s / 2 : s / 7;
          const a = p.rot + (i * Math.PI) / 4;
          pts.push(sx + Math.cos(a) * r, sy + Math.sin(a) * r);
        }
        g.poly(pts).fill(style);
        break;
      }
      case 'spark': {
        const len = Math.hypot(p.vx, p.vy) || 1;
        g.moveTo(sx, sy)
          .lineTo(sx - (p.vx / len) * s, sy + (p.vy / len) * s)
          .stroke({ width: Math.max(1, s / 6), color: p.color, alpha, cap: 'round' });
        break;
      }
      case 'flake':
        for (let i = 0; i < 3; i++) {
          const a = p.rot + (i * Math.PI) / 3;
          g.moveTo(sx + (Math.cos(a) * s) / 2, sy + (Math.sin(a) * s) / 2).lineTo(sx - (Math.cos(a) * s) / 2, sy - (Math.sin(a) * s) / 2);
        }
        g.stroke({ width: Math.max(1, s / 7), color: p.color, alpha, cap: 'round' });
        break;
      case 'sprinkle':
        g.poly(rotatedRect(sx, sy, s, s / 3, p.rot)).fill(style);
        break;
      default:
        g.poly(rotatedRect(sx, sy, s, s, p.rot)).fill(style);
    }
  }
}

function rotatedRect(cx: number, cy: number, w: number, h: number, rot: number): number[] {
  const cos = Math.cos(rot);
  const sin = Math.sin(rot);
  const pts: number[] = [];
  for (const [dx, dy] of [[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]]) {
    pts.push(cx + dx * cos - dy * sin, cy + dx * sin + dy * cos);
  }
  return pts;
}
