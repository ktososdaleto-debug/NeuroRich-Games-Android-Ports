import type { Application, Ticker } from 'pixi.js';
import type { LevelData } from './types';
import type { LevelMeta } from '../data/levels';
import type { Song } from '../audio/types';
import { Simulation, type Checkpoint } from './Simulation';
import { GameRenderer } from './GameRenderer';
import { DT } from './physics';
import { audio, SONG_LEAD_IN } from '../core/AudioManager';
import { settings } from '../state/settings';
import { profile, recordAttemptStart, recordCompletion, recordJumps, recordRun } from '../state/profile';

const DEATH_DELAY = 1.0;
const COMPLETE_DELAY = 1.4;
/** Не больше секунды симуляции за кадр — защита от «заморозки» после лагов */
const MAX_STEPS = 240;
/** Автоматический чекпоинт в практике — примерно раз в 2 такта */
const AUTO_CHECKPOINT_DISTANCE = 32;

export interface CompleteInfo {
  practice: boolean;
  attempts: number;
  jumps: number;
  time: number;
  stars: number;
  firstClear: boolean;
}

export interface SessionHooks {
  onAttempt(attempt: number): void;
  onProgress(percent: number): void;
  onDeath(info: { percent: number; newBest: boolean; practice: boolean }): void;
  /** Смерть при выключенном «Быстром рестарте» — показать меню */
  onDeathMenu(): void;
  onComplete(info: CompleteInfo): void;
  onCheckpoints(count: number): void;
}

type State = 'playing' | 'dead' | 'complete';

/**
 * Одна сессия игры на уровне. Часы — время песни (audio.songTime()):
 * симуляция догоняет его фиксированными шагами, поэтому физика всегда в такт музыке.
 */
export class GameSession {
  private readonly sim: Simulation;
  private readonly renderer: GameRenderer;
  private state: State = 'playing';
  private _paused = false;
  private _practice = false;
  private checkpoints: Checkpoint[] = [];
  private inputDown = false;
  private timer = 0;
  private notified = false;
  private perfOrigin = 0;
  private attemptStart = 0;
  private lastCheckpointX = 0;
  private lastPercent = -1;
  private completeInfo: CompleteInfo | null = null;
  private readonly tick = (ticker: Ticker) => this.frame(Math.min(ticker.deltaMS / 1000, 0.1));

  constructor(
    private readonly app: Application,
    level: LevelData,
    private readonly meta: LevelMeta,
    private readonly song: Song,
    private readonly hooks: SessionHooks,
  ) {
    this.sim = new Simulation(level);
    this.renderer = new GameRenderer(app, level, profile.get().skin, settings.get().particles);
  }

  get paused(): boolean {
    return this._paused;
  }

  get practice(): boolean {
    return this._practice;
  }

  get isComplete(): boolean {
    return this.state === 'complete';
  }

  start(): void {
    this.app.ticker.add(this.tick);
    this.newAttempt();
  }

  destroy(): void {
    this.app.ticker.remove(this.tick);
    recordJumps(this.meta.id, this.flushJumps());
    this.renderer.destroy();
    audio.stopSong(0.1);
  }

  // ---- Управление -----------------------------------------------------------

  /** stamp — event.timeStamp: нажатие применяется точно в момент события, а не кадра */
  setInput(down: boolean, stamp: number): void {
    if (down === this.inputDown) return;
    this.inputDown = down;
    if (this._paused || this.state !== 'playing') return;
    const lag = Math.max(0, (performance.now() - stamp) / 1000);
    this.sim.pushInput(down, this.now() - lag);
  }

  pause(): void {
    if (this._paused || this.state === 'complete') return;
    this._paused = true;
    if (this.state === 'playing') audio.stopSong(0.08);
  }

  resume(): void {
    if (!this._paused) return;
    this._paused = false;
    if (this.state === 'playing') this.startClock(this.sim.time);
  }

  /** R / «Заново» после смерти: с последнего чекпоинта в практике, иначе с начала */
  respawn(): void {
    this._paused = false;
    this.newAttempt();
  }

  /** С самого начала, чекпоинты удаляются */
  restart(): void {
    this.checkpoints = [];
    this.renderer.clearCheckpoints();
    this.hooks.onCheckpoints(0);
    this._paused = false;
    this.newAttempt();
  }

  setPractice(on: boolean): void {
    this._practice = on;
    this.restart();
  }

  placeCheckpoint(auto = false): void {
    if (!this._practice || this.state !== 'playing' || this._paused) return;
    if (auto && !this.sim.clearAhead(4)) return;
    this.checkpoints.push(this.sim.snapshot());
    this.lastCheckpointX = this.sim.x;
    this.renderer.addCheckpoint(this.sim.x, this.sim.y);
    if (!auto) audio.sfx('checkpoint');
    this.hooks.onCheckpoints(this.checkpoints.length);
  }

  removeCheckpoint(): void {
    if (!this._practice || !this.checkpoints.length) return;
    this.checkpoints.pop();
    this.renderer.removeCheckpoint();
    audio.sfx('back');
    this.hooks.onCheckpoints(this.checkpoints.length);
  }

  // ---- Внутреннее -----------------------------------------------------------

  private newAttempt(): void {
    const cp = this._practice ? this.checkpoints[this.checkpoints.length - 1] : undefined;
    this.sim.reset(cp);
    this.state = 'playing';
    this.notified = false;
    this.completeInfo = null;
    this.attemptStart = this.sim.time;
    this.lastCheckpointX = this.sim.x;
    const attempts = recordAttemptStart(this.meta.id, this.flushJumps());
    this.renderer.reset(this.sim, attempts, settings.get().showAttempts && !cp);
    this.startClock(this.sim.time);
    // кнопка всё ещё зажата — сразу прыгаем, как в оригинале
    if (this.inputDown) this.sim.pushInput(true, this.sim.time);
    this.hooks.onAttempt(attempts);
  }

  private startClock(from: number): void {
    this.perfOrigin = performance.now() / 1000 + SONG_LEAD_IN - from;
    audio.playSong(this.song, from);
  }

  private now(): number {
    return audio.isPlaying(this.song.id) ? audio.songTime() : performance.now() / 1000 - this.perfOrigin;
  }

  private flushJumps(): number {
    const j = this.sim.jumps;
    this.sim.jumps = 0;
    return j;
  }

  private frame(dt: number): void {
    if (!this._paused) {
      if (this.state === 'playing') this.advance();
      else this.timer -= dt;

      if (this.state === 'dead' && this.timer <= 0 && !this.notified) {
        if (this._practice || settings.get().autoRetry) this.newAttempt();
        else {
          this.notified = true;
          this.hooks.onDeathMenu();
        }
      } else if (this.state === 'complete' && this.timer <= 0 && !this.notified && this.completeInfo) {
        this.notified = true;
        this.hooks.onComplete(this.completeInfo);
      }
    }

    const percent = this.sim.progress * 100;
    if (Math.abs(percent - this.lastPercent) >= 0.05) {
      this.lastPercent = percent;
      this.hooks.onProgress(percent);
    }

    const t = this.state === 'dead' || this._paused ? this.sim.time : this.now();
    const beat = (t * this.song.bpm) / 60;
    this.renderer.render(this.sim, this._paused ? 0 : dt, beat, this.song.intensity(beat));
  }

  private advance(): void {
    const target = this.now();
    let n = 0;
    while (this.sim.time + DT <= target && n < MAX_STEPS) {
      this.sim.step();
      n++;
      if (this.sim.events.length) this.flushEvents();
      if (this.state !== 'playing') return;
    }
    const steady = this.sim.grounded || this.sim.mode !== 'cube';
    if (this._practice && steady && this.sim.x - this.lastCheckpointX >= AUTO_CHECKPOINT_DISTANCE) {
      this.placeCheckpoint(true);
    }
  }

  private flushEvents(): void {
    for (const e of this.sim.events) {
      this.renderer.onEvent(e);
      if (e.type === 'death') this.onDeath();
      else if (e.type === 'complete') this.onComplete();
    }
    this.sim.events.length = 0;
  }

  private onDeath(): void {
    this.state = 'dead';
    this.timer = DEATH_DELAY;
    this.notified = false;
    audio.stopSong(0.04);
    audio.sfx('death');
    const percent = Math.floor(this.sim.progress * 100);
    const { newBest } = recordRun(this.meta.id, { practice: this._practice, percent, jumps: this.flushJumps() });
    this.hooks.onDeath({ percent, newBest, practice: this._practice });
  }

  private onComplete(): void {
    this.state = 'complete';
    this.timer = COMPLETE_DELAY;
    this.notified = false;
    audio.sfx('complete');
    const res = recordCompletion(this.meta.id, { practice: this._practice, jumps: this.flushJumps() });
    this.completeInfo = {
      practice: this._practice,
      attempts: res.progress.attempts,
      jumps: res.progress.jumps,
      time: this.sim.time - this.attemptStart,
      stars: res.firstClear ? this.meta.stars : 0,
      firstClear: res.firstClear,
    };
  }
}
