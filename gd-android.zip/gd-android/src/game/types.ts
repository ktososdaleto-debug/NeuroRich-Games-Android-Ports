/**
 * Формат уровня. Это контракт между построителем уровней, движком и будущим редактором:
 * редактор будет сохранять ровно такой JSON.
 *
 * Координаты — в клетках (1 клетка = размер куба). x растёт вправо, y — вверх от земли.
 * (x, y) — левый нижний угол объекта.
 */

export type GameMode = 'cube' | 'ship' | 'ball' | 'ufo' | 'wave';

export type ObjectType =
  | 'block'
  | 'spike'
  | 'small-spike'
  | 'lava'
  | 'pad-yellow'
  | 'orb-yellow'
  | 'portal-cube'
  | 'portal-ship'
  | 'portal-ball'
  | 'portal-ufo'
  | 'portal-wave'
  | 'portal-gravity-up'
  | 'portal-gravity-down'
  | 'trigger-color'
  | 'trigger-flash'
  | 'trigger-zone';

export type ColorChannel = 'bg' | 'ground' | 'line' | 'obj';

/** Оформление уровня: классический неон или блоки в стиле Minecraft */
export type LevelTheme = 'classic' | 'minecraft';

/** Текстуры блоков темы minecraft */
export type BlockTexture =
  | 'grass'
  | 'dirt'
  | 'stone'
  | 'cobble'
  | 'planks'
  | 'log'
  | 'leaves'
  | 'netherrack'
  | 'obsidian'
  | 'endstone';

/** Зона темы minecraft: определяет землю, потолок и фон */
export type Zone = 'surface' | 'cave' | 'nether' | 'end';

export interface LevelObject {
  type: ObjectType;
  x: number;
  y: number;
  /** Ширина/высота (блоки, лава, порталы), по умолчанию 1 (у порталов высота 3) */
  w?: number;
  h?: number;
  /** Поворот по часовой стрелке, градусы */
  rot?: 0 | 90 | 180 | 270;
  /** trigger-color: какой канал и в какой цвет перекрасить */
  channel?: ColorChannel;
  color?: string;
  /** trigger-color: длительность перехода в клетках (≈ время × скорость) */
  duration?: number;
  /** block: текстура (тема minecraft) */
  tex?: BlockTexture;
  /** trigger-zone */
  zone?: Zone;
}

export interface LevelData {
  version: 1;
  id: string;
  songId: string;
  theme?: LevelTheme;
  /** x финиша */
  length: number;
  /** Стартовые цвета; obj — оттенок блоков (по умолчанию белый) */
  colors: { bg: string; ground: string; line: string; obj?: string };
  objects: LevelObject[];
  /** Эталонное прохождение: моменты нажатий в секундах (используется автопроверкой) */
  solution?: number[];
}
