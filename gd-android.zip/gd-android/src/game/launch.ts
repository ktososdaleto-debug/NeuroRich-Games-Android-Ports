import type { LevelMeta } from '../data/levels';
import type { LevelData } from './types';

/** Какой уровень открыть на экране игры: официальный или из редактора */
export interface LaunchInfo {
  meta: LevelMeta;
  level: LevelData;
  /** Уровень из редактора: без звёзд, после выхода — обратно в редактор */
  custom: boolean;
}

let current: LaunchInfo | null = null;

export function setLaunch(info: LaunchInfo): void {
  current = info;
}

export function getLaunch(): LaunchInfo | null {
  return current;
}
