import { hexToRgb, lerpRgb, type RGB } from '../core/color';
import type { ColorChannel, LevelData } from './types';

interface ColorStep {
  x: number;
  duration: number;
  color: RGB;
}

const FLASH_LENGTH = 8;

/**
 * Цвета уровня как чистая функция от позиции игрока.
 * Никакого состояния — поэтому рестарт и чекпоинты сразу дают правильный цвет.
 */
export class ColorTrack {
  private readonly base: Record<ColorChannel, RGB>;
  private readonly steps: Record<ColorChannel, ColorStep[]> = { bg: [], ground: [], line: [], obj: [] };
  private readonly flashes: number[] = [];

  constructor(level: LevelData) {
    this.base = {
      bg: hexToRgb(level.colors.bg),
      ground: hexToRgb(level.colors.ground),
      line: hexToRgb(level.colors.line),
      obj: hexToRgb(level.colors.obj ?? '#ffffff'),
    };
    for (const o of level.objects) {
      if (o.type === 'trigger-color' && o.channel && o.color) {
        this.steps[o.channel].push({ x: o.x, duration: o.duration ?? 0, color: hexToRgb(o.color) });
      } else if (o.type === 'trigger-flash') {
        this.flashes.push(o.x);
      }
    }
    for (const list of Object.values(this.steps)) list.sort((a, b) => a.x - b.x);
  }

  at(channel: ColorChannel, x: number): RGB {
    let c = this.base[channel];
    for (const s of this.steps[channel]) {
      if (x < s.x) break;
      const k = Math.min(1, (x - s.x) / Math.max(s.duration, 1e-3));
      c = lerpRgb(c, s.color, k);
    }
    return c;
  }

  /** Яркость белой вспышки 0..1 */
  flashAt(x: number): number {
    let a = 0;
    for (const f of this.flashes) {
      const d = x - f;
      if (d >= 0 && d < FLASH_LENGTH) a = Math.max(a, 1 - d / FLASH_LENGTH);
    }
    return a;
  }
}
