import { BUILDERS } from '../levels/registry';
import { solveLevel } from './solver';

/** Фоновая проверка проходимости уровня (только в режиме разработки) */
const scope = self as unknown as Worker;

scope.onmessage = (e: MessageEvent<{ id: string }>) => {
  const build = BUILDERS[e.data.id];
  if (!build) return;
  const result = solveLevel(build(), 30000);
  scope.postMessage({ id: e.data.id, ...result });
};
