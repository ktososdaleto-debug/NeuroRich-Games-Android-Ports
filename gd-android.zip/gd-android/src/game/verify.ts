import { Simulation } from './Simulation';
import type { LevelData } from './types';

export interface SolutionResult {
  ok: boolean;
  percent: number;
  time: number;
}

/** Прогоняет эталонное прохождение уровня в симуляции (без графики и звука). */
export function runSolution(level: LevelData): SolutionResult {
  const sim = new Simulation(level);
  sim.reset();
  for (const t of level.solution ?? []) {
    sim.pushInput(true, t);
    sim.pushInput(false, t + 0.05);
  }
  while (!sim.dead && !sim.complete && sim.time < 600) {
    sim.step();
    sim.events.length = 0;
  }
  return { ok: sim.complete, percent: Math.floor(sim.progress * 100), time: sim.time };
}
