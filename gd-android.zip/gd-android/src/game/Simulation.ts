import type { GameMode, LevelData, LevelObject, ObjectType } from './types';
import { cellToWorld } from './geometry';
import {
  BALL_GRAVITY,
  BALL_KICK,
  CORRIDOR_TOP,
  DT,
  GRAVITY,
  JUMP_VELOCITY,
  LAND_SNAP,
  MAX_FALL,
  ORB_BOOST,
  PAD_BOOST,
  PRESS_BUFFER,
  ROTATION_SPEED,
  SHIP_DOWN,
  SHIP_MAX,
  SHIP_UP,
  SPEED,
  UFO_GRAVITY,
  UFO_JUMP,
  UFO_MAX_FALL,
  WAVE_SPEED,
} from './physics';

export interface Box {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

interface Collider extends Box {
  stamp: number;
  used: boolean;
  /** Для порталов — что делает портал */
  kind?: ObjectType;
}

export type SimEventType = 'jump' | 'land' | 'orb' | 'pad' | 'portal' | 'death' | 'complete';

export interface SimEvent {
  type: SimEventType;
  /** Позиция игрока (левый нижний угол) в момент события */
  x: number;
  y: number;
}

/** Точка возрождения в практике */
export interface Checkpoint {
  time: number;
  x: number;
  y: number;
  vy: number;
  grounded: boolean;
  rot: number;
  mode: GameMode;
  grav: 1 | -1;
}

/** Полное состояние — для автопроверки уровня (поиск с откатом) */
export interface SimState extends Checkpoint {
  holding: boolean;
  pressPending: boolean;
  pressTime: number;
  dead: boolean;
  complete: boolean;
  jumps: number;
  used: boolean[];
}

const EPS = 1e-4;

function overlaps(a: Box, b: Box): boolean {
  return a.x0 < b.x1 - EPS && a.x1 > b.x0 + EPS && a.y0 < b.y1 - EPS && a.y1 > b.y0 + EPS;
}

function collider(x0: number, y0: number, x1: number, y1: number, kind?: ObjectType): Collider {
  return { x0, y0, x1, y1, stamp: 0, used: false, kind };
}

/** Хитбокс, заданный в локальных координатах клетки и повёрнутый вместе с объектом */
function cellBox(o: LevelObject, lx0: number, ly0: number, lx1: number, ly1: number): Collider {
  const [ax, ay] = cellToWorld(o, lx0, ly0);
  const [bx, by] = cellToWorld(o, lx1, ly1);
  return collider(Math.min(ax, bx), Math.min(ay, by), Math.max(ax, bx), Math.max(ay, by));
}

const PORTAL_MODES: Partial<Record<ObjectType, GameMode>> = {
  'portal-cube': 'cube',
  'portal-ship': 'ship',
  'portal-ball': 'ball',
  'portal-ufo': 'ufo',
  'portal-wave': 'wave',
};

/** Корзины по целым x — проверяем только объекты рядом с игроком */
class SpatialIndex {
  private readonly cells = new Map<number, Collider[]>();
  private readonly buffer: Collider[] = [];
  private stamp = 0;

  constructor(readonly items: Collider[]) {
    for (const c of items) {
      for (let k = Math.floor(c.x0); k <= Math.floor(c.x1); k++) {
        let list = this.cells.get(k);
        if (!list) {
          list = [];
          this.cells.set(k, list);
        }
        list.push(c);
      }
    }
  }

  near(x0: number, x1: number): readonly Collider[] {
    const out = this.buffer;
    out.length = 0;
    const s = ++this.stamp;
    for (let k = Math.floor(x0); k <= Math.floor(x1); k++) {
      const list = this.cells.get(k);
      if (!list) continue;
      for (const c of list) {
        if (c.stamp === s) continue;
        c.stamp = s;
        out.push(c);
      }
    }
    return out;
  }
}

/**
 * Физика уровня: чистая логика без графики и звука, шаг фиксирован (DT).
 * Одинаковые входные данные всегда дают одинаковый результат — это позволяет
 * автоматически проверять проходимость уровня (см. verify.ts и solver.ts).
 */
export class Simulation {
  time = 0;
  /** Левый нижний угол хитбокса 1×1 */
  x = 0;
  y = 0;
  vy = 0;
  grounded = true;
  /** Поворот иконки по часовой стрелке, радианы (только для отрисовки) */
  rot = 0;
  mode: GameMode = 'cube';
  /** 1 — гравитация вниз, −1 — вверх */
  grav: 1 | -1 = 1;
  dead = false;
  complete = false;
  jumps = 0;
  readonly events: SimEvent[] = [];
  readonly length: number;

  private holding = false;
  private pressPending = false;
  private pressTime = -1;
  private queue: Array<{ time: number; down: boolean }> = [];

  private readonly solids: SpatialIndex;
  private readonly hazards: SpatialIndex;
  private readonly pads: SpatialIndex;
  private readonly orbs: SpatialIndex;
  private readonly portals: SpatialIndex;
  /** Всё, что срабатывает один раз (батуты, орбы, порталы) — для сохранения состояния */
  private readonly triggers: Collider[];

  constructor(level: LevelData) {
    this.length = level.length;
    const solids: Collider[] = [];
    const hazards: Collider[] = [];
    const pads: Collider[] = [];
    const orbs: Collider[] = [];
    const portals: Collider[] = [];
    for (const o of level.objects) {
      switch (o.type) {
        case 'block':
          solids.push(collider(o.x, o.y, o.x + (o.w ?? 1), o.y + (o.h ?? 1)));
          break;
        case 'spike':
          hazards.push(cellBox(o, 0.38, 0, 0.62, 0.55));
          break;
        case 'small-spike':
          hazards.push(cellBox(o, 0.38, 0, 0.62, 0.3));
          break;
        case 'lava':
          hazards.push(collider(o.x, o.y, o.x + (o.w ?? 1), o.y + 0.45));
          break;
        case 'pad-yellow':
          pads.push(cellBox(o, 0.1, 0, 0.9, 0.3));
          break;
        case 'orb-yellow':
          orbs.push(collider(o.x - 0.1, o.y - 0.1, o.x + 1.1, o.y + 1.1));
          break;
        default:
          if (o.type.startsWith('portal-')) {
            portals.push(collider(o.x + 0.15, o.y, o.x + 0.85, o.y + (o.h ?? 3), o.type));
          }
      }
    }
    this.solids = new SpatialIndex(solids);
    this.hazards = new SpatialIndex(hazards);
    this.pads = new SpatialIndex(pads);
    this.orbs = new SpatialIndex(orbs);
    this.portals = new SpatialIndex(portals);
    this.triggers = [...pads, ...orbs, ...portals];
  }

  get progress(): number {
    return Math.min(1, Math.max(0, this.x / this.length));
  }

  /** Есть ли потолок коридора */
  get corridor(): boolean {
    return this.mode !== 'cube';
  }

  reset(cp?: Checkpoint): void {
    const s = cp ?? { time: 0, x: 0, y: 0, vy: 0, grounded: true, rot: 0, mode: 'cube' as GameMode, grav: 1 as const };
    this.time = s.time;
    this.x = s.x;
    this.y = s.y;
    this.vy = s.vy;
    this.grounded = s.grounded;
    this.rot = s.rot;
    this.mode = s.mode;
    this.grav = s.grav;
    this.dead = false;
    this.complete = false;
    this.jumps = 0;
    this.events.length = 0;
    this.queue = [];
    this.holding = false;
    this.pressPending = false;
    // всё, что уже позади (или под игроком), считаем использованным
    for (const c of this.triggers) c.used = c.x0 < s.x + 1;
  }

  snapshot(): Checkpoint {
    return {
      time: this.time,
      x: this.x,
      y: this.y,
      vy: this.vy,
      grounded: this.grounded,
      rot: this.rot,
      mode: this.mode,
      grav: this.grav,
    };
  }

  saveState(): SimState {
    return {
      ...this.snapshot(),
      holding: this.holding,
      pressPending: this.pressPending,
      pressTime: this.pressTime,
      dead: this.dead,
      complete: this.complete,
      jumps: this.jumps,
      used: this.triggers.map((c) => c.used),
    };
  }

  loadState(s: SimState): void {
    this.time = s.time;
    this.x = s.x;
    this.y = s.y;
    this.vy = s.vy;
    this.grounded = s.grounded;
    this.rot = s.rot;
    this.mode = s.mode;
    this.grav = s.grav;
    this.holding = s.holding;
    this.pressPending = s.pressPending;
    this.pressTime = s.pressTime;
    this.dead = s.dead;
    this.complete = s.complete;
    this.jumps = s.jumps;
    this.queue = [];
    this.events.length = 0;
    s.used.forEach((u, i) => (this.triggers[i].used = u));
  }

  /** Нажатие/отпускание в момент time (секунды песни) */
  pushInput(down: boolean, time: number): void {
    this.queue.push({ down, time: Math.max(time, this.time) });
  }

  /** Нет ли препятствий прямо перед игроком — для автоматических чекпоинтов */
  clearAhead(distance: number): boolean {
    const x0 = this.x;
    const x1 = this.x + 1 + distance;
    for (const index of [this.hazards, this.pads, this.orbs, this.portals]) {
      for (const c of index.near(x0, x1)) if (c.x1 > x0 && c.x0 < x1) return false;
    }
    for (const s of this.solids.near(x0, x1)) {
      if (s.x1 > x0 && s.x0 < x1 && s.y1 > this.y + 0.01 && s.y0 < this.y + 1) return false;
    }
    return true;
  }

  step(): void {
    if (this.dead || this.complete) return;
    const t = this.time + DT;

    while (this.queue.length && this.queue[0].time <= t) {
      const ev = this.queue.shift()!;
      if (ev.down) {
        if (!this.holding) {
          this.holding = true;
          this.pressPending = true;
          this.pressTime = ev.time;
        }
      } else {
        this.holding = false;
      }
    }
    const pressValid = this.pressPending && (this.holding || t - this.pressTime <= PRESS_BUFFER);

    // ---- Действия режима до движения
    if (this.mode === 'cube' && this.grounded && this.holding) {
      this.jump(JUMP_VELOCITY * this.grav, 'jump');
    } else if (this.mode === 'ball' && this.grounded && pressValid) {
      // смена гравитации с небольшим толчком к новому «полу»
      this.grav = this.grav === 1 ? -1 : 1;
      this.jump(-BALL_KICK * this.grav, 'jump');
    }

    // ---- Движение
    const prevY = this.y;
    const wasGrounded = this.grounded;
    const g = this.grav;
    switch (this.mode) {
      case 'cube':
        this.vy = clamp(this.vy - GRAVITY * g * DT, -MAX_FALL, MAX_FALL);
        break;
      case 'ball':
        this.vy = clamp(this.vy - BALL_GRAVITY * g * DT, -MAX_FALL, MAX_FALL);
        break;
      case 'ufo':
        this.vy = clamp(this.vy - UFO_GRAVITY * g * DT, -UFO_MAX_FALL, UFO_MAX_FALL);
        break;
      case 'ship':
        this.vy = clamp(this.vy + (this.holding ? SHIP_UP : -SHIP_DOWN) * g * DT, -SHIP_MAX, SHIP_MAX);
        break;
      case 'wave':
        this.vy = (this.holding ? WAVE_SPEED : -WAVE_SPEED) * g;
        break;
    }
    this.y += this.vy * DT;
    this.x += SPEED * DT;
    this.time = t;
    this.grounded = false;

    // ---- Пол и потолок коридора: по ним можно скользить
    if (this.y <= 0) {
      this.y = 0;
      if (this.vy < 0) this.vy = 0;
      if (g === 1) this.grounded = true;
    }
    if (this.corridor && this.y >= CORRIDOR_TOP - 1) {
      this.y = CORRIDOR_TOP - 1;
      if (this.vy > 0) this.vy = 0;
      if (g === -1) this.grounded = true;
    }

    // ---- Блоки
    const wave = this.mode === 'wave';
    for (const s of this.solids.near(this.x - 1, this.x + 2)) {
      if (!overlaps(this.body(), s)) continue;
      if (wave) return this.die();
      // куб встаёт только на «пол» своей гравитации, остальные режимы скользят по обеим сторонам
      const canTop = this.mode !== 'cube' || g === 1;
      const canBottom = this.mode !== 'cube' || g === -1;
      const fromAbove = prevY >= s.y1 - LAND_SNAP;
      const fromBelow = prevY + 1 <= s.y0 + LAND_SNAP;
      if (fromAbove && this.vy <= 0) {
        if (!canTop) return this.die();
        this.y = s.y1;
        this.vy = 0;
        if (g === 1) this.grounded = true;
      } else if (fromBelow && this.vy >= 0) {
        if (!canBottom) return this.die();
        this.y = s.y0 - 1;
        this.vy = 0;
        if (g === -1) this.grounded = true;
      } else if (!fromAbove && !fromBelow) {
        return this.die();
      }
    }

    if (this.grounded && !wasGrounded && (this.mode === 'cube' || this.mode === 'ball')) this.emit('land');

    // ---- Шипы и лава
    for (const hz of this.hazards.near(this.x - 1, this.x + 2)) {
      if (overlaps(this.hitbox(), hz)) return this.die();
    }

    // ---- Батуты и орбы (не для корабля и волны)
    if (this.mode !== 'ship' && this.mode !== 'wave') {
      for (const p of this.pads.near(this.x - 1, this.x + 2)) {
        if (!p.used && overlaps(this.body(), p)) {
          p.used = true;
          this.jump(JUMP_VELOCITY * PAD_BOOST * this.grav, 'pad');
        }
      }
      if (this.pressPending && pressValid) {
        for (const o of this.orbs.near(this.x - 1, this.x + 2)) {
          if (!o.used && overlaps(this.body(), o)) {
            o.used = true;
            this.jump(JUMP_VELOCITY * ORB_BOOST * this.grav, 'orb');
            break;
          }
        }
      }
    }

    // ---- НЛО: каждое новое нажатие — подскок
    if (this.mode === 'ufo' && this.pressPending && pressValid) {
      this.jump(UFO_JUMP * this.grav, 'jump');
    }
    if (this.pressPending && !this.holding && t - this.pressTime > PRESS_BUFFER) this.pressPending = false;

    // ---- Порталы
    for (const p of this.portals.near(this.x - 1, this.x + 2)) {
      if (p.used || !overlaps(this.body(), p)) continue;
      p.used = true;
      const mode = p.kind ? PORTAL_MODES[p.kind] : undefined;
      if (mode) {
        this.mode = mode;
        this.grav = 1;
      } else if (p.kind === 'portal-gravity-up') this.grav = -1;
      else if (p.kind === 'portal-gravity-down') this.grav = 1;
      this.vy *= 0.5;
      this.grounded = false;
      this.emit('portal');
    }

    this.updateRotation();

    if (this.x >= this.length) {
      this.complete = true;
      this.emit('complete');
    }
  }

  // ---------------------------------------------------------------------------

  private updateRotation(): void {
    const k = Math.min(1, DT * 15);
    switch (this.mode) {
      case 'cube':
        if (this.grounded) {
          const quarter = Math.PI / 2;
          const target = Math.round(this.rot / quarter) * quarter;
          this.rot += (target - this.rot) * Math.min(1, DT * 30);
        } else {
          this.rot += ROTATION_SPEED * DT * this.grav;
        }
        break;
      case 'ball':
        this.rot += (SPEED / 0.5) * DT * this.grav;
        break;
      case 'ship':
        this.rot += (-Math.atan2(this.vy, SPEED * 1.2) - this.rot) * k;
        break;
      case 'ufo':
        this.rot += (-this.vy * 0.02 - this.rot) * k;
        break;
      case 'wave':
        this.rot = -Math.atan2(this.vy, SPEED);
        break;
    }
  }

  /** Хитбокс для блоков */
  private body(): Box {
    if (this.mode === 'wave') return this.waveBox();
    return { x0: this.x, y0: this.y, x1: this.x + 1, y1: this.y + 1 };
  }

  /** Хитбокс для шипов — чуть меньше иконки, так честнее */
  private hitbox(): Box {
    switch (this.mode) {
      case 'cube':
        return { x0: this.x + 0.1, y0: this.y + 0.05, x1: this.x + 0.9, y1: this.y + 0.9 };
      case 'wave':
        return this.waveBox();
      default:
        return { x0: this.x + 0.15, y0: this.y + 0.15, x1: this.x + 0.85, y1: this.y + 0.85 };
    }
  }

  private waveBox(): Box {
    return { x0: this.x + 0.3, y0: this.y + 0.3, x1: this.x + 0.7, y1: this.y + 0.7 };
  }

  private jump(velocity: number, kind: 'jump' | 'orb' | 'pad'): void {
    this.vy = velocity;
    this.grounded = false;
    if (kind !== 'pad') {
      this.jumps++;
      this.pressPending = false;
    }
    this.emit(kind);
  }

  private die(): void {
    this.dead = true;
    this.emit('death');
  }

  private emit(type: SimEventType): void {
    this.events.push({ type, x: this.x, y: this.y });
  }
}

function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v;
}
