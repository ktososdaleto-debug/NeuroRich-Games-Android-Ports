import { Simulation, type SimState } from './Simulation';
import { DT } from './physics';
import type { LevelData } from './types';

export interface SolveResult {
  ok: boolean;
  /** Лучший достигнутый процент */
  percent: number;
  /** Моменты переключения кнопки (секунды), если решение найдено */
  toggles: number[];
  ms: number;
  timedOut: boolean;
}

/** Решение принимается раз в столько шагов физики (4 шага = 1/60 с) */
const STEPS_PER_DECISION = 4;

interface Node {
  state: SimState;
  input: boolean;
  /** Сколько вариантов уже пробовали из этой точки */
  tried: number;
  depth: number;
}

/**
 * Ищет любое прохождение уровня: поиск в глубину с откатом.
 * В каждой точке сначала пробуем «оставить кнопку как есть», потом — переключить.
 * Похожие состояния (та же точка времени, режим, высота, скорость) не исследуются повторно.
 */
export function solveLevel(level: LevelData, budgetMs = 20000): SolveResult {
  const started = performance.now();
  const sim = new Simulation(level);
  sim.reset();
  const visited = new Set<string>();
  const stack: Node[] = [{ state: sim.saveState(), input: false, tried: 0, depth: 0 }];
  let best = 0;
  let iterations = 0;

  while (stack.length) {
    if ((++iterations & 1023) === 0 && performance.now() - started > budgetMs) {
      return { ok: false, percent: Math.floor(best * 100), toggles: [], ms: performance.now() - started, timedOut: true };
    }
    const node = stack[stack.length - 1];
    if (node.tried >= 2) {
      stack.pop();
      continue;
    }
    const input = node.tried === 0 ? node.input : !node.input;
    node.tried++;

    sim.loadState(node.state);
    sim.pushInput(input, sim.time);
    for (let i = 0; i < STEPS_PER_DECISION && !sim.dead && !sim.complete; i++) sim.step();
    sim.events.length = 0;
    best = Math.max(best, sim.progress);
    if (sim.dead) continue;

    if (sim.complete) {
      const toggles: number[] = [];
      let prev = false;
      const path = [...stack.map((n, i) => (i === stack.length - 1 ? input : n.tried === 1 ? n.input : !n.input))];
      // path[i] — кнопка, выбранная в i-й точке решения
      path.forEach((v, i) => {
        if (v !== prev) toggles.push(i * STEPS_PER_DECISION * DT);
        prev = v;
      });
      return { ok: true, percent: 100, toggles, ms: performance.now() - started, timedOut: false };
    }

    const key = `${node.depth + 1}|${sim.mode}|${sim.grav}|${Math.round(sim.y * 20)}|${Math.round(sim.vy * 2)}|${input ? 1 : 0}`;
    if (visited.has(key)) continue;
    visited.add(key);
    stack.push({ state: sim.saveState(), input, tried: 0, depth: node.depth + 1 });
  }
  return { ok: false, percent: Math.floor(best * 100), toggles: [], ms: performance.now() - started, timedOut: false };
}
