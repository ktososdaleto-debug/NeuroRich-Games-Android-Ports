/** Какой уровень открыт в редакторе и где стояла камера (чтобы вернуться туда после теста) */
export const editorSession = {
  levelId: null as string | null,
  cameras: new Map<string, { camX: number; camY: number; zoom: number }>(),
};
