import type { BlockTexture, LevelObject, ObjectType, Zone } from '../game/types';
import { CORRIDOR_TOP } from '../game/physics';

/** Как объект ставится мышью */
export type PlaceMode =
  /** клик — один объект, протяжка — рисование кистью */
  | 'paint'
  /** протяжка задаёт прямоугольник (блоки) */
  | 'rect'
  /** протяжка задаёт ширину (лава) */
  | 'row';

export interface PaletteItem {
  type: ObjectType;
  label: string;
  group: string;
  place: PlaceMode;
  /** Клавиша быстрого выбора */
  key?: string;
}

export const PALETTE_GROUPS = ['Блоки', 'Опасности', 'Прыжки', 'Порталы', 'Триггеры'] as const;

export const PALETTE: PaletteItem[] = [
  { type: 'block', label: 'Блок', group: 'Блоки', place: 'rect', key: '1' },
  { type: 'spike', label: 'Шип', group: 'Опасности', place: 'paint', key: '2' },
  { type: 'small-spike', label: 'Малый шип', group: 'Опасности', place: 'paint', key: '3' },
  { type: 'lava', label: 'Лава', group: 'Опасности', place: 'row', key: '4' },
  { type: 'pad-yellow', label: 'Батут', group: 'Прыжки', place: 'paint', key: '5' },
  { type: 'orb-yellow', label: 'Орб', group: 'Прыжки', place: 'paint', key: '6' },
  { type: 'portal-cube', label: 'Куб', group: 'Порталы', place: 'paint', key: '7' },
  { type: 'portal-ship', label: 'Корабль', group: 'Порталы', place: 'paint', key: '8' },
  { type: 'portal-ball', label: 'Шар', group: 'Порталы', place: 'paint', key: '9' },
  { type: 'portal-ufo', label: 'НЛО', group: 'Порталы', place: 'paint' },
  { type: 'portal-wave', label: 'Волна', group: 'Порталы', place: 'paint' },
  { type: 'portal-gravity-up', label: 'Гравитация ↑', group: 'Порталы', place: 'paint' },
  { type: 'portal-gravity-down', label: 'Гравитация ↓', group: 'Порталы', place: 'paint' },
  { type: 'trigger-color', label: 'Цвет', group: 'Триггеры', place: 'paint' },
  { type: 'trigger-flash', label: 'Вспышка', group: 'Триггеры', place: 'paint' },
  { type: 'trigger-zone', label: 'Зона', group: 'Триггеры', place: 'paint' },
];

export const paletteItem = (type: ObjectType): PaletteItem => PALETTE.find((p) => p.type === type) ?? PALETTE[0];

export const TEXTURE_NAMES: Record<BlockTexture, string> = {
  grass: 'Трава',
  dirt: 'Земля',
  stone: 'Камень',
  cobble: 'Булыжник',
  planks: 'Доски',
  log: 'Бревно',
  leaves: 'Листва',
  netherrack: 'Незерак',
  obsidian: 'Обсидиан',
  endstone: 'Эндерняк',
};

export const ZONE_NAMES: Record<Zone, string> = {
  surface: 'Поверхность',
  cave: 'Пещера',
  nether: 'Незер',
  end: 'Энд',
};

export const CHANNEL_NAMES = { bg: 'Фон', ground: 'Земля', line: 'Линии', obj: 'Блоки' } as const;

export interface PlaceOptions {
  rot: 0 | 90 | 180 | 270;
  tex: BlockTexture;
}

/** Новый объект в клетке (x, y) */
export function makeObject(type: ObjectType, x: number, y: number, opts: PlaceOptions): LevelObject {
  switch (type) {
    case 'block':
      return { type, x, y, w: 1, h: 1, tex: opts.tex };
    case 'lava':
      return { type, x, y: 0, w: 1 };
    case 'spike':
    case 'small-spike':
      return { type, x, y, rot: opts.rot };
    case 'trigger-color':
      return { type, x: x + 0.5, y, channel: 'bg', color: '#d12fae', duration: 2 };
    case 'trigger-flash':
      return { type, x: x + 0.5, y };
    case 'trigger-zone':
      return { type, x: x + 0.5, y, zone: 'cave' };
    default:
      // порталы по умолчанию — во всю высоту коридора, чтобы игрок не пролетел мимо
      if (type.startsWith('portal-')) return { type, x, y: 0, h: CORRIDOR_TOP };
      return { type, x, y };
  }
}

export interface Bounds {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

/** Область объекта для выделения и ластика */
export function objectBounds(o: LevelObject): Bounds {
  if (o.type.startsWith('trigger')) return { x0: o.x - 0.5, y0: o.y, x1: o.x + 0.5, y1: o.y + 1 };
  if (o.type.startsWith('portal-')) return { x0: o.x, y0: o.y, x1: o.x + 1, y1: o.y + (o.h ?? 3) };
  if (o.type === 'lava') return { x0: o.x, y0: o.y, x1: o.x + (o.w ?? 1), y1: o.y + 0.6 };
  return { x0: o.x, y0: o.y, x1: o.x + (o.w ?? 1), y1: o.y + (o.h ?? 1) };
}
