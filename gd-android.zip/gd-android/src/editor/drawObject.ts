import type { BlockTexture, LevelObject, LevelTheme } from '../game/types';
import { cellToWorld } from '../game/geometry';
import { CHANNEL_NAMES, ZONE_NAMES } from './catalog';

/** Перевод мировых координат (клетки, y вверх) в пиксели холста */
export interface View {
  sx(x: number): number;
  sy(y: number): number;
  /** пикселей в клетке */
  z: number;
}

const PORTAL_STYLE: Record<string, [string, string]> = {
  'portal-cube': ['#5dff5d', 'К'],
  'portal-ship': ['#ff5fd8', 'Кор'],
  'portal-ball': ['#ff7a1a', 'Ш'],
  'portal-ufo': ['#ffb31a', 'Н'],
  'portal-wave': ['#3fd8ff', 'В'],
  'portal-gravity-up': ['#ffe14a', '↑'],
  'portal-gravity-down': ['#3f9bff', '↓'],
};

/** Упрощённые цвета текстур темы minecraft: [основной, верхний край] */
const TEX_COLORS: Record<BlockTexture, [string, string]> = {
  grass: ['#866043', '#5f9f35'],
  dirt: ['#866043', '#866043'],
  stone: ['#7f7f7f', '#8a8a8a'],
  cobble: ['#777777', '#8c8c8c'],
  planks: ['#a2824e', '#ad8b54'],
  log: ['#5b4426', '#6b5130'],
  leaves: ['#3f7d23', '#4a8f2a'],
  netherrack: ['#6f2d2d', '#8a3b3b'],
  obsidian: ['#1b1428', '#3b2a5c'],
  endstone: ['#dedca0', '#e6e4ad'],
};

function poly(c: CanvasRenderingContext2D, v: View, o: LevelObject, pts: Array<[number, number]>): void {
  c.beginPath();
  pts.forEach(([lx, ly], i) => {
    const [wx, wy] = cellToWorld(o, lx, ly);
    if (i === 0) c.moveTo(v.sx(wx), v.sy(wy));
    else c.lineTo(v.sx(wx), v.sy(wy));
  });
  c.closePath();
}

function label(c: CanvasRenderingContext2D, text: string, x: number, y: number, size: number, color = '#fff'): void {
  c.font = `${Math.max(9, size)}px 'Russo One', sans-serif`;
  c.textAlign = 'center';
  c.textBaseline = 'middle';
  c.lineWidth = Math.max(2, size / 4);
  c.strokeStyle = '#000';
  c.strokeText(text, x, y);
  c.fillStyle = color;
  c.fillText(text, x, y);
}

/** Рисует объект уровня. Триггеры дополнительно получают вертикальную линию срабатывания (если withLine). */
export function drawEditorObject(c: CanvasRenderingContext2D, o: LevelObject, v: View, theme: LevelTheme, withLine = true): void {
  const z = v.z;
  const lw = Math.max(1.5, z * 0.06);
  c.lineJoin = 'round';

  switch (o.type) {
    case 'block': {
      const w = o.w ?? 1;
      const h = o.h ?? 1;
      const x = v.sx(o.x);
      const y = v.sy(o.y + h);
      if (theme === 'minecraft') {
        const [body, top] = TEX_COLORS[o.tex ?? 'stone'];
        c.fillStyle = body;
        c.fillRect(x, y, w * z, h * z);
        c.fillStyle = top;
        c.fillRect(x, y, w * z, Math.min(h * z, z * 0.28));
        c.strokeStyle = 'rgba(0,0,0,0.35)';
        c.lineWidth = 1;
        for (let i = 1; i < w; i++) c.strokeRect(x + i * z, y, 0, h * z);
        for (let j = 1; j < h; j++) c.strokeRect(x, y + j * z, w * z, 0);
        c.strokeStyle = '#000';
      } else {
        c.fillStyle = 'rgba(0,0,0,0.85)';
        c.fillRect(x, y, w * z, h * z);
        c.strokeStyle = 'rgba(255,255,255,0.15)';
        c.lineWidth = 1;
        for (let i = 1; i < w; i++) c.strokeRect(x + i * z, y, 0, h * z);
        for (let j = 1; j < h; j++) c.strokeRect(x, y + j * z, w * z, 0);
        c.strokeStyle = '#fff';
      }
      c.lineWidth = lw;
      c.strokeRect(x + lw / 2, y + lw / 2, w * z - lw, h * z - lw);
      break;
    }
    case 'spike':
    case 'small-spike': {
      const h = o.type === 'small-spike' ? 0.45 : 0.92;
      poly(c, v, o, [[0.08, 0], [0.5, h], [0.92, 0]]);
      c.fillStyle = theme === 'minecraft' ? '#9a9a9a' : '#000';
      c.fill();
      c.lineWidth = lw;
      c.strokeStyle = theme === 'minecraft' ? '#2a2a2a' : '#fff';
      c.stroke();
      break;
    }
    case 'lava': {
      const x = v.sx(o.x);
      const w = (o.w ?? 1) * z;
      c.fillStyle = '#ff6a00';
      c.fillRect(x, v.sy(o.y + 0.45), w, 0.45 * z);
      c.fillStyle = '#ffd23f';
      c.fillRect(x, v.sy(o.y + 0.45), w, 0.12 * z);
      break;
    }
    case 'pad-yellow':
      poly(c, v, o, [[0.06, 0], [0.94, 0], [0.8, 0.22], [0.2, 0.22]]);
      c.fillStyle = '#ffd21f';
      c.fill();
      c.lineWidth = lw;
      c.strokeStyle = '#000';
      c.stroke();
      break;
    case 'orb-yellow': {
      const cx = v.sx(o.x + 0.5);
      const cy = v.sy(o.y + 0.5);
      c.beginPath();
      c.arc(cx, cy, z * 0.52, 0, Math.PI * 2);
      c.lineWidth = lw;
      c.strokeStyle = 'rgba(255,225,74,0.7)';
      c.stroke();
      c.beginPath();
      c.arc(cx, cy, z * 0.32, 0, Math.PI * 2);
      c.fillStyle = '#ffe14a';
      c.fill();
      c.strokeStyle = '#000';
      c.stroke();
      break;
    }
    case 'trigger-color':
    case 'trigger-flash':
    case 'trigger-zone': {
      const x = v.sx(o.x);
      const cy = v.sy(o.y + 0.5);
      const color = o.type === 'trigger-color' ? (o.color ?? '#fff') : o.type === 'trigger-flash' ? '#ffffff' : '#9d7dff';
      if (withLine) {
        c.save();
        c.setLineDash([6, 6]);
        c.strokeStyle = color;
        c.globalAlpha = 0.45;
        c.lineWidth = 2;
        c.beginPath();
        c.moveTo(x, 0);
        c.lineTo(x, c.canvas.height);
        c.stroke();
        c.restore();
      }
      c.beginPath();
      c.moveTo(x, cy - z * 0.42);
      c.lineTo(x + z * 0.42, cy);
      c.lineTo(x, cy + z * 0.42);
      c.lineTo(x - z * 0.42, cy);
      c.closePath();
      c.fillStyle = color;
      c.fill();
      c.lineWidth = lw;
      c.strokeStyle = '#000';
      c.stroke();
      const text =
        o.type === 'trigger-color'
          ? CHANNEL_NAMES[o.channel ?? 'bg'][0]
          : o.type === 'trigger-flash'
            ? '✦'
            : ZONE_NAMES[o.zone ?? 'surface'][0];
      label(c, text, x, cy, z * 0.38);
      break;
    }
    default: {
      const [color, text] = PORTAL_STYLE[o.type] ?? ['#fff', '?'];
      const h = o.h ?? 3;
      const cx = v.sx(o.x + 0.5);
      const cy = v.sy(o.y + h / 2);
      const rx = z * 0.4;
      const ry = (h * z) / 2;
      c.beginPath();
      c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
      c.fillStyle = color + '33';
      c.fill();
      c.lineWidth = z * 0.18;
      c.strokeStyle = '#000';
      c.stroke();
      c.lineWidth = z * 0.1;
      c.strokeStyle = color;
      c.stroke();
      label(c, text, cx, cy, z * 0.42, color);
    }
  }
}
