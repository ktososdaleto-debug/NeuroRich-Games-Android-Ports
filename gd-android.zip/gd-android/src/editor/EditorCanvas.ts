import type { ObjectType } from '../game/types';
import { CORRIDOR_TOP, SPEED } from '../game/physics';
import { levelLength, songChoice } from '../state/customLevels';
import { makeObject, objectBounds, paletteItem, type Bounds, type PlaceOptions } from './catalog';
import { drawEditorObject, type View } from './drawObject';
import type { EditorDoc } from './EditorDoc';

export type Tool = 'build' | 'select' | 'erase';

export interface CursorInfo {
  x: number;
  y: number;
  beat: number;
}

type Drag =
  | { kind: 'pan'; px: number; py: number; camX: number; camY: number }
  | { kind: 'paint'; last: string }
  | { kind: 'erase' }
  | { kind: 'rect'; x0: number; y0: number; x1: number; y1: number }
  | { kind: 'move'; wx: number; wy: number; applied: [number, number]; started: boolean }
  | { kind: 'band'; x0: number; y0: number; x1: number; y1: number; add: boolean };

const MIN_ZOOM = 12;
const MAX_ZOOM = 120;

/**
 * Холст редактора на Canvas 2D: сетка с долями и тактами текущего трека, объекты,
 * выделение и все жесты мышью. Клавиатуру ему передаёт экран (handleKey).
 */
export class EditorCanvas {
  readonly el = document.createElement('canvas');
  private readonly ctx = this.el.getContext('2d')!;
  tool: Tool = 'build';
  item: ObjectType = 'block';
  placeOpts: PlaceOptions = { rot: 0, tex: 'grass' };
  snap = 1;
  /** Мировой x у левого края и y у нижнего края холста */
  camX = -4;
  camY = -2;
  zoom = 40;
  private playhead: number | null = null;
  private W = 0;
  private H = 0;
  private dpr = 1;
  private drag: Drag | null = null;
  private hover: [number, number] | null = null;
  private raf = 0;
  private readonly resizeObserver: ResizeObserver;
  private readonly offDoc: () => void;

  constructor(
    private readonly doc: EditorDoc,
    private readonly onCursor: (info: CursorInfo) => void,
  ) {
    this.el.className = 'editor-canvas';
    this.el.addEventListener('pointerdown', this.onDown);
    this.el.addEventListener('pointermove', this.onMove);
    this.el.addEventListener('pointerup', this.onUp);
    this.el.addEventListener('pointercancel', this.onUp);
    this.el.addEventListener('pointerleave', () => {
      this.hover = null;
      this.invalidate();
    });
    this.el.addEventListener('wheel', this.onWheel, { passive: false });
    this.el.addEventListener('contextmenu', (e) => e.preventDefault());
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.el);
    this.offDoc = doc.onChange(() => this.invalidate());
  }

  destroy(): void {
    cancelAnimationFrame(this.raf);
    this.resizeObserver.disconnect();
    this.offDoc();
  }

  invalidate(): void {
    if (!this.raf) this.raf = requestAnimationFrame(this.frame);
  }

  setPlayhead(x: number | null): void {
    this.playhead = x;
    if (x !== null) {
      const right = this.camX + (this.W / this.zoom) * 0.75;
      if (x > right || x < this.camX) this.camX = x - (this.W / this.zoom) * 0.2;
    }
    this.invalidate();
  }

  get beatBlocks(): number {
    return (SPEED * 60) / songChoice(this.doc.level.songId).bpm;
  }

  jumpTo(where: 'start' | 'end'): void {
    const len = levelLength(this.doc.level);
    this.camX = where === 'start' ? -4 : len - (this.W / this.zoom) * 0.7;
    this.invalidate();
  }

  zoomBy(factor: number, anchorX = this.W / 2): void {
    const wx = this.camX + anchorX / this.zoom;
    this.zoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, this.zoom * factor));
    this.camX = wx - anchorX / this.zoom;
    this.invalidate();
  }

  /** Горячие клавиши холста; true — обработано */
  handleKey(e: KeyboardEvent): boolean {
    const doc = this.doc;
    const ctrl = e.ctrlKey || e.metaKey;
    const sel = doc.selection;
    const step = (e.shiftKey ? 4 : 1) * this.snap;
    switch (e.code) {
      case 'KeyZ':
        if (!ctrl) return false;
        if (e.shiftKey) doc.redo();
        else doc.undo();
        return true;
      case 'KeyY':
        if (!ctrl) return false;
        doc.redo();
        return true;
      case 'KeyC':
        if (!ctrl) return false;
        doc.copy();
        return true;
      case 'KeyV':
        if (ctrl) {
          const [x, y] = this.hover ? this.cell(...this.hover) : [Math.round(this.camX + this.W / this.zoom / 2), 0];
          doc.paste(x, y);
          this.tool = 'select';
          return true;
        }
        this.tool = 'select';
        return true;
      case 'KeyD':
        if (!ctrl) return false;
        doc.duplicate();
        return true;
      case 'KeyA':
        if (!ctrl) return false;
        doc.select(doc.objects);
        this.tool = 'select';
        return true;
      case 'KeyB':
        this.tool = 'build';
        this.invalidate();
        return true;
      case 'KeyE':
        this.tool = 'erase';
        this.invalidate();
        return true;
      case 'KeyR':
        if (sel.size) doc.rotate(sel);
        else this.placeOpts.rot = (((this.placeOpts.rot + 90) % 360) as PlaceOptions['rot']);
        this.invalidate();
        return true;
      case 'KeyG':
        this.snap = this.snap === 1 ? 0.5 : 1;
        this.invalidate();
        return true;
      case 'Delete':
      case 'Backspace':
        doc.remove(sel);
        return true;
      case 'Home':
        this.jumpTo('start');
        return true;
      case 'End':
        this.jumpTo('end');
        return true;
      case 'Equal':
      case 'NumpadAdd':
        this.zoomBy(1.2);
        return true;
      case 'Minus':
      case 'NumpadSubtract':
        this.zoomBy(1 / 1.2);
        return true;
      case 'ArrowLeft':
      case 'ArrowRight':
      case 'ArrowUp':
      case 'ArrowDown': {
        const dx = e.code === 'ArrowLeft' ? -step : e.code === 'ArrowRight' ? step : 0;
        const dy = e.code === 'ArrowDown' ? -step : e.code === 'ArrowUp' ? step : 0;
        if (sel.size) doc.move(sel, dx, dy);
        else {
          this.camX += dx * 2;
          this.camY += dy;
          this.invalidate();
        }
        return true;
      }
    }
    return false;
  }

  // ---- Координаты -----------------------------------------------------------

  private view(): View {
    return {
      sx: (x) => (x - this.camX) * this.zoom,
      sy: (y) => this.H - (y - this.camY) * this.zoom,
      z: this.zoom,
    };
  }

  private toWorld(e: PointerEvent | WheelEvent): [number, number] {
    const r = this.el.getBoundingClientRect();
    return [this.camX + (e.clientX - r.left) / this.zoom, this.camY + (r.bottom - e.clientY) / this.zoom];
  }

  private cell(wx: number, wy: number): [number, number] {
    const s = this.snap;
    return [Math.floor(wx / s) * s, Math.max(0, Math.floor(wy / s) * s)];
  }

  private resize(): void {
    const r = this.el.getBoundingClientRect();
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.W = r.width;
    this.H = r.height;
    this.el.width = Math.max(1, Math.round(r.width * this.dpr));
    this.el.height = Math.max(1, Math.round(r.height * this.dpr));
    this.invalidate();
  }

  // ---- Мышь -----------------------------------------------------------------

  private readonly onDown = (e: PointerEvent): void => {
    this.el.setPointerCapture(e.pointerId);
    const [wx, wy] = this.toWorld(e);
    const doc = this.doc;

    if (e.button === 1 || e.button === 2) {
      this.drag = { kind: 'pan', px: e.clientX, py: e.clientY, camX: this.camX, camY: this.camY };
      return;
    }
    if (this.tool === 'build') {
      const [cx, cy] = this.cell(wx, wy);
      const mode = paletteItem(this.item).place;
      if (mode === 'rect' || mode === 'row') {
        this.drag = { kind: 'rect', x0: cx, y0: mode === 'row' ? 0 : cy, x1: cx, y1: mode === 'row' ? 0 : cy };
      } else {
        doc.checkpoint();
        this.placeAt(cx, cy);
        this.drag = { kind: 'paint', last: `${cx}|${cy}` };
      }
    } else if (this.tool === 'erase') {
      doc.checkpoint();
      this.eraseAt(wx, wy);
      this.drag = { kind: 'erase' };
    } else {
      const hit = doc.objectAt(wx, wy);
      if (hit) {
        if (e.shiftKey) {
          if (doc.selection.has(hit)) doc.selection.delete(hit);
          else doc.selection.add(hit);
          doc.changed();
        } else if (!doc.selection.has(hit)) doc.select([hit]);
        this.drag = { kind: 'move', wx, wy, applied: [0, 0], started: false };
      } else {
        if (!e.shiftKey) doc.select([]);
        this.drag = { kind: 'band', x0: wx, y0: wy, x1: wx, y1: wy, add: e.shiftKey };
      }
    }
    this.invalidate();
  };

  private readonly onMove = (e: PointerEvent): void => {
    const [wx, wy] = this.toWorld(e);
    this.hover = [wx, wy];
    const [cx, cy] = this.cell(wx, wy);
    this.onCursor({ x: cx, y: cy, beat: wx / this.beatBlocks });
    const d = this.drag;
    if (d) {
      switch (d.kind) {
        case 'pan':
          this.camX = d.camX - (e.clientX - d.px) / this.zoom;
          this.camY = d.camY + (e.clientY - d.py) / this.zoom;
          break;
        case 'paint': {
          const key = `${cx}|${cy}`;
          if (key !== d.last) {
            d.last = key;
            this.placeAt(cx, cy);
          }
          break;
        }
        case 'erase':
          this.eraseAt(wx, wy);
          break;
        case 'rect':
          d.x1 = cx;
          if (paletteItem(this.item).place === 'rect') d.y1 = cy;
          break;
        case 'band':
          d.x1 = wx;
          d.y1 = wy;
          break;
        case 'move': {
          const s = this.snap;
          const dx = Math.round((wx - d.wx) / s) * s;
          const dy = Math.round((wy - d.wy) / s) * s;
          if (dx !== d.applied[0] || dy !== d.applied[1]) {
            if (!d.started) {
              this.doc.checkpoint();
              d.started = true;
            }
            this.doc.shift(this.doc.selection, dx - d.applied[0], dy - d.applied[1]);
            d.applied = [dx, dy];
          }
          break;
        }
      }
    }
    this.invalidate();
  };

  private readonly onUp = (): void => {
    const d = this.drag;
    this.drag = null;
    if (!d) return;
    if (d.kind === 'rect') {
      const s = this.snap;
      const x0 = Math.min(d.x0, d.x1);
      const y0 = Math.min(d.y0, d.y1);
      const w = Math.abs(d.x1 - d.x0) + s;
      const h = Math.abs(d.y1 - d.y0) + s;
      const o = makeObject(this.item, x0, y0, this.placeOpts);
      o.w = w;
      if (this.item === 'block') o.h = h;
      this.doc.add([o]);
    } else if (d.kind === 'band') {
      const r: Bounds = {
        x0: Math.min(d.x0, d.x1),
        y0: Math.min(d.y0, d.y1),
        x1: Math.max(d.x0, d.x1),
        y1: Math.max(d.y0, d.y1),
      };
      if (r.x1 - r.x0 > 0.05 || r.y1 - r.y0 > 0.05) this.doc.select(this.doc.objectsIn(r), d.add);
    }
    this.invalidate();
  };

  private readonly onWheel = (e: WheelEvent): void => {
    e.preventDefault();
    if (e.ctrlKey || e.metaKey) {
      const r = this.el.getBoundingClientRect();
      this.zoomBy(e.deltaY < 0 ? 1.15 : 1 / 1.15, e.clientX - r.left);
      return;
    }
    if (e.shiftKey) this.camY -= e.deltaY / this.zoom;
    else this.camX += (Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY) / this.zoom;
    this.invalidate();
  };

  private placeAt(cx: number, cy: number): void {
    const proto = makeObject(this.item, cx, cy, this.placeOpts);
    const dup = this.doc.objects.some(
      (o) => o.type === proto.type && Math.abs(o.x - proto.x) < 1e-6 && Math.abs(o.y - proto.y) < 1e-6,
    );
    if (!dup) this.doc.insertRaw([proto]);
  }

  private eraseAt(wx: number, wy: number): void {
    const hit = this.doc.objectAt(wx, wy);
    if (hit) this.doc.removeRaw(hit);
  }

  // ---- Отрисовка ------------------------------------------------------------

  private readonly frame = (): void => {
    this.raf = 0;
    this.draw();
  };

  private draw(): void {
    const c = this.ctx;
    const { W, H, zoom: z } = this;
    const v = this.view();
    const level = this.doc.level;
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);

    // небо и земля
    c.fillStyle = level.colors.bg;
    c.fillRect(0, 0, W, H);
    c.fillStyle = 'rgba(0,0,0,0.25)';
    c.fillRect(0, 0, W, H);
    const gy = v.sy(0);
    c.fillStyle = level.colors.ground;
    if (gy < H) c.fillRect(0, gy, W, H - gy);

    this.drawGrid(c, v);

    // потолок коридора
    const cy = v.sy(CORRIDOR_TOP);
    c.save();
    c.setLineDash([10, 8]);
    c.strokeStyle = 'rgba(255,255,255,0.35)';
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(0, cy);
    c.lineTo(W, cy);
    c.stroke();
    c.restore();
    c.font = `12px 'Russo One', sans-serif`;
    c.textAlign = 'left';
    c.textBaseline = 'bottom';
    c.fillStyle = 'rgba(255,255,255,0.55)';
    c.fillText('потолок в режимах корабль · шар · НЛО · волна', 8, cy - 4);

    // старт и финиш
    const len = levelLength(level);
    this.marker(c, v.sx(0), '#5dff7a', 'Старт');
    this.marker(c, v.sx(len), '#ffffff', 'Финиш');

    // объекты
    const x0 = this.camX - 2;
    const x1 = this.camX + W / z + 2;
    for (const o of this.doc.objects) {
      const b = objectBounds(o);
      const isTrigger = o.type.startsWith('trigger');
      if (!isTrigger && (b.x1 < x0 || b.x0 > x1)) continue;
      if (isTrigger && (o.x < x0 || o.x > x1)) continue;
      drawEditorObject(c, o, v, level.theme);
    }

    // выделение
    c.lineWidth = 2;
    c.strokeStyle = '#3ff0ff';
    c.fillStyle = 'rgba(63,240,255,0.12)';
    for (const o of this.doc.selection) {
      const b = objectBounds(o);
      const rx = v.sx(b.x0);
      const ry = v.sy(b.y1);
      c.fillRect(rx, ry, (b.x1 - b.x0) * z, (b.y1 - b.y0) * z);
      c.strokeRect(rx, ry, (b.x1 - b.x0) * z, (b.y1 - b.y0) * z);
    }

    this.drawGhost(c, v);

    if (this.playhead !== null) {
      const px = v.sx(this.playhead);
      c.fillStyle = '#ffd21f';
      c.fillRect(px - 1.5, 0, 3, H);
    }
  }

  private drawGrid(c: CanvasRenderingContext2D, v: View): void {
    const { W, H, zoom: z } = this;
    const beat = this.beatBlocks;
    const x0 = this.camX;
    const x1 = this.camX + W / z;
    // клетки
    if (z >= 14) {
      c.strokeStyle = 'rgba(255,255,255,0.07)';
      c.lineWidth = 1;
      c.beginPath();
      for (let x = Math.floor(x0); x <= x1; x++) {
        c.moveTo(Math.round(v.sx(x)) + 0.5, 0);
        c.lineTo(Math.round(v.sx(x)) + 0.5, H);
      }
      for (let y = Math.floor(this.camY); y <= this.camY + H / z; y++) {
        c.moveTo(0, Math.round(v.sy(y)) + 0.5);
        c.lineTo(W, Math.round(v.sy(y)) + 0.5);
      }
      c.stroke();
    }
    // доли и такты трека — сюда удобно ставить препятствия в ритм
    c.font = `11px 'Russo One', sans-serif`;
    c.textAlign = 'left';
    c.textBaseline = 'top';
    for (let k = Math.max(0, Math.floor(x0 / beat)); k * beat <= x1; k++) {
      const sx = Math.round(v.sx(k * beat)) + 0.5;
      const bar = k % 4 === 0;
      c.strokeStyle = bar ? 'rgba(255,210,31,0.55)' : 'rgba(255,210,31,0.2)';
      c.lineWidth = bar ? 2 : 1;
      c.beginPath();
      c.moveTo(sx, 0);
      c.lineTo(sx, H);
      c.stroke();
      if (bar) {
        c.fillStyle = 'rgba(255,230,140,0.9)';
        c.fillText(`такт ${k / 4 + 1}`, sx + 4, 4);
      }
    }
    // линия земли
    c.fillStyle = 'rgba(255,255,255,0.85)';
    c.fillRect(0, v.sy(0) - 1, W, 2);
  }

  private marker(c: CanvasRenderingContext2D, x: number, color: string, text: string): void {
    c.fillStyle = color;
    c.fillRect(x - 2, 0, 4, this.H);
    c.font = `13px 'Russo One', sans-serif`;
    c.textAlign = 'left';
    c.textBaseline = 'top';
    c.fillText(text, x + 6, 22);
  }

  /** Подсказка под курсором: что и где появится */
  private drawGhost(c: CanvasRenderingContext2D, v: View): void {
    const d = this.drag;
    const z = this.zoom;
    if (d?.kind === 'band') {
      c.save();
      c.setLineDash([6, 4]);
      c.strokeStyle = '#3ff0ff';
      c.lineWidth = 1.5;
      c.strokeRect(v.sx(Math.min(d.x0, d.x1)), v.sy(Math.max(d.y0, d.y1)), Math.abs(d.x1 - d.x0) * z, Math.abs(d.y1 - d.y0) * z);
      c.restore();
      return;
    }
    if (d?.kind === 'rect') {
      const o = makeObject(this.item, Math.min(d.x0, d.x1), Math.min(d.y0, d.y1), this.placeOpts);
      o.w = Math.abs(d.x1 - d.x0) + this.snap;
      if (this.item === 'block') o.h = Math.abs(d.y1 - d.y0) + this.snap;
      c.globalAlpha = 0.6;
      drawEditorObject(c, o, v, this.doc.level.theme, false);
      c.globalAlpha = 1;
      return;
    }
    if (!this.hover || d) return;
    const [cx, cy] = this.cell(...this.hover);
    if (this.tool === 'build') {
      c.globalAlpha = 0.45;
      drawEditorObject(c, makeObject(this.item, cx, cy, this.placeOpts), v, this.doc.level.theme, false);
      c.globalAlpha = 1;
    } else if (this.tool === 'erase') {
      c.strokeStyle = '#ff4b5c';
      c.lineWidth = 2;
      c.strokeRect(v.sx(cx), v.sy(cy + this.snap), this.snap * z, this.snap * z);
    }
  }
}
