import type { LevelObject } from '../game/types';
import { saveCustomLevel, type CustomLevel } from '../state/customLevels';
import { objectBounds, type Bounds } from './catalog';

const HISTORY_LIMIT = 120;
const SAVE_DELAY_MS = 400;

/**
 * Редактируемый уровень: объекты, выделение, история отмены и автосохранение.
 * История хранит снимки всего списка объектов — просто и надёжно при любых правках.
 */
export class EditorDoc {
  readonly selection = new Set<LevelObject>();
  private undoStack: string[] = [];
  private redoStack: string[] = [];
  private clipboard: LevelObject[] = [];
  private readonly listeners = new Set<() => void>();
  private saveTimer = 0;

  constructor(public level: CustomLevel) {}

  get objects(): LevelObject[] {
    return this.level.objects;
  }

  get canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  get canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  onChange(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }

  /** Вызывается перед каждой правкой — запоминает состояние для отмены */
  checkpoint(): void {
    this.undoStack.push(JSON.stringify(this.objects));
    if (this.undoStack.length > HISTORY_LIMIT) this.undoStack.shift();
    this.redoStack = [];
  }

  undo(): void {
    const prev = this.undoStack.pop();
    if (prev === undefined) return;
    this.redoStack.push(JSON.stringify(this.objects));
    this.level.objects = JSON.parse(prev) as LevelObject[];
    this.selection.clear();
    this.changed();
  }

  redo(): void {
    const next = this.redoStack.pop();
    if (next === undefined) return;
    this.undoStack.push(JSON.stringify(this.objects));
    this.level.objects = JSON.parse(next) as LevelObject[];
    this.selection.clear();
    this.changed();
  }

  /** Сообщить об изменении: перерисовка, обновление панелей и отложенное сохранение */
  changed(): void {
    for (const fn of this.listeners) fn();
    window.clearTimeout(this.saveTimer);
    this.saveTimer = window.setTimeout(() => this.save(), SAVE_DELAY_MS);
  }

  save(): void {
    window.clearTimeout(this.saveTimer);
    saveCustomLevel(this.level);
  }

  // ---- «Тихие» правки для жестов мышью: checkpoint делается один раз в начале жеста

  insertRaw(objs: LevelObject[]): void {
    this.level.objects.push(...objs);
    this.changed();
  }

  removeRaw(o: LevelObject): void {
    this.level.objects = this.level.objects.filter((x) => x !== o);
    this.selection.delete(o);
    this.changed();
  }

  // ---- Правки (каждая сама делает checkpoint) --------------------------------

  add(objs: LevelObject[], select = false): void {
    if (!objs.length) return;
    this.checkpoint();
    this.level.objects.push(...objs);
    if (select) {
      this.selection.clear();
      for (const o of objs) this.selection.add(o);
    }
    this.changed();
  }

  remove(objs: Iterable<LevelObject>): void {
    const set = new Set(objs);
    if (!set.size) return;
    this.checkpoint();
    this.level.objects = this.level.objects.filter((o) => !set.has(o));
    for (const o of set) this.selection.delete(o);
    this.changed();
  }

  /** Сдвиг без checkpoint — для перетаскивания (checkpoint делается в начале жеста) */
  shift(objs: Iterable<LevelObject>, dx: number, dy: number): void {
    for (const o of objs) {
      o.x += dx;
      // лава всегда лежит на земле
      if (o.type !== 'lava') o.y = Math.max(0, o.y + dy);
    }
    this.changed();
  }

  move(objs: Iterable<LevelObject>, dx: number, dy: number): void {
    this.checkpoint();
    this.shift(objs, dx, dy);
  }

  /** Поворот шипов на 90° по часовой стрелке */
  rotate(objs: Iterable<LevelObject>): void {
    const spikes = [...objs].filter((o) => o.type === 'spike' || o.type === 'small-spike');
    if (!spikes.length) return;
    this.checkpoint();
    for (const o of spikes) o.rot = (((o.rot ?? 0) + 90) % 360) as 0 | 90 | 180 | 270;
    this.changed();
  }

  update(o: LevelObject, patch: Partial<LevelObject>): void {
    this.checkpoint();
    Object.assign(o, patch);
    this.changed();
  }

  // ---- Выделение и буфер обмена ----------------------------------------------

  /** Верхний объект в точке (последний нарисованный) */
  objectAt(x: number, y: number): LevelObject | null {
    for (let i = this.objects.length - 1; i >= 0; i--) {
      const b = objectBounds(this.objects[i]);
      if (x >= b.x0 && x < b.x1 && y >= b.y0 && y < b.y1) return this.objects[i];
    }
    return null;
  }

  objectsIn(r: Bounds): LevelObject[] {
    return this.objects.filter((o) => {
      const b = objectBounds(o);
      return b.x0 < r.x1 && b.x1 > r.x0 && b.y0 < r.y1 && b.y1 > r.y0;
    });
  }

  select(objs: Iterable<LevelObject>, add = false): void {
    if (!add) this.selection.clear();
    for (const o of objs) this.selection.add(o);
    this.changed();
  }

  copy(): number {
    this.clipboard = [...this.selection].map((o) => ({ ...o }));
    return this.clipboard.length;
  }

  /** Вставка так, чтобы левый нижний угол копии оказался в клетке (x, y) */
  paste(x: number, y: number): void {
    if (!this.clipboard.length) return;
    const minX = Math.min(...this.clipboard.map((o) => objectBounds(o).x0));
    const minY = Math.min(...this.clipboard.map((o) => o.y));
    const copies = this.clipboard.map((o) => ({ ...o, x: o.x - minX + x, y: Math.max(0, o.y - minY + y) }));
    this.add(copies, true);
  }

  /** Дублировать выделение сразу правее него */
  duplicate(): void {
    const sel = [...this.selection];
    if (!sel.length) return;
    const x0 = Math.min(...sel.map((o) => objectBounds(o).x0));
    const x1 = Math.max(...sel.map((o) => objectBounds(o).x1));
    const width = Math.ceil(x1 - x0);
    this.add(
      sel.map((o) => ({ ...o, x: o.x + width })),
      true,
    );
  }
}
