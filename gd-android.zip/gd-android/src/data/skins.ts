import { EFFECTS, type EffectDef, type EffectId } from './effects';

export type UnlockKind = 'stars' | 'attempts' | 'jumps' | 'best';

/** Условие открытия иконки: набрать value звёзд / попыток / прыжков / рекорд в % */
export interface UnlockRule {
  kind: UnlockKind;
  value: number;
}

export interface IconDef {
  id: string;
  name: string;
  /** null — доступна сразу */
  unlock: UnlockRule | null;
  /** Особый скин-картинка (public/skins) — рисуется вместо процедурного узора */
  image?: string;
  effect?: EffectId;
}

/** Порядок важен: так иконки идут в сетке выбора. Рисунок каждой — в render/cubeArt.ts */
export const ICONS: readonly IconDef[] = [
  { id: 'classic', name: 'Классика', unlock: null },
  { id: 'smile', name: 'Улыбка', unlock: null },
  { id: 'cross', name: 'Крест', unlock: null },
  { id: 'grid', name: 'Сетка', unlock: null },
  { id: 'diamond', name: 'Ромб', unlock: { kind: 'attempts', value: 5 } },
  { id: 'ring', name: 'Кольцо', unlock: { kind: 'jumps', value: 100 } },
  { id: 'robot', name: 'Робот', unlock: { kind: 'best', value: 50 } },
  { id: 'stripes', name: 'Полосы', unlock: { kind: 'attempts', value: 25 } },
  { id: 'angry', name: 'Злюка', unlock: { kind: 'jumps', value: 500 } },
  { id: 'target', name: 'Мишень', unlock: { kind: 'stars', value: 3 } },
  { id: 'pixel', name: 'Пиксель', unlock: { kind: 'jumps', value: 1500 } },
  { id: 'demon', name: 'Демон', unlock: { kind: 'attempts', value: 100 } },

  // Особые скины с эффектами — доступны всегда
  { id: 'mc-grass', name: 'Травяной блок', unlock: null, image: 'skins/minecraft_grass.png', effect: 'grass' },
  { id: 'mc-creeper', name: 'Крипер', unlock: null, image: 'skins/minecraft_creeper.png', effect: 'creeper' },
  { id: 'neon-robot', name: 'Неоновый робот', unlock: null, image: 'skins/neon_robot.png', effect: 'neon' },
  { id: 'magma', name: 'Магма', unlock: null, image: 'skins/magma.png', effect: 'magma' },
  { id: 'ice', name: 'Лёд', unlock: null, image: 'skins/ice.png', effect: 'ice' },
  { id: 'steampunk', name: 'Стимпанк', unlock: null, image: 'skins/steampunk.png', effect: 'steam' },
  { id: 'candy', name: 'Конфета', unlock: null, image: 'skins/candy.png', effect: 'candy' },
  { id: 'cosmic', name: 'Космос', unlock: null, image: 'skins/cosmic.png', effect: 'cosmic' },
];

export function iconDef(id: string): IconDef {
  return ICONS.find((i) => i.id === id) ?? ICONS[0];
}

export function effectOf(skin: SkinConfig): EffectDef | null {
  const def = iconDef(skin.icon);
  return def.effect ? EFFECTS[def.effect] : null;
}

export function describeUnlock(r: UnlockRule): { short: string; full: string } {
  switch (r.kind) {
    case 'stars':
      return { short: `${r.value}★`, full: `${r.value} ★ — пройдите уровень` };
    case 'attempts':
      return { short: `${r.value} поп.`, full: `${r.value} попыток` };
    case 'jumps':
      return { short: `${r.value} пр.`, full: `${r.value} прыжков` };
    case 'best':
      return { short: `${r.value}%`, full: `рекорд ${r.value}% в обычном режиме` };
  }
}

export const PALETTE: readonly string[] = [
  '#7dff00', '#00ff00', '#00ff7d', '#00ffff', '#007dff', '#0000ff',
  '#7d00ff', '#ff00ff', '#ff007d', '#ff0000', '#ff7d00', '#ffff00',
  '#ffffff', '#b9b9b9', '#5a5a5a', '#000000', '#ffb3d9', '#a0e7ff',
  '#c8ff96', '#ffe08a', '#8b4dff', '#00c8a0', '#ff5a5a', '#3a6bff',
];

export interface SkinConfig {
  icon: string;
  primary: string;
  secondary: string;
  glow: boolean;
}

export const DEFAULT_SKIN: SkinConfig = {
  icon: 'classic',
  primary: '#7dff00',
  secondary: '#00ffff',
  glow: false,
};
