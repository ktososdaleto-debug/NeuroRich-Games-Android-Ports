/**
 * Эффекты особых скинов: частицы-шлейф за игроком, свечение вокруг и цвет взрыва.
 * Одно и то же описание используют игра (GameRenderer) и превью в «Иконках» (effectPreview).
 * Размеры и скорости — в клетках (1 клетка = размер куба).
 */

export type ParticleShape = 'square' | 'circle' | 'star' | 'spark' | 'smoke' | 'flake' | 'sprinkle' | 'ember';

export interface EffectDef {
  /** Подпись для экрана «Иконки» */
  name: string;
  colors: number[];
  shape: ParticleShape;
  /** Частиц в секунду */
  rate: number;
  size: [number, number];
  life: [number, number];
  /** Случайный разброс скорости */
  speed: number;
  /** Начальная скорость вверх */
  rise: number;
  /** Ускорение вниз (отрицательное — частицы всплывают) */
  gravity: number;
  /** Светящиеся частицы (аддитивное смешивание) */
  additive: boolean;
  /** Цвет свечения вокруг игрока */
  aura?: number;
  /** Цвета и масштаб взрыва при смерти */
  deathColors?: number[];
  deathScale?: number;
}

export type EffectId = 'grass' | 'creeper' | 'neon' | 'magma' | 'ice' | 'steam' | 'candy' | 'cosmic';

export const EFFECTS: Record<EffectId, EffectDef> = {
  grass: {
    name: 'Комья земли и трава',
    colors: [0x6cc24a, 0x4e9a2f, 0x8b5a2b, 0x6b4423],
    shape: 'square',
    rate: 26,
    size: [0.1, 0.2],
    life: [0.4, 0.7],
    speed: 1.5,
    rise: 2,
    gravity: 12,
    additive: false,
    deathColors: [0x6cc24a, 0x8b5a2b, 0x6b4423, 0x9a9a9a],
  },
  creeper: {
    name: 'Шипящий дым и мощный взрыв',
    colors: [0x9aa39a, 0xc8d0c8, 0x5fd35f],
    shape: 'smoke',
    rate: 14,
    size: [0.2, 0.4],
    life: [0.5, 0.9],
    speed: 0.6,
    rise: 1,
    gravity: -1.5,
    additive: false,
    deathColors: [0xffffff, 0xffd27a, 0x777777, 0x5fd35f],
    deathScale: 2.2,
  },
  neon: {
    name: 'Неоновые искры',
    colors: [0x00f0ff, 0xff2bd6],
    shape: 'spark',
    rate: 40,
    size: [0.25, 0.5],
    life: [0.15, 0.3],
    speed: 4,
    rise: 0,
    gravity: 0,
    additive: true,
    aura: 0x00e5ff,
    deathColors: [0x00f0ff, 0xff2bd6, 0xffffff],
  },
  magma: {
    name: 'Раскалённые угли',
    colors: [0xffd23f, 0xff7a00, 0xff3d00],
    shape: 'ember',
    rate: 34,
    size: [0.08, 0.16],
    life: [0.4, 0.8],
    speed: 1.2,
    rise: 2.5,
    gravity: -3,
    additive: true,
    aura: 0xff6a00,
    deathColors: [0xffd23f, 0xff7a00, 0x333333],
  },
  ice: {
    name: 'Снежинки и иней',
    colors: [0xffffff, 0xbdf3ff, 0x7fdcff],
    shape: 'flake',
    rate: 18,
    size: [0.15, 0.28],
    life: [0.6, 1],
    speed: 0.8,
    rise: 0.5,
    gravity: 2.5,
    additive: false,
    aura: 0x9be8ff,
    deathColors: [0xffffff, 0xbdf3ff, 0x3a7bd5],
  },
  steam: {
    name: 'Пар и латунные искры',
    colors: [0xd8d2c4, 0xb8b0a0, 0xe0b04a],
    shape: 'smoke',
    rate: 12,
    size: [0.25, 0.45],
    life: [0.6, 1],
    speed: 0.5,
    rise: 1.5,
    gravity: -2,
    additive: false,
    deathColors: [0xc9a227, 0x8b5a2b, 0xd8d2c4],
  },
  candy: {
    name: 'Разноцветная посыпка',
    colors: [0xff5fa2, 0xffd166, 0x06d6a0, 0x4cc9f0, 0xffffff],
    shape: 'sprinkle',
    rate: 24,
    size: [0.12, 0.2],
    life: [0.5, 0.9],
    speed: 2,
    rise: 2,
    gravity: 9,
    additive: false,
    deathColors: [0xff5fa2, 0xffd166, 0x06d6a0, 0x4cc9f0],
  },
  cosmic: {
    name: 'Звёздная пыль',
    colors: [0xffffff, 0xc77dff, 0x72efdd],
    shape: 'star',
    rate: 18,
    size: [0.15, 0.32],
    life: [0.5, 1],
    speed: 0.7,
    rise: 0.3,
    gravity: 0,
    additive: true,
    aura: 0x9d4edd,
    deathColors: [0xffffff, 0xc77dff, 0x72efdd],
  },
};
