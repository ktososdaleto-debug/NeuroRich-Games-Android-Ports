export type Difficulty = 'easy' | 'normal' | 'hard' | 'harder' | 'insane' | 'demon';

export interface LevelMeta {
  id: string;
  name: string;
  difficulty: Difficulty;
  stars: number;
  /** Акцентный цвет уровня: фон меню перекрашивается в него при выборе */
  color: string;
  songId: string;
  song: { title: string; author: string };
}

/**
 * Каталог уровней (только метаданные). Сами уровни собираются в src/levels/
 * в формате game/types.ts — тот же формат будет сохранять редактор.
 */
export const LEVELS: readonly LevelMeta[] = [
  {
    id: 'first-jump',
    name: 'Первый прыжок',
    difficulty: 'normal',
    stars: 3,
    color: '#2a5fe0',
    songId: 'first-jump',
    song: { title: 'Неоновый старт', author: 'Claude Synth' },
  },
  {
    id: 'block-world',
    name: 'Блочный мир',
    difficulty: 'hard',
    stars: 5,
    color: '#4caf50',
    songId: 'block-world',
    song: { title: 'Пиксельный рассвет', author: 'Claude Synth' },
  },
];
