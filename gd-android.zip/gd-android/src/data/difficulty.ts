import type { Difficulty } from './levels';

export const DIFFICULTIES: Record<Difficulty, { label: string; color: string }> = {
  easy: { label: 'Легко', color: '#3ec9ff' },
  normal: { label: 'Нормально', color: '#4dde4d' },
  hard: { label: 'Сложно', color: '#ffc93e' },
  harder: { label: 'Очень сложно', color: '#ff7a2e' },
  insane: { label: 'Безумно', color: '#ff4fd8' },
  demon: { label: 'Демон', color: '#e0243a' },
};
