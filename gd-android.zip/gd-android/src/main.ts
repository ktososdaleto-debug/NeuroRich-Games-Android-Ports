import '@fontsource/russo-one';
import './ui/styles/index.css';

import type { Application } from 'pixi.js';
import { createPixiApp } from './render/pixiApp';
import { MenuBackground } from './render/MenuBackground';
import { skinImagesReady } from './render/skinImages';
import { Router } from './ui/Router';
import { createSplash } from './ui/screens/SplashScreen';
import { createMainMenu } from './ui/screens/MainMenu';
import { createLevelSelect } from './ui/screens/LevelSelect';
import { createSettings } from './ui/screens/SettingsScreen';
import { createSkins } from './ui/screens/SkinsScreen';
import { createGameScreen } from './ui/screens/GameScreen';
import { createEditorList } from './ui/screens/EditorListScreen';
import { createEditorScreen } from './ui/screens/EditorScreen';
import { audio } from './core/AudioManager';
import { createFpsCounter } from './core/fps';
import { settings } from './state/settings';
import { profile } from './state/profile';

async function boot(): Promise<void> {
  const stage = document.getElementById('stage')!;
  const uiRoot = document.getElementById('ui')!;

  let app: Application | null = null;
  let bg: MenuBackground | null = null;
  try {
    app = await createPixiApp(stage);
    bg = new MenuBackground(app);
  } catch (err) {
    console.error('WebGL недоступен: меню работает без фона, игра не запустится', err);
  }

  const fps = createFpsCounter();
  settings.subscribe((s) => {
    bg?.setMotion(s.menuAnimations);
    bg?.setParticleQuality(s.particles);
    document.body.classList.toggle('reduced-motion', !s.menuAnimations);
    fps.setVisible(s.showFps);
  }, true);

  if (bg) {
    const menuBg = bg;
    profile.subscribe((p) => menuBg.setSkin(p.skin), true);
    // картинки особых скинов подгружаются позже — перерисовываем демо-куб
    void skinImagesReady.then(() => menuBg.setSkin(profile.get().skin, true));
    audio.onBeat(() => menuBg.pulse());
  }

  const router = new Router(uiRoot, { app, background: bg });
  router
    .register('splash', createSplash)
    .register('main', createMainMenu)
    .register('levels', createLevelSelect)
    .register('settings', createSettings)
    .register('skins', createSkins)
    .register('game', createGameScreen)
    .register('editorList', createEditorList)
    .register('editor', createEditorScreen);
  router.go('splash', 'fade');

  window.addEventListener('contextmenu', (e) => e.preventDefault());
}

void boot();
