import { midi, type Synth } from '../Synth';
import type { Song } from '../types';

/*
 * «Пиксельный рассвет» — трек уровня «Блочный мир». 156 BPM, 56 тактов.
 * Каждое «измерение» уровня звучит по-своему, а в последнем такте перед порталом
 * идёт нарастание — портал всегда совпадает с первой долей новой части.
 *
 *   0–3   вступление (тихое «пиано»)      20–27 шахта (прыгучий бас)     44–51 рассвет (кульминация)
 *   4–11  поверхность (пиано + ударные)    28–35 Незер (тяжёлый минор)    52–55 концовка
 *   12–19 пещера (арпеджио, драйв)         36–43 Энд (воздушные колокольчики)
 */

const BPM = 156;
const STEP = 60 / BPM / 4;
const BARS = 56;

type ChordName = 'G' | 'D' | 'Em' | 'C' | 'Am' | 'B';
interface Chord {
  root: number;
  notes: number[];
}

const CHORDS: Record<ChordName, Chord> = {
  G: { root: 43, notes: [55, 59, 62] },
  D: { root: 38, notes: [54, 57, 62] },
  Em: { root: 40, notes: [55, 59, 64] },
  C: { root: 48, notes: [55, 60, 64] },
  Am: { root: 45, notes: [57, 60, 64] },
  B: { root: 47, notes: [54, 59, 63] },
};

type SectionName = 'intro' | 'surface' | 'cave' | 'mine' | 'nether' | 'end' | 'finale' | 'outro';
interface Section {
  name: SectionName;
  start: number;
  end: number;
  intensity: number;
  chords: ChordName[];
}

const SURFACE: ChordName[] = ['G', 'D', 'Em', 'C'];
const CAVE: ChordName[] = ['Em', 'C', 'G', 'D'];
const NETHER: ChordName[] = ['Em', 'C', 'Am', 'B'];
const END: ChordName[] = ['C', 'G', 'Am', 'Em'];

const SECTIONS: Section[] = [
  { name: 'intro', start: 0, end: 4, intensity: 0.3, chords: SURFACE },
  { name: 'surface', start: 4, end: 12, intensity: 0.6, chords: SURFACE },
  { name: 'cave', start: 12, end: 20, intensity: 0.85, chords: CAVE },
  { name: 'mine', start: 20, end: 28, intensity: 0.9, chords: CAVE },
  { name: 'nether', start: 28, end: 36, intensity: 0.95, chords: NETHER },
  { name: 'end', start: 36, end: 44, intensity: 0.75, chords: END },
  { name: 'finale', start: 44, end: 52, intensity: 1, chords: SURFACE },
  { name: 'outro', start: 52, end: 56, intensity: 0.4, chords: SURFACE },
];

const sectionAt = (bar: number): Section =>
  SECTIONS.find((s) => bar >= s.start && bar < s.end) ?? SECTIONS[SECTIONS.length - 1];

// ---- Мелодии: по 8 восьмых в такте; «-» тянет ноту, «.» — пауза ----

interface MelodyNote {
  midi: number;
  len: number;
}

const NOTE_INDEX: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };

function noteToMidi(name: string): number {
  const m = /^([A-G])(#|b)?(\d)$/.exec(name);
  if (!m) throw new Error(`Неверная нота: ${name}`);
  return 12 * (Number(m[3]) + 1) + NOTE_INDEX[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
}

function parseMelody(bars: string[]): Array<Map<number, MelodyNote>> {
  return bars.map((bar) => {
    const map = new Map<number, MelodyNote>();
    let last: MelodyNote | null = null;
    bar
      .trim()
      .split(/\s+/)
      .forEach((tok, i) => {
        if (tok === '.') {
          last = null;
        } else if (tok === '-') {
          if (last) last.len += 2;
        } else {
          last = { midi: noteToMidi(tok), len: 2 };
          map.set(i * 2, last);
        }
      });
    return map;
  });
}

const THEME = parseMelody([
  'D5 . B4 D5 G5 . F#5 .',
  'E5 D5 . A4 . D5 F#5 .',
  'G5 . E5 . B4 . E5 G5',
  'E5 - D5 C5 B4 . A4 .',
]);
const CAVE_TUNE = parseMelody([
  'B4 . E5 . G5 . F#5 E5',
  'E5 . C5 . G4 . C5 E5',
  'D5 . B4 . G4 . B4 D5',
  'F#5 - E5 . D5 . A4 .',
]);
const NETHER_TUNE = parseMelody([
  'E5 - - . G5 - F#5 .',
  'E5 - - . C5 - D5 .',
  'E5 - - . A5 - G5 .',
  'F#5 - - - D#5 - B4 .',
]);
const END_TUNE = parseMelody([
  'G5 . E5 . C6 . E5 .',
  'D6 . B5 . G5 . B5 .',
  'C6 . A5 . E5 . A5 .',
  'B5 . G5 . E5 . G5 B5',
]);

// ---- Инструменты -----------------------------------------------------------

/** «Пиано»: треугольник с быстрым затуханием и тихой октавой сверху */
function piano(sy: Synth, note: number, t: number, out: AudioNode, k = 1, dur = 0.55): void {
  sy.tone(midi(note), t, dur, out, { type: 'triangle', gain: 0.11 * k, attack: 0.003 });
  sy.tone(midi(note + 12), t, dur * 0.4, out, { type: 'sine', gain: 0.035 * k, attack: 0.003 });
}

/** Чиптюн-лид: квадрат + эхо на пунктирную восьмую */
function chipLead(sy: Synth, note: number, len: number, t: number, out: AudioNode, k = 1): void {
  const dur = len * STEP * 0.95;
  sy.tone(midi(note), t, dur, out, { type: 'square', gain: 0.06 * k, cutoff: 3400 });
  sy.tone(midi(note), t, dur, out, { type: 'sawtooth', gain: 0.03 * k, detune: 7, cutoff: 2800 });
  sy.tone(midi(note), t + STEP * 3, dur, out, { type: 'triangle', gain: 0.03 * k });
}

/** «Гаст»: тягучий пилообразный лид с глиссандо снизу */
function wailLead(sy: Synth, note: number, len: number, t: number, out: AudioNode): void {
  const f = midi(note);
  const dur = len * STEP * 0.95;
  sy.tone(f * 0.94, t, dur, out, { type: 'sawtooth', gain: 0.06, slideTo: f, cutoff: 2400, attack: 0.03 });
  sy.tone(f / 2, t, dur, out, { type: 'square', gain: 0.025, cutoff: 1600, attack: 0.03 });
}

function bell(sy: Synth, note: number, t: number, out: AudioNode, k = 1): void {
  sy.tone(midi(note), t, 0.7, out, { type: 'sine', gain: 0.07 * k });
  sy.tone(midi(note + 19), t, 0.3, out, { type: 'sine', gain: 0.02 * k });
}

function pad(sy: Synth, chord: Chord, t: number, out: AudioNode, gain: number, attack = 0.2, bars = 1): void {
  const dur = STEP * 16 * bars;
  for (const n of chord.notes) {
    sy.tone(midi(n), t, dur, out, { type: 'sawtooth', gain, attack, cutoff: 1300, detune: -6 });
    sy.tone(midi(n), t, dur, out, { type: 'triangle', gain: gain * 1.2, attack, detune: 6 });
  }
}

const ARP = [0, 1, 2, 3, 2, 1, 0, 1, 0, 1, 2, 3, 2, 1, 2, 3];

function arp(sy: Synth, chord: Chord, s: number, t: number, out: AudioNode, cutoff: number, gain: number, octave = 12): void {
  if (gain <= 0.001) return;
  const i = ARP[s];
  const n = (i < 3 ? chord.notes[i] : chord.notes[0] + 12) + octave;
  sy.tone(midi(n), t, STEP * 0.9, out, { type: 'square', gain, cutoff });
}

function drums(sy: Synth, s: number, t: number, out: AudioNode, busy: boolean): void {
  const sub = s % 4;
  if (sub === 0) sy.kick(t, out, 0.85);
  if (s === 4 || s === 12) sy.clap(t, out, 0.26);
  if (sub === 2) sy.hat(t, out, 0.08, busy);
  if (busy && sub % 2 === 1) sy.hat(t, out, 0.04);
}

/** Нарастание в последнем такте части — перед каждым порталом */
function build(sy: Synth, s: number, t: number, out: AudioNode): void {
  if (s === 0) sy.riser(t, STEP * 15, out, 0.1);
  if (s >= 8) sy.snare(t, out, 0.06 + (s - 8) * 0.025);
}

// ---------------------------------------------------------------------------

export const blockWorldSong: Song = {
  id: 'block-world',
  bpm: BPM,
  lengthSteps: BARS * 16,
  loop: false,

  intensity(beat) {
    return sectionAt(Math.floor(beat / 4)).intensity;
  },

  play(sy, step, t, out) {
    if (step >= BARS * 16) return;
    const bar = Math.floor(step / 16);
    const s = step % 16;
    const sub = s % 4;
    const sec = sectionAt(bar);
    const rel = bar - sec.start;
    const last = bar === sec.end - 1;
    const chord = CHORDS[sec.chords[bar % 4]];

    // нарастание перед порталом (кроме концовки)
    if (last && sec.name !== 'outro' && sec.name !== 'finale') build(sy, s, t, out);

    switch (sec.name) {
      case 'intro': {
        if (s === 0) pad(sy, chord, t, out, 0.015, 0.4);
        if (s % 2 === 0) piano(sy, chord.notes[ARP[s] % 3] + 12, t, out, 0.8);
        if (rel >= 2 && s === 0) piano(sy, chord.root + 12, t, out, 0.9, 1.2);
        break;
      }

      case 'surface': {
        drums(sy, s, t, out, false);
        if (s % 2 === 0) sy.tone(midi(chord.root + (s % 4 === 2 ? 12 : 0)), t, STEP * 1.8, out, { type: 'triangle', gain: 0.16 });
        if (s % 2 === 0) piano(sy, chord.notes[ARP[s] % 3] + 12, t, out, 0.55, 0.3);
        const n = THEME[bar % 4].get(s);
        if (n && rel >= 2) piano(sy, n.midi, t, out, 1.1, n.len * STEP * 1.4);
        if (s === 0) pad(sy, chord, t, out, 0.012);
        break;
      }

      case 'cave': {
        if (rel === 0 && s === 0) {
          sy.crash(t, out, 0.2);
          sy.subDrop(t, out, 0.45);
        }
        drums(sy, s, t, out, true);
        if (sub !== 0) {
          sy.tone(midi(chord.root + (sub === 2 ? 12 : 0)), t, STEP * 0.9, out, {
            type: 'sawtooth', gain: sub === 2 ? 0.16 : 0.1, cutoff: 2000, cutoffEnd: 300, q: 4,
          });
        }
        arp(sy, chord, s, t, out, 2800, 0.03);
        const n = CAVE_TUNE[bar % 4].get(s);
        if (n) chipLead(sy, n.midi, n.len, t, out);
        if (s === 0) pad(sy, chord, t, out, 0.014);
        break;
      }

      case 'mine': {
        if (rel === 0 && s === 0) sy.crash(t, out, 0.2);
        drums(sy, s, t, out, true);
        // прыгучий бас: октавы шестнадцатыми
        sy.tone(midi(chord.root + (s % 2 ? 12 : 0)), t, STEP * 0.8, out, { type: 'square', gain: 0.09, cutoff: 1400 });
        // томы в конце каждого второго такта
        if (bar % 2 === 1 && s >= 12) sy.tone(180 - (s - 12) * 25, t, 0.15, out, { type: 'sine', gain: 0.3, slideTo: 70 });
        const n = CAVE_TUNE[bar % 4].get(s);
        if (n) bell(sy, n.midi + 12, t, out, 0.9);
        if (s === 0) pad(sy, chord, t, out, 0.012);
        break;
      }

      case 'nether': {
        if (rel === 0 && s === 0) {
          sy.crash(t, out, 0.24);
          sy.subDrop(t, out, 0.6);
        }
        if (sub === 0 || s === 14) sy.kick(t, out, 0.95);
        if (s === 4 || s === 12) sy.snare(t, out, 0.3);
        if (sub === 2) sy.hat(t, out, 0.09, true);
        if (s % 2 === 0) {
          sy.tone(midi(chord.root), t, STEP * 1.8, out, { type: 'sawtooth', gain: 0.18, cutoff: 1200, q: 6 });
          sy.tone(midi(chord.root - 12), t, STEP * 1.8, out, { type: 'square', gain: 0.07, cutoff: 500 });
        }
        const n = NETHER_TUNE[bar % 4].get(s);
        if (n) wailLead(sy, n.midi, n.len, t, out);
        if (s === 0) pad(sy, chord, t, out, 0.018, 0.1);
        break;
      }

      case 'end': {
        if (rel === 0 && s === 0) sy.crash(t, out, 0.18);
        if (s === 0 || s === 8) sy.kick(t, out, 0.7);
        if (s === 12) sy.clap(t, out, 0.18);
        sy.hat(t, out, sub === 2 ? 0.06 : 0.025);
        arp(sy, chord, s, t, out, 5000, 0.025, 24);
        const n = END_TUNE[bar % 4].get(s);
        if (n) bell(sy, n.midi, t, out);
        if (s === 0) pad(sy, chord, t, out, 0.03, 0.5);
        break;
      }

      case 'finale': {
        if ((rel === 0 || rel === 4) && s === 0) {
          sy.crash(t, out, 0.24);
          sy.subDrop(t, out, 0.5);
        }
        drums(sy, s, t, out, true);
        if (sub !== 0) {
          sy.tone(midi(chord.root + (sub === 2 ? 12 : 0)), t, STEP * 0.9, out, {
            type: 'sawtooth', gain: sub === 2 ? 0.17 : 0.11, cutoff: 2200, cutoffEnd: 300, q: 4,
          });
        }
        arp(sy, chord, s, t, out, 3200, 0.022);
        const n = THEME[bar % 4].get(s);
        if (n) {
          chipLead(sy, n.midi, n.len, t, out, 1.1);
          piano(sy, n.midi, t, out, 0.6, n.len * STEP * 1.2);
        }
        if (s === 0) pad(sy, chord, t, out, 0.02);
        if (rel === 7 && s >= 12) sy.snare(t, out, 0.14);
        break;
      }

      case 'outro': {
        const fade = 1 - (rel * 16 + s) / 64;
        if (rel < 3 && s % 2 === 0) piano(sy, chord.notes[ARP[s] % 3] + 12, t, out, 0.7 * fade);
        if (rel < 3 && s === 0) pad(sy, chord, t, out, 0.02);
        if (rel === 3 && s === 0) {
          pad(sy, CHORDS.G, t, out, 0.045, 0.01, 4.5);
          piano(sy, 67, t, out, 1.2, 3);
          piano(sy, 71, t + 0.08, out, 1, 3);
          piano(sy, 74, t + 0.16, out, 1, 3);
          sy.tone(midi(31), t, 3, out, { type: 'sine', gain: 0.28 });
        }
        break;
      }
    }
  },
};
