import { midi, type Synth } from '../Synth';
import type { Song } from '../types';

/*
 * «Неоновый старт» — трек уровня «Первый прыжок».
 * 156 BPM: при скорости куба 10.4 блока/с одна доля = ровно 4 блока,
 * а прыжок длится ровно одну долю. Уровень расставлен по этим долям.
 *
 * Такты (по 4 доли):
 *   0–3   вступление      12–15 нарастание     24–27 брейк        32–43 дроп 2
 *   4–11  куплет          16–23 дроп 1         28–31 нарастание 2 44–47 концовка
 */

const BPM = 156;
const STEP = 60 / BPM / 4;
const BARS = 48;

type ChordName = 'Am' | 'F' | 'C' | 'G' | 'Em';
interface Chord {
  root: number;
  notes: number[];
}

const CHORDS: Record<ChordName, Chord> = {
  Am: { root: 45, notes: [57, 60, 64] },
  F: { root: 41, notes: [57, 60, 65] },
  C: { root: 48, notes: [55, 60, 64] },
  G: { root: 43, notes: [55, 59, 62] },
  Em: { root: 40, notes: [55, 59, 64] },
};
const MAIN: ChordName[] = ['Am', 'F', 'C', 'G'];
const BREAK: ChordName[] = ['F', 'G', 'Em', 'Am'];

type SectionName = 'intro' | 'verse' | 'build' | 'drop1' | 'break' | 'build2' | 'drop2' | 'outro';
interface Section {
  name: SectionName;
  start: number;
  end: number;
  intensity: number;
}

const SECTIONS: Section[] = [
  { name: 'intro', start: 0, end: 4, intensity: 0.35 },
  { name: 'verse', start: 4, end: 12, intensity: 0.6 },
  { name: 'build', start: 12, end: 16, intensity: 0.75 },
  { name: 'drop1', start: 16, end: 24, intensity: 1 },
  { name: 'break', start: 24, end: 28, intensity: 0.3 },
  { name: 'build2', start: 28, end: 32, intensity: 0.75 },
  { name: 'drop2', start: 32, end: 44, intensity: 1 },
  { name: 'outro', start: 44, end: 48, intensity: 0.45 },
];

const sectionAt = (bar: number): Section =>
  SECTIONS.find((s) => bar >= s.start && bar < s.end) ?? SECTIONS[SECTIONS.length - 1];

// ---- Мелодии: по 8 восьмых в такте; «-» тянет ноту, «.» — пауза ----

interface MelodyNote {
  midi: number;
  /** в шестнадцатых */
  len: number;
}

const NOTE_INDEX: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };

function noteToMidi(name: string): number {
  const m = /^([A-G])(#|b)?(\d)$/.exec(name);
  if (!m) throw new Error(`Неверная нота: ${name}`);
  return 12 * (Number(m[3]) + 1) + NOTE_INDEX[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
}

function parseMelody(bars: string[]): Array<Map<number, MelodyNote>> {
  return bars.map((bar) => {
    const map = new Map<number, MelodyNote>();
    let last: MelodyNote | null = null;
    bar
      .trim()
      .split(/\s+/)
      .forEach((tok, i) => {
        if (tok === '.') {
          last = null;
        } else if (tok === '-') {
          if (last) last.len += 2;
        } else {
          last = { midi: noteToMidi(tok), len: 2 };
          map.set(i * 2, last);
        }
      });
    return map;
  });
}

const LEAD_A = parseMelody([
  'E5 . E5 D5 E5 . C5 D5',
  'C5 . A4 . C5 D5 C5 A4',
  'G4 . C5 . E5 . G5 F5',
  'E5 - D5 . B4 . D5 .',
]);

const LEAD_B = parseMelody([
  'A5 . G5 E5 . E5 G5 A5',
  'C6 . A5 . F5 . A5 C6',
  'G5 . E5 . C5 E5 G5 C6',
  'B5 - . G5 D5 . B4 D5',
]);

// ---- Партии ----------------------------------------------------------------

function drums(sy: Synth, s: number, t: number, out: AudioNode, hats: 'eighth' | 'open' | 'sixteenth'): void {
  const sub = s % 4;
  if (sub === 0) sy.kick(t, out, 0.85);
  if (s === 4 || s === 12) sy.clap(t, out, 0.28);
  if (sub === 2) sy.hat(t, out, hats === 'eighth' ? 0.07 : 0.09, hats !== 'eighth');
  if (sub % 2 === 1) sy.hat(t, out, hats === 'sixteenth' ? 0.045 : 0.025);
}

function bassEighth(sy: Synth, chord: Chord, s: number, t: number, out: AudioNode, gain: number): void {
  if (s % 2) return;
  const n = chord.root + (s % 4 === 2 ? 12 : 0);
  sy.tone(midi(n), t, STEP * 1.8, out, { type: 'sawtooth', gain, cutoff: 900, cutoffEnd: 250 });
}

/** «Качающий» бас между ударами бочки */
function bassPump(sy: Synth, chord: Chord, s: number, t: number, out: AudioNode): void {
  const sub = s % 4;
  if (sub === 0) return;
  const n = chord.root + (sub === 2 ? 12 : 0);
  sy.tone(midi(n), t, STEP * 0.9, out, { type: 'sawtooth', gain: sub === 2 ? 0.17 : 0.11, cutoff: 2200, cutoffEnd: 300, q: 4 });
}

const ARP = [0, 1, 2, 3, 2, 1, 0, 1, 0, 1, 2, 3, 2, 1, 2, 3];

function arp(sy: Synth, chord: Chord, s: number, t: number, out: AudioNode, cutoff: number, gain: number): void {
  if (gain <= 0.001) return;
  const i = ARP[s];
  const n = (i < 3 ? chord.notes[i] : chord.notes[0] + 12) + 12;
  sy.tone(midi(n), t, STEP * 0.9, out, { type: 'square', gain, cutoff });
}

function pad(sy: Synth, chord: Chord, t: number, out: AudioNode, gain: number, attack = 0.15, bars = 1): void {
  const dur = STEP * 16 * bars;
  for (const n of chord.notes) {
    sy.tone(midi(n), t, dur, out, { type: 'sawtooth', gain, attack, cutoff: 1400, detune: -7 });
    sy.tone(midi(n), t, dur, out, { type: 'sawtooth', gain, attack, cutoff: 1400, detune: 7 });
  }
}

function lead(sy: Synth, note: number, len: number, t: number, out: AudioNode, octave: boolean, k = 1): void {
  const dur = len * STEP * 0.95;
  const f = midi(note);
  sy.tone(f, t, dur, out, { type: 'sawtooth', gain: 0.055 * k, detune: -6, cutoff: 3600 });
  sy.tone(f, t, dur, out, { type: 'sawtooth', gain: 0.055 * k, detune: 6, cutoff: 3600 });
  sy.tone(f / 2, t, dur, out, { type: 'square', gain: 0.025 * k, cutoff: 3600 });
  if (octave) sy.tone(f * 2, t, dur, out, { type: 'square', gain: 0.02 * k, cutoff: 5000 });
  // эхо на пунктирную восьмую
  sy.tone(f, t + STEP * 3, dur, out, { type: 'triangle', gain: 0.03 * k });
}

function bell(sy: Synth, note: number, t: number, out: AudioNode): void {
  sy.tone(midi(note), t, 0.6, out, { type: 'triangle', gain: 0.07 });
  sy.tone(midi(note) * 2, t, 0.25, out, { type: 'sine', gain: 0.025 });
}

// ---------------------------------------------------------------------------

export const firstJumpSong: Song = {
  id: 'first-jump',
  bpm: BPM,
  lengthSteps: BARS * 16,
  loop: false,

  intensity(beat) {
    return sectionAt(Math.floor(beat / 4)).intensity;
  },

  play(sy, step, t, out) {
    if (step >= BARS * 16) return;
    const bar = Math.floor(step / 16);
    const s = step % 16;
    const sub = s % 4;
    const sec = sectionAt(bar);
    const rel = bar - sec.start;
    const chord = CHORDS[(sec.name === 'break' ? BREAK : MAIN)[bar % 4]];
    /** 0..1 — прогресс внутри 4-тактовой секции */
    const progress4 = (rel * 16 + s) / 64;

    switch (sec.name) {
      case 'intro': {
        if (s === 0) pad(sy, chord, t, out, 0.022);
        arp(sy, chord, s, t, out, 500 + progress4 * 2500, 0.03);
        if (rel >= 2 && sub === 0) sy.kick(t, out, 0.7);
        if (rel >= 2 && s === 0) sy.tone(midi(chord.root), t, STEP * 16, out, { type: 'triangle', gain: 0.12, attack: 0.02 });
        if (rel === 3 && sub === 2) sy.hat(t, out, 0.06);
        if (rel === 3 && s >= 12) sy.snare(t, out, 0.08 + (s - 12) * 0.05);
        break;
      }

      case 'verse': {
        drums(sy, s, t, out, 'eighth');
        bassEighth(sy, chord, s, t, out, 0.15);
        arp(sy, chord, s, t, out, 2600, 0.035);
        if (s === 0) pad(sy, chord, t, out, 0.015);
        if (rel === 7 && s >= 12) sy.snare(t, out, 0.12 + (s - 12) * 0.04);
        break;
      }

      case 'build':
      case 'build2': {
        // последняя доля перед дропом — тишина
        const silent = rel === 3 && s >= 12;
        if (!silent && sub === 0) sy.kick(t, out, 0.75);
        const roll = rel === 0 ? s % 4 === 0 : rel === 1 ? s % 2 === 0 : rel === 2 ? true : s < 12;
        if (roll) sy.snare(t, out, 0.06 + progress4 * 0.2);
        if (rel === 0 && s === 0) sy.riser(t, STEP * 60, out, 0.12);
        if (!silent) {
          bassEighth(sy, chord, s, t, out, 0.13);
          arp(sy, chord, s, t, out, 1500 + progress4 * 5000, 0.035);
        }
        if (s === 0) pad(sy, chord, t, out, 0.02);
        break;
      }

      case 'drop1':
      case 'drop2': {
        const second = sec.name === 'drop2';
        if (s === 0 && (rel === 0 || (second && rel === 8))) {
          sy.crash(t, out, 0.22);
          sy.subDrop(t, out, 0.5);
        }
        drums(sy, s, t, out, second ? 'sixteenth' : 'open');
        bassPump(sy, chord, s, t, out);
        arp(sy, chord, s, t, out, 3200, 0.022);
        if (s === 0) pad(sy, chord, t, out, 0.02);
        const note = (second ? LEAD_B : LEAD_A)[bar % 4].get(s);
        if (note) lead(sy, note.midi, note.len, t, out, second && rel >= 8);
        const fill = second ? rel === 7 || rel === 11 : rel === 7;
        if (fill && s >= 12) sy.snare(t, out, 0.14);
        break;
      }

      case 'break': {
        if (s === 0) pad(sy, chord, t, out, 0.04, 0.4);
        // «колокольчики» на каждую долю держат ритм, пока нет бочки
        if (sub === 0) bell(sy, chord.notes[(s / 4) % 3] + 24, t, out);
        if (rel >= 2 && (s === 0 || s === 8)) sy.kick(t, out, 0.55);
        if (rel === 3 && s >= 12) sy.snare(t, out, 0.06 + (s - 12) * 0.03);
        break;
      }

      case 'outro': {
        const fade = 1 - progress4;
        if (rel < 2 && sub === 0) sy.kick(t, out, 0.7);
        if (rel < 2 && (s === 4 || s === 12)) sy.clap(t, out, 0.2);
        if (rel < 3) arp(sy, chord, s, t, out, 2400, 0.035 * fade);
        if (rel < 3 && s === 0) pad(sy, chord, t, out, 0.025);
        if (rel < 2) {
          const note = LEAD_A[bar % 4].get(s);
          if (note) lead(sy, note.midi, note.len, t, out, false, 0.6);
        }
        if (rel === 3 && s === 0) {
          pad(sy, CHORDS.Am, t, out, 0.05, 0.01, 4.5);
          sy.crash(t, out, 0.12);
          sy.tone(midi(33), t, 3, out, { type: 'sine', gain: 0.3 });
          bell(sy, 81, t, out);
        }
        break;
      }
    }
  },
};
