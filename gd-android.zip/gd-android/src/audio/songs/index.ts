import type { Song } from '../types';
import { menuSong } from './menuSong';
import { firstJumpSong } from './firstJumpSong';
import { blockWorldSong } from './blockWorldSong';

const SONGS: Record<string, Song> = {
  [menuSong.id]: menuSong,
  [firstJumpSong.id]: firstJumpSong,
  [blockWorldSong.id]: blockWorldSong,
};

export function getSong(id: string): Song {
  return SONGS[id] ?? menuSong;
}

export { menuSong };
