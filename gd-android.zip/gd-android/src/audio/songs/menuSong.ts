import { midi } from '../Synth';
import type { Song } from '../types';

const BPM = 124;
const STEP = 60 / BPM / 4;
const PROGRESSION = [
  { bass: 45, chord: [57, 60, 64] }, // Am
  { bass: 41, chord: [57, 60, 65] }, // F
  { bass: 48, chord: [55, 60, 64] }, // C
  { bass: 43, chord: [55, 59, 62] }, // G
];
/** Мелодия восьмыми нотами (32 = 4 такта), null — пауза */
const MELODY: Array<number | null> = [
  76, null, 74, 76, 72, null, 69, null,
  72, null, 74, 72, 69, null, 65, null,
  67, null, 72, 74, 76, null, 79, null,
  79, null, 76, 74, 71, null, 74, null,
];

/** Спокойная петля главного меню: 4 такта без мелодии, 4 — с мелодией */
export const menuSong: Song = {
  id: 'menu',
  bpm: BPM,
  lengthSteps: 128,
  loop: true,
  intensity: () => 0.6,
  play(sy, step, t, out) {
    const s = step % 16;
    const { bass, chord } = PROGRESSION[Math.floor(step / 16) % 4];

    if (s % 4 === 0) sy.kick(t, out, 0.75);
    if (s === 4 || s === 12) sy.noise(t, 0.16, 0.22, out, 'highpass', 1400);
    if (s % 2 === 1) sy.noise(t, 0.04, 0.06, out, 'highpass', 7000);
    if (s % 4 === 2) sy.noise(t, 0.09, 0.09, out, 'highpass', 6000);

    if (s === 0) {
      for (const n of chord) sy.tone(midi(n), t, STEP * 16, out, { type: 'sawtooth', gain: 0.025, attack: 0.25, cutoff: 1100 });
    }
    if (s % 2 === 0) {
      sy.tone(midi(bass + (s % 4 === 2 ? 12 : 0)), t, STEP * 1.8, out, { type: 'sawtooth', gain: 0.16, cutoff: 700 });
    }
    const arp = chord[[0, 1, 2, 1][s % 4]] + (s >= 8 ? 12 : 0);
    sy.tone(midi(arp), t, STEP * 0.9, out, { type: 'square', gain: 0.04, cutoff: 3200 });

    if (step >= 64 && s % 2 === 0) {
      const note = MELODY[Math.floor((step % 64) / 2)];
      if (note !== null) {
        sy.tone(midi(note), t, STEP * 3, out, { type: 'triangle', gain: 0.13, attack: 0.01 });
        sy.tone(midi(note), t, STEP * 2.5, out, { type: 'square', gain: 0.025, detune: 8, cutoff: 2500 });
      }
    }
  },
};
