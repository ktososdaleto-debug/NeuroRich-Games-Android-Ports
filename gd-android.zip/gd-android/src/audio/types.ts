import type { Synth } from './Synth';

/**
 * Песня — это функция, которая по номеру шестнадцатой ноты планирует звуки.
 * Благодаря этому трек можно начать с любого места (нужно для чекпоинтов практики).
 */
export interface Song {
  id: string;
  bpm: number;
  /** Длина в шестнадцатых */
  lengthSteps: number;
  loop: boolean;
  /** Запланировать звуки одной шестнадцатой; t — время AudioContext */
  play(sy: Synth, step: number, t: number, out: AudioNode): void;
  /** 0..1 — насколько сильно «качает» музыка в этой доле (для пульсации картинки) */
  intensity(beat: number): number;
}
