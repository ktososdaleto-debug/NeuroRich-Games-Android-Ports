/** Набор простых инструментов на Web Audio. Всё создаётся «одноразово» на каждую ноту. */

export interface ToneOptions {
  type?: OscillatorType;
  gain?: number;
  attack?: number;
  /** Частота среза lowpass-фильтра, Гц */
  cutoff?: number;
  /** Куда сдвинуть срез к концу ноты (эффект «вау») */
  cutoffEnd?: number;
  q?: number;
  /** Глиссандо к этой частоте за время звучания */
  slideTo?: number;
  detune?: number;
}

export const midi = (n: number): number => 440 * Math.pow(2, (n - 69) / 12);

export class Synth {
  private readonly noiseBuffer: AudioBuffer;

  constructor(readonly ctx: AudioContext) {
    const len = ctx.sampleRate * 2;
    this.noiseBuffer = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = this.noiseBuffer.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  }

  tone(freq: number, t: number, dur: number, out: AudioNode, o: ToneOptions = {}): void {
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = o.type ?? 'square';
    osc.frequency.setValueAtTime(freq, t);
    if (o.slideTo) osc.frequency.exponentialRampToValueAtTime(o.slideTo, t + dur);
    if (o.detune) osc.detune.setValueAtTime(o.detune, t);

    const g = ctx.createGain();
    const attack = o.attack ?? 0.005;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(o.gain ?? 0.1, 0.0002), t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(dur, attack + 0.01));

    let node: AudioNode = osc;
    if (o.cutoff) {
      const f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.Q.value = o.q ?? 0.7;
      f.frequency.setValueAtTime(o.cutoff, t);
      if (o.cutoffEnd) f.frequency.exponentialRampToValueAtTime(o.cutoffEnd, t + dur);
      node = osc.connect(f);
    }
    node.connect(g).connect(out);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  noise(t: number, dur: number, gain: number, out: AudioNode, type: BiquadFilterType = 'highpass', freq = 1000, q = 0.7): void {
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(Math.max(gain, 0.0002), t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(out);
    src.start(t, Math.random() * 1.5);
    src.stop(t + dur + 0.02);
  }

  kick(t: number, out: AudioNode, amp = 0.75): void {
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, t);
    osc.frequency.exponentialRampToValueAtTime(42, t + 0.13);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(amp, 0.0002), t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.32);
    osc.connect(g).connect(out);
    osc.start(t);
    osc.stop(t + 0.35);
  }

  snare(t: number, out: AudioNode, amp = 0.25): void {
    this.noise(t, 0.16, amp, out, 'bandpass', 1900, 0.9);
    this.tone(200, t, 0.09, out, { type: 'triangle', gain: amp * 0.7, slideTo: 140 });
  }

  clap(t: number, out: AudioNode, amp = 0.25): void {
    this.noise(t, 0.03, amp, out, 'bandpass', 1300, 1.4);
    this.noise(t + 0.012, 0.03, amp, out, 'bandpass', 1300, 1.4);
    this.noise(t + 0.024, 0.14, amp, out, 'bandpass', 1200, 1.1);
  }

  hat(t: number, out: AudioNode, amp = 0.07, open = false): void {
    this.noise(t, open ? 0.14 : 0.035, amp, out, 'highpass', 7500);
  }

  crash(t: number, out: AudioNode, amp = 0.22): void {
    this.noise(t, 1.8, amp, out, 'highpass', 4200);
  }

  /** Шумовой «взлёт» перед дропом */
  riser(t: number, dur: number, out: AudioNode, amp = 0.12): void {
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.Q.value = 3;
    f.frequency.setValueAtTime(300, t);
    f.frequency.exponentialRampToValueAtTime(7000, t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(amp, t + dur);
    g.gain.linearRampToValueAtTime(0.0001, t + dur + 0.05);
    src.connect(f).connect(g).connect(out);
    src.start(t);
    src.stop(t + dur + 0.06);
  }

  /** Низкий «бум» на начале дропа */
  subDrop(t: number, out: AudioNode, amp = 0.5): void {
    this.tone(110, t, 0.9, out, { type: 'sine', gain: amp, slideTo: 32 });
  }
}
