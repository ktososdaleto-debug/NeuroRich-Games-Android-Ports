# Сборка APK
Через GitHub Actions: workflow `android-gd.yml` распаковывает `gd-android.zip` и собирает `app-debug.apk`.
Локально: `npm install && npm run android:add && npm run android:apk` (нужны Node 22, JDK 21, Android SDK).
