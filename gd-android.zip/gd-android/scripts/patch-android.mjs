// Запускается после `cap add android`: делает игру альбомной, на весь экран, и вырезы экрана не мешают.
import fs from 'node:fs';
import path from 'node:path';

const cfg = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8'));
const appId = cfg.appId;

// 1. Манифест: только альбомная ориентация.
const manifestPath = 'android/app/src/main/AndroidManifest.xml';
let manifest = fs.readFileSync(manifestPath, 'utf8');
if (!manifest.includes('screenOrientation')) {
  manifest = manifest.replace(
    /android:name="[^"]*MainActivity"/,
    (m) => `${m}\n            android:screenOrientation="sensorLandscape"`,
  );
  fs.writeFileSync(manifestPath, manifest);
}

// 2. MainActivity: скрываем системные панели (иммерсивный режим).
const javaDir = path.join('android/app/src/main/java', ...appId.split('.'));
fs.mkdirSync(javaDir, { recursive: true });
fs.writeFileSync(
  path.join(javaDir, 'MainActivity.java'),
  `package ${appId};

import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (Build.VERSION.SDK_INT >= 28) {
      getWindow().getAttributes().layoutInDisplayCutoutMode =
          WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
    }
    hideSystemBars();
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) hideSystemBars();
  }

  private void hideSystemBars() {
    WindowInsetsControllerCompat c =
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
    c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    c.hide(WindowInsetsCompat.Type.systemBars());
  }
}
`,
);
console.log('Android-проект подготовлен: альбомная ориентация + полный экран.');
