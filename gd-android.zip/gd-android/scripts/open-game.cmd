@echo off
rem Ждёт, пока dev-сервер начнёт принимать подключения, и открывает игру
rem в отдельном окне Microsoft Edge (режим приложения, без панелей браузера).
setlocal
set "PORT=%~1"
if "%PORT%"=="" set "PORT=5173"
set "URL=http://127.0.0.1:%PORT%/"
set /a TRIES=0

:wait
powershell -NoProfile -Command "try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', %PORT%); $c.Close(); exit 0 } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 goto open
set /a TRIES+=1
if %TRIES% geq 90 exit /b 1
timeout /t 1 /nobreak >nul
goto wait

:open
set "EDGE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if defined EDGE (
  start "" "%EDGE%" --app=%URL% --window-size=1280,760
) else (
  start "" "%URL%"
)
exit /b 0
