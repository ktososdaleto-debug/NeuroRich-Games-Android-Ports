import { defineConfig } from 'vite';

export default defineConfig({
  // относительные пути — чтобы собранная игра открывалась из файла (Electron / .exe)
  base: './',
  server: {
    host: '127.0.0.1',
    port: 5173,
    strictPort: true,
    open: false,
  },
  preview: {
    host: '127.0.0.1',
    port: 4173,
  },
  build: {
    target: 'es2022',
    chunkSizeWarningLimit: 1500,
  },
});
